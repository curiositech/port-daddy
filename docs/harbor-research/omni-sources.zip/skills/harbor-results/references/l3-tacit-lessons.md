# L3 Tacit Lessons — the hard-won knowledge behind the results

Load BEFORE extending, re-implementing, or designing anything adjacent to R1–R9. Each lesson: context → the mistake → the fix → the transferable rule → where it bit. These are the errors a fresh session will otherwise repeat.

## 1. The unpriced side channel (the meter bug)
**Context.** Falsifying the information floor (R1): simulate digests at budget B, measure miss rate against the floor.
**Mistake.** Gave the oracle encoder a perfect per-item score vector and charged B bits only for quantizing rank resolution (tie-breaking). Result: 8/14 apparent floor "violations."
**Fix.** Make B a literal message length: digest = encoder e:(features)→{0,1}^B, decoder d:{0,1}^B→(m-subset), shared data-independent codebook. Bits now gate *identification*. Violations → 0/16.
**Rule.** An information bound constrains what a channel carries; any simulation that appears to beat one is leaking through an unpriced side channel. Audit the meter before doubting the theorem — and before trusting the "refutation."
**Bit.** a7_experiment.py v1 vs v2; documented in Execution Report #1 §3.3. Repo: wrong turn at docs/harbor-research/wrong-turns/a7_experiment.py; fixed at skills/harbor-results/scripts/a7_experiment.py.

## 2. Cohomology of the data, not the sheaf
**Context.** Testing whether sheaf cohomology detects equivocation (R6).
**Mistake #1.** Computed dim H¹(G;F) of the abstract sheaf. That is a property of the *restriction maps* — data-independent; with generic vector readouts the coboundary is surjective and H¹=0 regardless of any lie.
**Fix #1.** The right object is the obstruction of the *observed assignment*: is the disagreement cochain g in im(δ)? Its harmonic component (projection onto coker δ) is the equivocation signal — exactly the Abramsky–Brandenburger contextuality construction, which had been cited but not coded.
**Mistake #2.** Tested on two cliques joined by a single bridge. A bridge is a *cut edge*: it lies on no cycle, so it carries no cocycle constraint — the one topology where the method provably cannot help.
**Fix #2.** The value-add requires the uncompared edge to lie on a cycle (redundant paths). Minimal decisive case: C₆ with one uncompared edge — signal 1.225 while pairwise is blind; same lie on P₆'s bridge — signal 0.000.
**Rules.** (a) Sheaf invariants of the *space* vs obstructions of the *data* are different objects; equivocation/contextuality lives in the data. (b) Before crediting a linear residual, check the topology admits its cycle constraints. This is not an impossibility result for all detectors: categorical endpoint pins can contradict on a tree. (c) Residual energy is not a fault count, even after accounting for topology; attenuation and cancellation remain. (d) A comparison with an observer denied endpoint claims cannot establish an advantage over an equally informed sender checker.
**Bit.** sheaf_experiment.py (wrong twice) → sheaf_diagnosis.py (right). Repo: wrong turns at docs/harbor-research/wrong-turns/{sheaf_experiment.py, sheaf_verdict.py}; working proof at skills/harbor-results/scripts/sheaf_mechanism_proof.py; rebuild spec HANDOFF §3.3.

## 3. Zoom's regime, stated or wrong
**Context.** Quantifying adaptive group-split inspection (R4).
**Mistake.** First comparison put k≈F·(2/3) positives inside the flagged set (flag rate 1.5p) — group testing's *worst* case; adaptive "advantage" came out at 0.5× (worse than flat).
**Fix.** Group splitting pays when positives are *sparse in the tested pool*: conservative over-flagging digests (F large, k small). There: 15.3× at F=2500,k=10, tracking k·log₂(F/k).
**Rule.** Every "X beats Y" claim carries a regime; find the regime where it flips and state both. The flip is often the more publishable sentence.
**Bit.** b1_experiment.py v1 vs b1_fix.py. Repo: docs/harbor-research/wrong-turns/b1_experiment.py vs skills/harbor-results/scripts/b1_frontier.py.

## 4. Conventions change the headline number
**Context.** ρ* for the inspection game (R7).
**Fact.** Keep-gain convention: ρ* = G/(dB). Confiscation (capture forfeits the gain too): ρ*_c = G/(d(G+B)) — cheaper. Same game, ~17% different audit budget at the session parameters.
**Rule.** Before quoting an equilibrium threshold, pin the payoff convention to the *actual settlement rule*. Related forks recorded: amortization is Θ(log T) if losses occur only-if-audited but O(1) if cheats independently surface (rate r) — an empirical fork, not a modeling taste.
**Bit.** b2_tower.py derives both; the exemplar write-up states both.

## 5. Mutation-test the checker or it proves nothing
**Context.** Model-checking the work-unit machine (R8) and the sealed room (R9).
**Practice.** A green checker is unvalidated until seeded bugs turn it red: disable each guard / plant each leak and demand a counterexample. R8: all five guards proven critical with shortest crimes (4,2,4,1,7 steps). R9: leaky gate and bypass both caught with witness traces.
**Rules.** (a) Ship the mutation suite with the checker; the suite *is* the checker's certificate. (b) BFS gives shortest counterexamples — human-readable crimes, gold for exposition and debugging. (c) Note which crime needs the longest trace: R8's wrong-principal payout walks the entire legitimate path before the one illegal step — exactly how the fraud would look in production, so the test doubles as a detection playbook.
**Bit.** c0_workunit.py, c1_noninterference.py.

## 6. The schedule is a channel
**Context.** Two-run noninterference checking (R9).
**Insight.** If action *enabledness* depends on the secret, the interleaving structure itself leaks — before any observation content does. Check schedule secret-independence as a separate, prior verification.
**Rule.** In any two-run/purge-style security check, verify control-flow equality across secrets first; only then compare observations.
**Bit.** c1_noninterference.py `structure_check()`.

## 7. Pick mutation witnesses that prove the contract, not just a bug
**Context.** R9's leaky-gate mutation.
**Insight.** The caught witness distinguishes secrets (0,2) — an *equal-parity* pair the honest gate provably keeps identical. That single trace demonstrates "beyond the declared release" precisely, which a (0,1) witness (different parity, legally distinguishable) would not.
**Rule.** Choose/report the counterexample that violates the *contract*, not merely the implementation; it is simultaneously the sharpest test and the best expository example.

## 8. Gate the channel, never the token — proven twice
**Context.** Clean-room security (R5 + R9).
**Insight.** Token-level taint through an LLM is not soundly definable (everything read taints everything written). The compound policy "no egress after reading a secret" is regimentable *because* it permits the uncontrollable read (recording taint) and gates only the controllable egress (R5); two-run equivalence then shows the gate suffices (R9). One design rule, two independent proofs.
**Rule.** For any "prevent X after Y" policy where Y is uncontrollable: never try to forbid Y; record it and gate the controllable consequence. Claims of "mathematically cannot phone home" via token taint are overclaims — the honest claim is "every release is explicit, gated, and bounded."

## 9. Refute before you prove (the ordering that caught everything above)
**Context.** Program-wide discipline.
**Practice.** No bound is formalized until it survives an automated counterexample sweep; no speculative direction (sheaf) proceeds without a pre-registered commit-or-cut gate; wrong turns are *reported* (they locate boundaries — lessons 1–3 exist because of this).
**Rule.** The order is: sweep → gate → prove → mutation-test → expose with boundaries. Details and protocols: the falsification-first skill.

## 10. Super-additivity of split floors (a surprise worth remembering)
**Context.** Joint digests for two readers (R2).
**Fact.** Write F(k)=log₂C(N,k)−log₂C(m,k), with N>m≥2k and k≥1. Then F(2k)>2F(k): the summands log₂((N−i)/(m−i)) strictly increase with i. The numerator-only explanation is false: C(N,2k)<C(N,k)². The floor difference, not that numerator, gives superadditivity.
**Rule.** Cost the jointly required critical set in the declared source/decoder model. This counting comparison does not by itself require separate compaction processes: a common retained representation can have reader-specific decoders. Do not turn a lower bound into an architecture necessity without a matching representation theorem.


## 11. A quieter residual is not a repaired world
**Context.** R6 CR-4 intervention experiments.
**Observation.** Removing a constraint can make a retained-data residual disappear, and replacing a disagreement by zero can make a numerical cochain consistent. Those operations answer different questions: the first changes which evidence is checked; the second changes the evidence value. Neither names an authorized external effect.
**Counterexample.** In the five-edge fixture, greedy severing costs 6 while deleting edge12 costs 5 and leaves a consistent cycle. In the triangle, three zeroings are needed despite beta_1=1.
**Rule.** Report the mode, selected rows, remaining residual, stop status, replacement-observation provenance, authority, and effect receipt separately. A passed special fixture is neither an optimizer proof nor an operational repair certificate.
