# HANDOFF — Harbor Research Program (v2, repo edition)
### Continuity pack. v2 (2026-08-16): converted from session-outputs form to repo-relative form; everything referenced below lives in this repository unless marked (not in repo).

---
## 0. REPO MAP — where everything lives
| Path | What it is |
|---|---|
| `skills/harbor-exposition/`, `skills/harbor-results/`, `skills/falsification-first/` | The three codified skills, incl. all reproduction scripts (`skills/harbor-results/scripts/`), the sweep tool, and the style linter. THE core context: read the three SKILL.md files first, then `skills/harbor-results/references/l3-tacit-lessons.md` in full. |
| `docs/harbor-research/HANDOFF.md` | This file. |
| `docs/harbor-research/mega-volume-editorial-architecture.md` | The collected book's thesis, seven propositions, causal chain, chapter jobs, and editorial admission rules. |
| `docs/harbor-research/mega-volume-epistemic-manifest.yaml` | Stable result ledger: result id, status, claim, conditions, boundary, chapter home, and recomputation evidence. |
| `docs/harbor-research/tex/` | LaTeX sources of every document: `doc1_treatise.tex` (8 corrections + adjudications + re-spine), `doc2_product.tex` (roadmap), `doc3_research.tex` (program), `doc4_papers.tex` (papers 1–8), `review.tex`, `portfolio.tex` (the 18 A/B/C items with proof paths), `exec1/2/3.tex` (executed results), `preamble.tex`. PDFs are intentionally NOT committed — rebuild with `make -C docs/harbor-research docs`. |
| `docs/harbor-research/wrong-turns/` | The four failed formulations (a7 v1, b1 v1, sheaf_experiment.py, sheaf_verdict.py) + README mapping each to its tacit lesson. Kept per falsification-first §5. |
| `docs/harbor-research/research/` | Rescued research reports: `exposition-craft.md` (the nine expository treatments, verbatim), plus extract-stubs `tooling-notes.md` and `sheaf-assessment-notes.md`. |
| `docs/harbor-research/Makefile`, `b1_figure.py` | `make figures` regenerates the three figure PNGs from the skill scripts (seed 20260816); `make docs` compiles the PDFs. |
| `website-v2/public/whitepaper/coordination-papers-mega-volume.pdf` | Canonical rendered collected volume; rebuild from the seven chapter sources with `scripts/build-whitepapers.sh coordination-papers-mega-volume`. |
| (not in repo) `GeminiFeedback.pdf`, `harbor-feedback-and-exercise-solutions.pdf`, `port_daddy_feedback_analysis_v2.pdf` | The three external reviews (user uploads). Attach for W4. |

**Standing directives for every wave prompt below (assume them even if a prompt is trimmed):**
- Clone `curiositech/port-daddy` and run `npm run skills:sync` (adds `-- --scope user` for ~/.claude) so the runtimes discover the skills. Read the three harbor skills' SKILL.md files, then `skills/harbor-results/references/results-compendium.md` for the relevant R#, then `skills/harbor-results/references/l3-tacit-lessons.md` (all 10 lessons — every one prevents a repeated mistake).
- Follow `skills/falsification-first`: sweep before proving; mutation-test any checker; tag every number **[verified]** or **[internal, script, seed 20260816]**; file wrong turns in `docs/harbor-research/wrong-turns/`.
- Write deliverables in the `skills/harbor-exposition` house style; lint with `python3 skills/harbor-exposition/scripts/check_style.py <draft>`.
- Build with `docs/harbor-research/tex/preamble.tex` (see §3.6 traps). Commit sources to the repo; compiled PDFs stay out of version control.

---
## 1. CROSSWALK — Portfolio IDs ↔ exposition R# ↔ papers ↔ scripts ↔ status
(The A/B/C labels come from Provable-Results-Portfolio.pdf; R1–R9 from the exposition work; both appear in documents and neither alone is complete. This table exists nowhere else.)

| Portfolio | R# | Result | Status | Paper | Script |
|---|---|---|---|---|---|
| A7 (+Thm I.6.1) | R1 | Information floor + falsification | done | 1 | a7_experiment.py |
| A1 | R2 | Split-digest (comonotone; 2.13× super-additive) | done (proof in Exec-Rpt 1) | 1 | — |
| A2 | R3 | Derived regret head / SDT fix | done | 1 | — |
| B1 | R4 | R(δ,f) frontier + zoom advantage | done (sim + closed form; **theorem statement of zoom bound still needed**) | 1 | b1_frontier.py |
| B3 | R5 | Hypervisor = RW controllability | done | 2, 4 | b3_controllability.py |
| sheaf gate | R6 | Cycle-vs-cut verdict | mechanism proved; harness REBUILT (W8, gates PASS) | 7 | sheaf_mechanism_proof.py, sheaf_harness_v2.py |
| B2 | R7 | Inspection tower + amortization | done | 3 | b2_tower.py |
| C0 | R8 | Work-unit machine | done (bounded, 536 states) | 8 | c0_workunit.py |
| C1 | R9 | Sealed-room noninterference | done (finite, depth 7) | 4 | c1_noninterference.py |
| A3 | R10 | ε-conservation release ledger (exhaustive interleavings; DP seq + advanced composition) | done (W5) | 4 | a3_epsilon_ledger.py |
| A4 | R11 | Canary power 1−β^k + hypergeometric operating curve + SPRT time-to-detection | done (W5) | 4 | a4_canary_sprt.py |
| A6 | R12 | No-mint inheritance (transfer semantics; closure-sum phrasing refuted; 8.2× mint caught) | done (W5) | 5 / skill-econ | a6_no_mint.py |
| B4 | — | Deontic-conflict fragment | pending | 6 | — |
| B5, B6 | — | Engine substitution; probation cliff | pending | 5 | — |
| B7, B8, B9 | — | Escalation signaling; specialization boundary; context paging | pending, **unscheduled** (§3.9) | 1-adjacent/6 | — |
| C2 | — | Minimum viable take-rate | pending | 4/econ ch. | — |
| C0-lift, C1-lift | — | Apalache; Isabelle unwinding | pending | 8, 4 | — |

---
## 2. WAVE PROMPTS — paste-ready
Each block is a complete prompt for a fresh session working IN THE REPO. Every wave: read docs/harbor-research/HANDOFF.md plus the three harbor skills, then the wave's listed repo paths. Items marked (not in repo) are user uploads to attach. Inline context is included so the prompt degrades gracefully.

### W1 — Assemble Paper 1, "The Price of a Summary" (arXiv)
> You are continuing the Harbor research program (repo: curiositech/port-daddy). Read skills/harbor-results/SKILL.md, compendium §R1–R4, and ALL of l3-tacit-lessons.md. Open in repo: docs/harbor-research/tex/exec1.tex + exec2.tex (source of the executed write-ups); regenerate figures via `make -C docs/harbor-research figures`; and HANDOFF §3.4 (novelty anchors) + §3.5 (numbers).
> Task: assemble the complete arXiv paper from four executed pillars: R2/A1 split-digest characterization (comonotone iff; super-additive joint floor ≈2.13×), R3/A2 derived regret head (likelihood-ratio criterion; reputation only through the posterior), R1/A7 falsification experiment (floor survived 0/16; report the 8/14 meter-bug wrong turn per lesson #1), R4/B1 frontier (closed-form R(δ,f); zero-miss corner R(0)=H(p)=0.286 at p=0.05 [verified]).
> The ONE missing piece you must produce: a clean theorem + proof for the zoom advantage — halving group-splitting identifies k positives inside F flagged items in ≤ 2k·log2(F/k)+O(k) group queries (potential/charging argument); position against Hwang 1972 generalized binary splitting and Du–Hwang; state the dense-flag boundary (lesson #3) and the measured ~2× practical overhead (15.3× observed vs ~31× ideal at F=2500,k=10 [internal]).
> Related-work anchors and the novelty flag are in HANDOFF §3.4 verbatim — use them; do NOT cite the two-constraint program as a textbook theorem. Structure per harbor-exposition; run check_style.py on every section; regenerate both figures from the bundled scripts rather than trusting the PNGs. Deliver: paper.tex + PDF + a 150-word arXiv abstract.

### W2 — Draft Paper 2, "Regimented or Enforced"
> Continue the Harbor program in-repo. Skills: compendium §R5 + lessons #8. Open: docs/harbor-research/tex/exec2.tex; HANDOFF §3.1 (Ramadge–Wonham/Lin–Wonham/Goguen–Meseguer exact citations) and §3.2 (Supremica note).
> Task: full paper draft around the executed theorem — a policy is regimentable (preventable pre-effect) iff controllable w.r.t. Σu = {model_emit_token, in_context_read, internal_plan}: K̄Σu ∩ L̄ ⊆ K̄. Include: (i) relation to Schneider's EM-enforceable = safety properties, with controllability as the refinement over the mediated alphabet; (ii) the policy table (egress/push/write/exec/spawn regimentable; semantic content detect-only); (iii) the compound channel-not-token result ("no egress after secret read" IS regimentable) as the bridge to clean rooms; (iv) an honest partial-observation section (Lin–Wonham observability shrinks the set when policies reference unmediated STATE); (v) one worked Supremica-style synthesis case study (spec it; implement in the bundled checker style if Supremica unavailable). Reproduce the table by running scripts/b3_controllability.py. House style; deliver paper.tex + PDF.

### W3 — Draft Paper 3, "Reputation is Amortized Verification"
> Continue the Harbor program in-repo. Skills: compendium §R7 + lessons #4, #9. Open: docs/harbor-research/tex/exec3.tex; `make -C docs/harbor-research figures` for B2; HANDOFF §3.1 (Becker/Kreps–Wilson/Fudenberg–Levine/Avenhaus citations) + §3.2 (pygambit/PRISM-games pins).
> Task: full paper around the executed tower: ρ*=G/(dB) (state BOTH conventions: confiscation ρ*c=G/(d(G+B)) — lesson #4); sealed sampling from C disjoint cliques, bribery profitable iff G_k>C·B else geometric (1−ρd)^k decay, finite bond certifies unbounded depth; amortization Θ(log T) vs O(1)=aG²/(2dBrv) with the empirical fork (do cheats surface without audits?). Cross-check equilibria numerically in pygambit (pip install pygambit) and, if feasible, a PRISM-games 3.0 model of the stage game; both are verification, the closed forms are the result. Frame the fusion honestly: model heterogeneity supplies the cliques, VRF honeypots implement the sealed audit — neither external review had the theorem. Reproduce all numbers via scripts/b2_tower.py. House style; deliver paper.tex + PDF.

### W4 — Land the eight treatise corrections
> Continue the Harbor program. Attach (not in repo): coordination-papers-mega-volume.pdf (the treatise) and the three external-review PDFs (GeminiFeedback, harbor-feedback-and-exercise-solutions, port_daddy_feedback_analysis_v2). Open in repo: docs/harbor-research/tex/doc1_treatise.tex (the correction spec, buildable) and skills compendium end-section "Treatise-corrections consensus".
> Task: produce a patchset (per-section replacement text, not commentary) landing all eight: (1) replace the non-PD stage game with (T,T)=(3,3),(T,F)=(0,4),(F,T)=(4,0),(F,F)=(1,1), re-derive δ≥1/3, purge every 0.253; (2) restate exact-key uniqueness as a conflict-predicate theorem + add fencing epochs at every effect boundary; (3) replace the identity theorem with the valid conditional + principal-aggregation (the 10/2/0 counterexample goes in as a remark); (4) replace the SDT section with the derived likelihood-ratio criterion from R3 (Exec-Rpt 1 §1 has the full text to adapt); (5) split the float plan into four buckets (requester bounty escrow / provider bond / insurer reserve / fees), returned collateral ≠ income; (6) fix Anchor to per-edge ⊆ checks incl. audience, conditions, quotas, expiry monotonicity + PoP + token IDs + ancestor revocation; (7) per-write durability types {PROCESS_CRASH|POWER_LOSS} with synchronous=FULL for money/authority; replace CREATE-IF-NOT-EXISTS schema-by-union with a PRAGMA user_version migration ledger; (8) scope every cryptographic claim via typed evidence channels + the five assurance levels (observed/coordinated/brokered/confined/attested). Each patch: old text location, new text, one-line rationale citing which reviews converged. Deliver as a single patch document PDF.

### W5 — Quick proofs: A3 + A4 + A6
> Continue the Harbor program. Skills: falsification-first (sweep first), compendium (paper map); open docs/harbor-research/tex/portfolio.tex §A3/A4/A6 for the drafted proof paths.
> Task, three short results in one report (house style each): (A3) ε-conservation of the clean-room release ledger — state machine where release(εi) atomically appends and adds; prove Σspent = Σlog by induction incl. the concurrent-invocation case under single-writer serialization; import DP sequential + advanced composition (Dwork–Rothblum–Vadhan FOCS 2010). (A4) Canary power 1−β^k + Wald SPRT expected time-to-detection; publish the operating curve Pr(detect)=f(leak size). (A6) No-mint inheritance: per-outcome derivation budgets Σ_a w(e→a) ≤ 1 ⇒ total inherited prior ≤ total witnessed value; cycles safe via potential/supermartingale; state explicitly why per-DERIVATION budgets mint infinitely (the k-fork attack). Sweep each inequality with falsification-first/scripts/sweep.py before writing the proof. These feed Papers 4 (A3, A4) and the skill-economy (A6). Deliver Execution-Report-4 PDF + any scripts.

### W6 — B5 + B6: the Chapter-III pair (Paper 5)
> Continue the Harbor program. Skills: compendium §R7 boundary + lessons #4; docs/harbor-research/tex/portfolio.tex §B5/B6; tex/doc4_papers.tex §Paper 5.
> Task: (B5) two-period lemons model with engine qualities θH>θL: without attestation, pooling on θH cannot survive (substitute-after-reputation is profitable at any pooled price above θL's cost) — Akerlof unraveling INSIDE one identity; with daemon-attested engine IDs, reputation on (principal, engine) pairs closes it; then prove resurrection soundness: sanction-respecting reputation preserved across provider migration under (i) credential+continuity-witness verification, (ii) engine attestation in successor outcomes, (iii) open commitments closed or renegotiated with escrow delta. (B6) probation-cliff theorem: minimize honest newcomer burden Σδh^t·g_t s.t. fraudster deterrence Σδf^t·g_t ≥ Gmax with δf<δh; the deterrence-per-honest-cost ratio (δf/δh)^t strictly decreases ⇒ exchange argument ⇒ maximally FRONT-loaded schedule (a cliff, not a ramp — contra Lazear deferred-comp intuition; explain why: here the punishment IS the ramp re-paid after reset). Sweep both; verify B6 numerically over random (δf, δh, Gmax). Deliver Execution-Report-5 + paper-5 skeleton.

### W7 — B4: the tractable deontic-conflict fragment (Paper 6)
> Continue the Harbor program. Skills: compendium (R8 context); docs/harbor-research/tex/portfolio.tex §B4; tex/review.tex Part 4 (the condominium design this serves).
> Task: (i) define L_c = ground Horn clauses + interval resource claims + difference constraints; implement the incremental checker (watched-literal unit propagation; interval tree; Bellman–Ford negative-cycle) with amortized bounds stated; (ii) prove NP-completeness one step outside (disjunctive obligations ⇒ SAT reduction); (iii) completeness-with-regimentation: within L_c every conflict is detected at proposal time, and since acceptance is a mediated write, R5/B3 makes conflicting acceptances regimentable pre-commit. Mutation-test the checker per falsification-first protocol §4 (seed one violation per conflict class, demand shortest traces). Deliver: checker script + Execution-Report-6 + paper-6 skeleton.

### W8 — Rebuild the sheaf statistical harness + prove the consistency-radius theorem (Paper 7)
> Continue the Harbor program. THIS WAVE HAS A DOCUMENTED BROKEN PREDECESSOR. Read, in order: skills/harbor-results lessons #2; HANDOFF §3.3 IN FULL (the autopsy + rebuild spec — the defects are diagnosed there and nowhere else); docs/harbor-research/wrong-turns/sheaf_experiment.py and sheaf_verdict.py (the failures); skills/harbor-results/scripts/sheaf_mechanism_proof.py (the working minimal case).
> Task: (i) rebuild the vector-stalk statistical harness EXACTLY per §3.3's spec (identity/shared-coordinate restrictions, mask-after-computing-g, least-squares completion residual as the detector) and run the topology×adversary matrix (two_path bridge-on-cycle vs single_bridge; 200 trials each) — success gate unchanged: cohomology-only detections in the partition-on-a-cycle regime, ~0 across cut edges, redundant-with-pairwise under full visibility; (ii) prove Theorem: consistency radius of the log presheaf (prefix pseudometric, Lipschitz K=1) = max over compared pairs of prefix divergence, computable O(|E|·L), zero iff no witnessed equivocation — low-risk and publishable regardless of (i); (iii) scope Paper 7 exactly: detection/localization under partial visibility where missing comparisons lie on cycles; complements (never replaces) forensic attribution (Sheng et al. CCS'21); bounded by the abelianization gap (Carù). Deliver: fixed harness + Execution-Report-7 + paper-7 skeleton with the two wrong turns reported as §"how the boundary was found".

### W9 — Lift C0 to TLA+/Apalache
> Continue the Harbor program. Skills: compendium §R8; skills/harbor-results/scripts/c0_workunit.py (the executable spec to translate faithfully — same states, transitions, guards, six invariants).
> Task: write workunit.tla with Apalache type annotations; state Inv1..Inv6 exactly as in the Python checker; check with Apalache (bounded symbolic, then attempt inductive invariants for unbounded parameters: #principals, #grants, journal lengths); port the mutation suite (disable each guard as a CONSTANT flag, confirm Apalache produces a counterexample per mutation — the suite is the certificate, lesson #5). Record any divergence between the Python machine and the TLA machine as a refinement bug. Deliver: .tla files + run log + a short report with the state-count comparison (Python baseline: 536 states, crimes 4/2/4/1/7 steps [internal]).

### W10 — Lift C1 to Isabelle/AFP unwinding
> Continue the Harbor program. Skills: compendium §R9 + lessons #6, #7; skills/harbor-results/scripts/c1_noninterference.py (the finite model); HANDOFF §3.1 (Rushby CSL-92-02; Goguen–Meseguer 1982/1984) + §3.2 (AFP entries: Noce's stateful intransitive noninterference; von Oheimb noninfluence).
> Task: formalize the clean-room transition system in Isabelle building on the AFP intransitive-noninterference entries; domains {D, E, G→E, G→D, pub}, policy D↝G→E↝E and E↝G→D↝D with direct D↝E, E↝D absent; discharge the three unwinding conditions (output consistency, weak step consistency, local respect) per transition class; conclude noninterference modulo the declared g. Keep the finite Python model as the sanity oracle: every Isabelle lemma should have a corresponding exhaustive check there. State the honest scope verbatim from the compendium boundary (possibilistic; timing/termination out of model; gate spec is the residual oracle; bounds channels not minds). Deliver: theory files + report.

### W11 — C2: minimum viable take-rate
> Continue the Harbor program. Skills: compendium paper map; docs/harbor-research/tex/portfolio.tex §C2; tex/review.tex (Myerson–Satterthwaite exercise solutions for the setup).
> Task: uniform-type bilateral trade model; derive the expected VCG deficit of ex-post-efficient trade in closed form (re-derive cleanly, don't just cite); theorem: the platform escapes the MS corner iff expected fee income per trade ≥ expected deficit ⇒ minimum viable take-rate τ* as an explicit function of the value distributions; corollary comparison: under common-value contamination (shared grading oracle), disclosure (information design) beats subsidy — state as a scoped comparison, not a grand claim. Sweep the deficit formula numerically before proving. Deliver: Execution-Report + the econ-chapter section text.

### W12 — Skills activation test + instrumentation spec
> Continue the Harbor program in-repo. Part 1: for each of the three skills run the activation protocol — 5 queries that SHOULD fire it and 5 that should NOT (write them first, then judge each against the description's [What][When]. NOT-for formula); tighten any description that misfires; bump CHANGELOGs. Part 2: write the instrumentation spec for every measured-not-proven parameter the theorems condition on: detection rate d (audit outcomes), the anomaly calibration map g (fit from operator accept/reject vs downstream witnessed outcome — NOT from clicks, per Review-and-Extensions solution 7.5), escalation validation rates (for the B7 tuning band), cross-clique collusion correlation (judge-pair agreement stats), and the amortization fork variable (do cheats surface without audits? — tombstone provenance rates). For each: the event to log, the estimator, the theorem it feeds. Deliver: committed skill updates (bump CHANGELOGs) + docs/harbor-research/instrumentation.md.

### W13 (unscheduled backlog) — B7 + B8 + B9
> Continue the Harbor program in-repo. docs/harbor-research/tex/portfolio.tex §B7/B8/B9 has full proof paths. Task: (B7) costly-escalation signaling — single-crossing threshold equilibrium u*(δ) for the alarm channel; derive the tuning band [δmin, δmax] from alarm-fatigue and miss-risk constraints. (B8) specialization boundary — Erlang-C comparison, sole specialist M/M/1 at μs vs pooled M/M/c at μg; explicit threshold g(ρ,c); include the M/M/1-with-breakdowns corner pricing the succession rule. (B9) context paging — import Landlord k/(k−h+1)-competitiveness for weighted caching on the unpinned region; prove the linear φ-degradation term for a corrupted pin oracle by a charging argument; note φ is shared with R1's forgeable-feature budget. Sweep everything; house style; these slot into Paper 1's orbit (B9), Paper 6 (B8), and the attention-queue chapter (B7).

---
## 3. THE DUMP — knowledge that exists ONLY in this file

### 3.1 Verified citation anchors (exact forms — several correct common miscitations)
Ramadge & Wonham, SIAM J. Control Optim. 25(1):206–230, 1987; and Proc. IEEE 77(1):81–98, 1989. · Lin & Wonham, Information Sciences 44(3):173–198, 1988 (partial observation). · Rushby, "Noninterference, Transitivity, and Channel-Control Security Policies," SRI CSL-92-02, Dec 1992 (a TECH REPORT, not a conference paper). · Goguen & Meseguer, IEEE S&P (Oakland) 1982 pp.11–20; unwinding 1984. · Young, "On-Line File Caching," **Algorithmica 33(3):371–383, 2002** (Landlord; cite the journal, not SODA'98). · Sleator & Tarjan, CACM 28(2):202–208, 1985. · Dorfman, Ann. Math. Stat. 14(4):436–440, 1943. · Hwang, **JASA 67(339):605–608, 1972** (generalized binary splitting). · Du & Hwang, Combinatorial Group Testing, World Scientific 2nd ed. 2000. · Avenhaus, von Stengel & Zamir, "Inspection Games," Handbook of Game Theory **Vol. 3, Ch. 51, pp. 1947–1987**, 2002. · Becker, JPE 76(2):169–217, 1968. · Kreps & Wilson, **JET 27(2):253–279, 1982**. · Fudenberg & Levine, Econometrica 57(4):759–778, 1989. · Lazear, JPE 87(6):1261–1284, 1979. · Spence, QJE 87(3):355–374, 1973. · Myerson & Satterthwaite, JET 29(2):265–281, 1983. · Akerlof, QJE 84(3):488–500, 1970. · Kamenica & Gentzkow, AER 101(6):2590–2615, 2011. · G. Smith, FoSSaCS 2009, LNCS 5504:288–302 (QIF). · Dwork, Rothblum & Vadhan, FOCS 2010 pp.51–60 (advanced composition). · Melara et al., CONIKS, USENIX Security 2015. · Miller & Drexler, both papers in The Ecology of Computation (Huberman ed.), North-Holland 1988. · Sutherland, CACM 11(6):449–451, 1968. · Simon 1971 in Computers, Communications, and the Public Interest (Greenberger ed.), Johns Hopkins. · Goldwasser, Kalai & Rothblum, STOC 2008 pp.113–122. · Irving, Christiano & Amodei, arXiv:1805.00899, 2018. · Elster, Ulysses and the Sirens, CUP 1979. · Abramsky & Brandenburger, New J. Phys. 13:113036, 2011. · Abramsky, Mansfield & Barbosa, EPTCS 95:1–14, 2012 (obstruction is SUFFICIENT not necessary). · Carù, arXiv:1701.00656 (2017) & 1807.04203 (2018) — disproves AMB Conj. 8.1; the abelianization-gap citations. · Abramsky et al., "Contextuality, Cohomology and Paradox," CSL 2015, LIPIcs 41:211–228 (completeness for All-vs-Nothing class). · Hansen & Ghrist, J. Appl. Comput. Topology 3(4):315–358, 2019 (spectral sheaves); SIAM J. Appl. Math 81(5):2033–2060, 2021 (discourse sheaves). · Curry thesis, arXiv:1303.3255. · Robinson, consistency radius, arXiv:1805.08927 (Compositionality 2020). · Sheng, Wang, Nayak, Kannan & Viswanath, "BFT Protocol Forensics," CCS 2021 pp.1722–1743 (impossibility: no forensic support for 2t+1 synchronous BFT even with all replica states). · **Bach, "Sheaf Cohomology is #P-hard," J. Symbolic Comput. 27(4):429–433, 1999 — applies to COHERENT sheaves on projective space, NOT finite cellular sheaves over ℝ (poly-time linear algebra); preempt this referee objection in Paper 7.** · Ghrist–Krishnan topological MFMC, GlobalSIP 2013 — has known duality gaps (tightened in Krishnamoorthy et al., arXiv:2107.04252); cite carefully. · MINGLE, IACR eprint 2026/1010 — in-band gossip KT equivocation detection; the closest existing SYSTEM to the harbor's model; Paper 7's real-world anchor. · Exposition canon: Halmos 1970 L'Enseignement Mathématique; Knuth-Larrabee-Roberts 1989; Sweller & Cooper, Cognition & Instruction 2(1):59–89, 1985; Kalyuga et al. 2003 (expertise reversal); Renkl & Atkinson 2003 (fading); Gentner, Cognitive Science 7(2):155–170, 1983; Camerer-Loewenstein-Weber, JPE 97(5):1232–54, 1989; Strogatz, Notices AMS 61(3):286–291, 2014.

### 3.2 Toolchain facts & pins (from the Aug-2026 tooling survey — chat artifact, else lost)
- **Mathlib has NO Shannon entropy, mutual information, rate-distortion, or coding theorems** — only KL divergence (`klDiv`) and Hamming. Entropy/MI exist only in the external PFR project, not upstreamed (confirmed via Degenne arXiv:2510.04070). Route info-theory mechanization to Isabelle's HOL entropy (Mhamdi–Hasan–Tahar, ITP 2011) or budget a PFR port.
- **PRISM-games 3.0** (CAV 2020) is the checker with turn-based AND concurrent stochastic-game equilibria (rPATL); **Storm does not natively take stochastic games**. Apalache has a JSON-RPC server API for headless driving. Supremica for RW synthesis (Java, batch mode); TCT/libFAUDES alternates.
- Version pins seen Aug 2026 (re-verify at build): Z3 5.0.0; cvc5 1.3.4; Gambit 16.7.0 + `pip install pygambit` (enummixed/gnm/logit solvers); Manim CE 0.21.0; Typst 0.14.2; Penrose headless via Node `@penrose/core` (compile→optimize→toSVG). Z3's nlsat is complete for existential reals — the cubic/threshold checks.
- **PySheaf cannot compute cohomology** (maintainers' own release note) — consistency-radius track only; hand-roll coboundaries in numpy.
- LLM provers: Goedel-Prover-V2 (open, ~88–90% MiniF2F), DeepSeek-Prover-V2, Harmonic Aristotle (public API, `pip install aristotlelib`). Policy: proof-SEARCH only, kernel-checked output only, and human-review every Lean STATEMENT (autoformalization can prove the wrong theorem).
- Claim-type routing: algebra/roots → Z3/cvc5 or numpy sweep; finite games → indifference checks/pygambit; audit schedules → pointwise deviation ≤ 0; safety/protocol → Python BFS then Apalache; info bounds → build the frontier, attack with an oracle.

### 3.3 SHEAF STATISTICAL-HARNESS AUTOPSY (todo W8's real content; the working minimal proof is sheaf_mechanism_proof.py; the broken wrapper is wrong-turns/sheaf_verdict.py)
**Symptom:** in the wrapper (docs/harbor-research/wrong-turns/sheaf_verdict.py), full-visibility scenario showed 0 redundant detections (should be ~200: pairwise must fire when an equivocator perturbs compared edges) and 0 cohomology-only detections everywhere — coh signal wasn't tracking injected inconsistency at all.
**Diagnosed defects (in my head only until now):**
- **D1 — restriction maps kill coker.** Per-edge random orthonormal S×D projections (S=3, D=6) make the coboundary δ generically SURJECTIVE once edges are plentiful ⇒ coker(δ)=0 ⇒ harmonic space empty ⇒ signal ≡ 0 regardless of data. The scalar minimal case works precisely because identity restrictions give coker = cycle space. **Fix:** restrictions must be coordinate-subset selections (shared-prefix coordinates), or scalar/low-d stalks, so coker(δ) ≅ (cycle space) ⊗ (shared coords) and carries the cocycle constraints.
- **D2 — masking applied inconsistently.** `pairwise` was computed from the FULL disagreement cochain g (before removing uncompared edges) in some paths, and the coh signal never modeled the uncompared entries as unknown — it projected a g that silently contained the "hidden" edge's value. **Fix:** compute g only on compared edges; treat uncompared blocks as free variables.
- **D3 — wrong detector under partition.** The correct statistic when some edges are unobserved: does ANY completion of the unknown entries make g a coboundary? i.e. residual r = min over (x, free blocks) of ‖g_known − (δx)|_known‖; equivalently, project the known-edge vector onto the orthogonal complement of {(δx) restricted to known edges}. r > 0 ⟺ cocycle obstruction visible from the observed edges alone. (On a cut edge the free block absorbs everything ⇒ r = 0 always — which is exactly the honest boundary, now falling out of the algebra.)
**Rebuild spec:** stalks ℝ^d, restriction = selection of shared coordinates per edge; equivocator = per-neighbor offset vectors on its reports (so around any cycle through it, offsets don't cancel); observed g on compared edges only; detector = the least-squares completion residual r; localization = support of the minimizing residual vector; baseline = pairwise on compared edges; run two_path (two bridges ⇒ severed bridge lies on a cycle) vs single_bridge (cut edge), 200 trials, plus expander with random uncompared edges. Success gate unchanged from the assessment: cohomology-only detections in partition-on-a-cycle; ~0 on cut edges; redundant under full visibility. Expected counting caveat: net out topological β₁ per lesson #2.

### 3.4 Paper-specific gaps & novelty anchors (verbatim-usable)
- **Paper 1 novelty flag:** an Aug-2026 survey found NO prior "one-sided / false-negative-constrained rate-distortion for binary sources" under that framing. Nearest neighbors to position against (not to claim as ancestry): expansion coding with one-sided error, arXiv:1308.2338 (continuous exponential/Laplacian sources); "Rate-Distortion-Classification Representation Theory for Bernoulli Sources," arXiv:2601.11919 (2026) and the related IEEE ITW 2025 universal-RDC line. Treat the two-constraint R(δ,f) as a custom formulation; do a final lit-sweep before claiming novelty ("not found" ≠ "proven nonexistent").
- **Paper 1 closed-form note:** with X~Bern(p) and both constraints binding, the 2×2 joint is fully pinned: q11=p−δ, q10=δ, q01=f−(p−δ), q00=1−f−δ, feasible iff all ≥0 — the "closed form" IS this pinned joint's mutual information; the minimization argument is one paragraph (any slack in a constraint only lowers I by moving toward independence along a feasible ray). B1 Panel-B's slight uptick near δ/p→1 is NOT real constraint-geometry: it's the pinned closed form evaluated past its own domain of validity (f<1−δ/p); within that domain R falls exactly to 0. Corrected in paper1.tex and exec2.tex; found during the Paper 1 editorial pass (2026-08-24).
- **Paper 2:** frame Schneider's "EM-enforceable = safety" as the ambient result and RW controllability as the refinement once the alphabet is split into mediated/unmediated; the product reviews' "pure function of committed DB state" is the special case Σc = DB writes.
- **Paper 3:** amortization Model A (loss only-if-audited) ⇒ ρt = G/(d(B+vt)) ⇒ Θ(log T); Model B (independent revelation rate r) ⇒ O(1) with t* = G/(rv) and closed form aG²/(2dBrv); at the session parameters t*=333 > T=200 so the O(1) curve hadn't saturated at 35.08 (limit 41.67) — say so or a referee will.
- **Paper 7:** open with the Sheng et al. impossibility as the boundary pairwise/forensic methods provably cannot cross; cohomology's pitch is triage/localization INTO that gap, never attribution; MINGLE is the systems anchor; Bach #P preempt (§3.1); Carù caveat: non-vanishing is a sufficient alarm, vanishing over ℝ is NOT an all-clear.
- **Paper 4 remaining pieces beyond C1:** A3 + A4 (W5) and the leakage budget framing (q·b bits across q jobs before timing channels — from the Harbor-After-the-Harbor review, adopted in Doc 1 Adjudication 3).

### 3.5 Numeric master table (tags: V=verified/recomputable, I=internal seed 20260816 + script)
Floor B*(N=60,k=2,m=8)=5.98 bits [V]; disjoint-readers floor 12.77 [V]; ratio 2.13×, super-additivity 1.067 (band 1.05–1.08 across regimes) [V]. A7: 0/16 oracle violations; wrong-turn v1: 8/14 spurious [I, a7]. R(δ,f) @p=.05: (0,.05)=.286 [V, =H(.05)]; (0,.10)=.186; (.01,.10)=.110; (.04,.06)=.009 [I, b1]. Zoom: 15.3× @F=2500,k=10 (ideal 2k·log2(F/k)≈? — k·log2(F/k)=79.7 ⇒ ~31× ideal ⇒ ~2× practical overhead) [I, b1]. ρ*=0.25, ρ*c=0.2083, q*=0.03125 @(G,d,B,a,L)=(10,.8,50,1,40) [V]; tower C=1: 400→390→380 (bleed = C·β = 10/level); C=8: ×0.8/level from level 1 [I, b2]; geometric-regime levels-to-<1 = 27, bond capital 27·50=1350 [V arith]. Amortization spends @T=200: flat 50.00, log 25.58 (closed 25.50), O(1) 35.08→41.67 [I/V]. C0: 536 states; crimes 4/2/4/1/7 steps [I, c0]. C1: depth 7 exhaustive; leaky-gate witness secrets (0,2) equal-parity; bypass 3 steps [I, c1]. Sheaf: C6 signal 1.225 vs P6 cut-edge 0.000 [I, sheaf_mechanism_proof].

### 3.6 Environment & LaTeX conventions (traps included)
- pdflatex available; **microtype and lmodern are FATAL in this container** (font-expansion "auto expansion is only possible with scalable" / missing lmodern) — the working preamble omits both; xcolor must load before hyperref color options. Compile twice for refs. mdframed environments: `thebox` (blue!4 bg, harborblue frame) for statements, `boundary` (red!4, shipred) for limits — color semantics are program-wide. Palette: harborblue RGB(30,70,110), shipred (140,30,30), seagreen (20,90,70). Full preamble: session-sources zip tex/preamble.tex.
- Python: pip installs fine (PEP-668 hint is noise); numpy/scipy/matplotlib/networkx used; seed convention 20260816 everywhere; figures at dpi=150 bbox_inches='tight'.
- Skill validator: in-repo at skills/skill-architect/scripts/validate_skill.py. Scripts in skills need shebangs or the validator suggests them.
- In chat sessions, deliverables go to /mnt/user-data/outputs and must be presented; for repo work, commit instead — a file not committed is chat-state, and chat-state dies.

### 3.7 Honest caveats & open threads written nowhere else
- **A7 Panel 2 (feature corruption φ) is visually compressed** at m=8 — the budget is generous enough that corruption barely moves miss rate in-range; rerun with tighter m for a publication figure.
- **A7's "noisy encoder" (SNR≈1) barely beats random** at N=60,k=2 with codebook scoring — not a bug (the floor claim needs only the oracle), but don't present it as evidence noisy digests are near-optimal.
- **B2's exact-indifference outputs (+0.000000, max deviation +1.78e-15)** are machine-epsilon zeros; phrase as "≤0 up to float epsilon".
- **R4 formulation flag** (also in exposition audit): the two-constraint objective is custom, not Cover–Thomas; only the (δ=0) corner coincides with H(p).
- **C0's settle(p2!) mutation** required walking the full legitimate path (7 steps) — reuse as the production fraud-detection playbook example.
- **Chat-artifact rescue status:** artifact (3) below is now in-repo at docs/harbor-research/research/exposition-craft.md (nine treatments verbatim + caveats); (1) and (2) exist only as extracts (HANDOFF §3.1–§3.3 + research/*-notes.md stubs) — their full texts remain chat-only: (1) "Multi-Agent Coordination Theorem-Proving Stack: State of the Art (August 2026)"; (2) "Sheaf Cohomology for Federated Witness-Log Systems: Literature Review, Assessment, and Prototyping Plan"; (3) "The Craft of Technical Exposition: Seven Moves Plus Two Rails and Nine Harbor Applications". §3.1–3.3 extract the decisive content of (1) and (2); rescue their full texts (esp. the sheaf experiment matrix) into research/ when convenient.
- **Exposition template revisit-triggers** (pre-registered): drop the express lane's prominence if experts read linearly anyway; simplify figure grammar if >~2h/figure; fold misread-line into Move 7 if usually empty.
- **Product-side numbers to never overclaim:** the assurance-level ladder means hook/MCP integrations are level 2–3; "level 4 confined" claims require the hypervisor + a red-team pass of the enumerated channel set (raw sockets, DNS, /proc, inherited FDs, git helpers, package managers, child processes, clipboard, provider callbacks).

### 3.8 Reminder-list state
15 "Harbor:" items live in the default Reminders list (created 2026-08-16), matching waves W1–W12 (W13's B7/B8/B9 are NOT in reminders — add if scheduling them).

### 3.9 Unscheduled backlog one-liners (proof paths in Portfolio PDF)
B7 escalation signaling (single-crossing threshold; tuning band from measured validation rates). B8 specialization boundary (Erlang-C; breakdowns corner prices succession). B9 context paging (Landlord import + linear φ-degradation; φ shared with R1's forgeable-feature budget).

---
## 4. DELTA v3 (2026-08-19) — PR #7698 reconciled in-session
- The treatise is now **in-repo and canonical**: sources at `whitepaper/` (legible-swarm, single-writer-kernel) and `website-v2/public/whitepaper/` (five papers + mega volume); the PAPERS table in `scripts/build-whitepapers.sh` is authoritative. W4-style edits target these files; the mega-volume PDF attachment instruction is obsolete.
- **W4: done-pending-verification** (verification ledger: `pr7698-reconciliation.md`, same directory — corrections table, adjudications, follow-ups F1–F4).
- **W14: executed in-session** (merge + adjudications + One Spine appendix). The One Spine appendix in the mega volume is now the admission test for any new mechanism: name your theorem family, your developer obligation, your boundary — no row, no feature.
- **Proof debt is now blocking**: A3/A4 (asserted in the volume's cleanroom theorem), B5, B7, B8, B9; B6 discharged-as-sketch. **Revised wave order: W5 → W6 → W13 → W1–W3 → W8 → W9/W10.**
- New tacit datum for the results skill: the duplicate-generator collision (#6368 vs #7698) — an unfiled exact-key claim conflict inside the project's own repo.

---
## 5. DELTA v4 (2026-08-23) — #9450 omnibus, artifact rescue, next-session plan
- **Merged head under review:** the reconciliation (24052b84d) is pushed to `purser/pr-7278-tests` = PR **#9450**, now the omnibus publish vehicle. CI is red on that head with three diagnosed causes; the fix list and full resume plan live in `docs/harbor-research/plan-2026-08-23-merge-and-resume.md` (Part 0 = land #9450; Parts 1–7 = resume the program in ledger wave order W5 → W6 → W13 → W1–W3 → W8 → lifts).
- **F4 partially discharged:** `pdf/Sheaf-Cohomology-Lit-Review-Assessment-Prototyping-Plan.pdf` (the W8-gating artifact — experiment matrix, Stage-1 COMMIT/CUT gates, three theorem candidates) and `pdf/The-Harbor-After-the-Harbor.pdf` (the rigor review behind doc1's adjudications; correctness audit + full exercise solution key + build sequence) are now committed, user-supplied renders. Only the theorem-proving-stack SotA report remains extract-only (§3.2).
- **Stale-mechanization finding — RESOLVED, verified 2026-09-14. Do not act on this; it is kept as history.** As written on 2026-08-23 it read: *"CI's `proofs.yml` still green-gates the VOID δ\*≈0.2531 game — `proofs/economics/delta-threshold.z3` (cubic 3δ³+3δ²+3δ−1), `claim_signaling.tla/.cfg` (old bimatrix, DeltaNum=26), `sweep-delta.sh`, and `website-v2/src/pages/whitepaper/HowWeProveGameTheory.tsx` — while the corrected treatise (2δ³+2δ²+2δ−1=0, δ\*≈0.3423, grim δ≥1/3) cites those files as its mechanization (agent-transactions:801) and its own §1402 table still says 'IC holds at δ=0.26'. Sync all surfaces together (plan Part 2). Also: B6's '0/4000 dominating schedules' number has NO generating script anywhere — write it."* Every surface it names was since corrected, each re-checked on 2026-09-14: `delta-threshold.z3` carries `2δ³+2δ²+2δ−1=0` and proves the root unique in [0.34, 0.35] at δ\*≈0.3425080314; `claim_signaling.tla` carries the genuine PD payoffs (3,3)/(0,4)/(4,0)/(1,1); `claim_signaling.cfg` is DeltaNum=35, not 26; `sweep-delta.sh` sweeps δ ∈ {0.30…0.40} and expects the crossover at ≈0.35, citing δ\*≈0.3425; `HowWeProveGameTheory.tsx` prints δ\*≈0.3425 throughout; and the treatise carries 0.3425080314 with no surviving "IC holds at δ=0.26" table. B6's number now has its generating script — `skills/harbor-results/scripts/b6_probation.py` (`N_INSTANCES = 4000`, random domination search), wired into the `harbor-results-estate` CI job. The only surviving mentions of 0.253 are ledger and critique records that correctly describe it as void; `docs/research/north-star/doctrine/game-theory.md` is the model for how to cite it.
- **Note:** §0's "PDFs are intentionally NOT committed" is stale — commit bfc49dda1 committed all nine analysis PDFs (plus these two rescues); README.md:4 has the same stale line.

---
## 6. DELTA v5 (2026-08-24) — W5 + W8-core executed
- **W5 done**: A3 (R10), A4 (R11), A6 (R12) — scripts + Execution Report #4 (`tex/exec4.tex`, Makefile TEXS updated), compendium/SKILL entries added. A6's portfolio phrasing was REFUTED by the sweep (γ>1/2 full-weight chains mint under budgets-without-debit; closure sum 2.44>1) and restated with transfer semantics — the sweep-first discipline locating the correct statement again. With A3/A4 executed, mega-volume `thm:cleanroom` claims 2–3 are upgradeable from "short and scheduled" (follow-up tex edit, appendices ~line 211).
- **W8 core done**: `sheaf_harness_v2.py` — completion-residual detector; pre-registered gates PASS, verdict COMMIT. Key design finding: the spec's "uncompared" conflated RELAYED (reports gossiped, check never ran — detectable on cycles) with SEVERED (no data — free block, provably dark); the three-tier visibility model (compared/relayed/severed) is now the observability contract for Paper 7. D1/D2 reintroduction mutants caught; cut edges silent at float epsilon; v1's cut-edge "detections" confirmed as D2 artifacts. Consistency-radius theorem + Paper 7 assembly remain (W8 tail).
- **Proof debt after W5**: blocking before arXiv: **B5, B7, B8, B9**; B6 discharged-as-sketch. Wave order: W6 → W13 → W1–W3 → W8-tail → W9/W10.

---
## 7. DELTA v6 (2026-08-24) — the papers are written; folds applied
- **Papers 1–4 drafted as arXiv-style sources** (`tex/paper{1,2,3,4}.tex`, Makefile TEXS updated; canon figures included via graphicspath): Paper 1 "The Price of a Summary" (R1–R4 + the NEW zoom theorem — W1's missing piece PROVED: Q ≤ 2k⌈log₂(F/k)⌉+4k with exact tightness at F=4096,k=32 → 511; verified by zoom_bound_check.py, now in the estate CI job); Paper 2 "Regimented or Enforced" (R5, full two-direction proof, supC(thought-ban)=∅ corollary); Paper 3 "Reputation is Amortized Verification" (R7, convention fork + non-saturation caveats stated); Paper 4 "The Sealed Harbor" (R9+R5+R10+R11 four-pillar assembly, q·b leakage budget, honest-refusal list). All pass check_style.py 7/7. B1's "theorem statement of zoom bound still needed" crosswalk debt: DISCHARGED.
- **Treatise folds** (website-v2 chapters): thm:cleanroom claims 2–3 → executed (a3/a4 scripts); spawn-to-person gains the no-mint status note (refuted-phrasing wrong turn reported) and the b6_probation.py citation; federated-harbor sheaf theorem gains the harness-COMMIT status note (three-tier visibility). Chapter PDFs regenerate in CI; pins resync after (F3 cycle).
- **Remaining before arXiv**: B5 (Paper 5), B4 (Paper 6), B7–B9; W8-tail (consistency-radius theorem, Paper 7 assembly); lifts W9/W10. PDFs of papers 1–4 render via `make -C docs/harbor-research docs` where TeX exists (none in this container).

---
## 8. DELTA v7 (2026-08-24) — the blocking register runs dry
- **W6 + W13 + W8-tail + B4 executed in one six-prover round**: B5 (R13, `b5_engine_substitution.py` — unraveling inside one identity, IC flip under attestation, resurrection soundness with 4 shortest-crime mutants), B7 (R14, `b7_escalation_band.py` — threshold equilibrium + two-walled tuning band, empty-band regime exhibited), B8 (R15, `b8_specialization.py` — the whitepaper's proposed specialization threshold FALSIFIED both directions; exact Erlang-C boundary g(ρ,c) + succession price D*), B9 (R16, `b9_context_paging.py` — Landlord import vs exact OPT + linear φ-degradation, repair-on-touch required for the bound), B4 (R17, `b4_deontic_fragment.py` — polynomial witness-producing conflict checker + NP-complete frontier via verified 3-SAT reduction), consistency radius (`sheaf_consistency_radius.py` — CR-1/2/3: r is the exact minimum lie, localizes to cycles through the equivocator, computes as ≤L Laplacian solves; the R6 1.2247 number has closed form 3·√(1−5/6); coalition cancellation located as the honest scope).
- **Blocking-before-arXiv register (A3, A4, B5, B7, B8, B9): CLEAR.** Compendium now R1–R17 + the CR theorem block; Execution Report #5 (`tex/exec5.tex`, style gate 7/7); all six scripts added to the harbor-results-estate CI job (now 19 scripts).
- **Whitepaper folds now owed (from these results)**: thm:specialization at legible-swarm.tex:868 must adopt the exact g (the current statement is refuted — tex draft in R15's provenance); context-paging thm (~line 1549) and escalation §951/1449 upgrade "proposed" → executed; B5/B7 Status lines gain ledger-code citations.
- **Next: Papers 5–7 assemblies** — Paper 5 "Continuity Without Metaphysics" (R12+R13+B6), Paper 6 "What Needs an Authority" (R17+R15), Paper 7 "Cohomology of Equivocation" (R6+harness+CR). All inputs in hand; house style per papers 1–4.
- Tacit datum: three provers wrote scripts into the tree while the orchestrator was mid-audit — the skill-hygiene "every script indexed" gate fired each time and was satisfied with in-progress bullets finalized at integration; adopt "index at landing, finalize at integration" as the pattern.

---
## 9. DELTA v8 (2026-08-24) — all seven papers drafted
- **Papers 5–7 written** (`tex/paper{5,6,7}.tex`, Makefile TEXS updated; all 7/7 on the style gate; new canon figures paper6_*/paper7_*/r13_regime/b6_figure via figures/src/paper{5,6,7}_figures.py, figlint clean): Paper 5 "Continuity Without Metaphysics" (R12 no-mint + R13 unraveling/IC-flip/resurrection + B6 probation cliff — "not a soul but a ledger position"); Paper 6 "What Needs an Authority" (R17 fragment/frontier + R15 boundary/succession, the authority inventory priced); Paper 7 "The Cohomology of Equivocation" (R6 mechanism + harness COMMIT + CR-1/2/3, boundary section is decisive). With Papers 1–4 (delta v6), the paper program's writing phase is COMPLETE — all seven drafted from executed results.
- **Compendium accuracy fix** (caught by Paper 6's author at assembly): R15's succession numbers conflated two script instances — W=1.376 (μs=10⁸ still-loses test) occurs at ξ/η=1.5·D*, while ξ/η=2 is the mutation canary. Corrected. Lesson: paper assembly re-verifying against scripts is itself a check layer.
- **Next**: whitepaper folds owed from R14–R17 (thm:specialization exact g; paging/escalation upgrades; B5/B7 Status lines), C2, lifts (Apalache/Isabelle), instrumentation.md (W12), F1/F5; PDF renders of papers 1–7 + exec5 happen in the CI TeX container (no local TeX), then the F3 pin-resync cycle if pins move.

---
## 10. DELTA v9 (2026-08-30) — the research becomes one book
- **One thesis now governs the collected volume:** autonomy scales only when authority, evidence, and consequence remain coupled at every effect boundary. The seven papers now serve seven propositions in one causal chain: supervision cost; local effect control; durable accountability; separated exchange instruments; monotone delegation; institutions for residual uncertainty; and federation without transferred sovereignty.
- **The PDF archive is no longer the editorial index.** `mega-volume-epistemic-manifest.yaml` records 21 durable result families, including the R6 counterexample and the verified current Relay boundary. `mega-volume-editorial-architecture.md` maps those results into chapter jobs, handoffs, evidence types, and admission rules.
- **The collected source now owns its seams.** Every chapter receives a short opening that names the question and result ids, plus a handoff that says what the next chapter may assume and what remains unresolved. The introduction states the book's seven propositions; the appendices now contain only the implementation boundary, result atlas, and notation.
- **Editorial illustration is out of this edition.** Jacket, chapter-plate, coda, speculative-expansion, condominium, and clean-room material no longer render in the collected book. Art assets remain available for a later, separately judged edition.
- **Current Relay scope was checked against source.** Relay v0 transports authenticated events over outbound HTTPS/SSE. It is not daemon-state replication, global consensus, local effect authorization, end-to-end secrecy, a witness log, or a settlement institution.

---
## 11. DELTA v10 (2026-09-07) — outside literature review credited into the canon
Four independent outside reviewers were pointed at the Book, one per part, and told to
search the live literature for prior work behind every formal idea, ignoring the Book's own framing. Their four write-ups live
at `docs/harbor-research/exposition/literature/README.md`, `part-I-ground-truth.md`, `part-II-cost-of-seeing.md`,
`part-III-what-survives-the-restart.md`, and `part-IV-trade-between-strangers.md` on the `research/literature-review` branch
(Part I landed after Parts II–IV, in a second pass on the same wave): a verdict per idea (firm / known result
restated / novel / contested), a `[verified]`-or-`[unverified]`-tagged Prior Work list, a reading list, and a closing table of
the Book's private coinages against the public terms the fields already use. The reviews found no theorem wrong as stated;
what they found was missing canon. This wave (`wave-16/credit-the-canon`) closed the citable gaps: it added the missing
`\cite`/`\bibitem` pairs at the sentence where the Book states each idea (propagated to the research-paper twin per the
twin rule, `LIBRARY-SYSTEM.md` §2/7, when the section is folded), named the public term before the Book's private one where
the closing tables called for it (e.g. "level of automation" before "auto-land grant," "algorithms with predictions" before
"context paging with a corrupted pin oracle," the fencing token before the fencing epoch, self-composition before "run the
world twice"), added the one-sentence reframing of the deontic fragment against Colombo
Tosatto/Governatori/van Beest's compliance-checking dichotomy the Part IV review recommended, placed the five-rung assurance
ladder beside Sheridan's levels of automation and the Common Criteria's evaluation assurance levels, and verified the
Liu–Skrzypacz venue correction the reviews flagged was already applied. Every finding is logged as a row in
`docs/harbor-research/critique-ledger.json` / `CRITIQUE-LEDGER.md` under ids `LR-1xx` (Part I), `LR-2xx` (Part II), `LR-3xx`
(Part III), and `LR-4xx` (Part IV) — see the ledger's "Outside literature review" section for the full per-idea disposition
(`DONE`, or `DECLINED` with the reason: already fully cited, no citable source exists, or a self-reported open item in the
Book itself). No theorem statement, number, or label changed.

---
## 9. WHAT TO DO NEXT — written 2026-09-08, for whoever picks this up cold

Four things landed today that are only half-useful until somebody else uses
them. Each one is written here as a job with a first command, because the
failure mode for all four is the same: they sit there, correct and unread, and
the next agent solves the problem they already solve.

### 9.1 `pd roadmap push` exists now. Somebody has to run it, on a schedule.

`lib/roadmap-mirror-push.ts` + `pd roadmap push` fill the relay's roadmap mirror
(`apps/relay/src/roadmap-mirror.ts`, migration `2026-08-22-roadmap-mirror.sql`,
applied in staging). That mirror shipped in August as "PR 1 of 4" and **nothing
ever pushed to it** — PR 2 was never written — so it was a well-tested empty
table for a fortnight, and every reader built since went and found the roadmap
somewhere else instead. That is the shape of failure to watch for here: the
storage is convincing enough that people assume the pipeline exists.

The job: run it on `git:committed`, the way `scripts/export-roadmap-snapshot.ts`
was always meant to be run — its own docstring names "a `pd-fleet.yml`
Cartographer trigger" as the intended automation and nobody built that either.
Same trigger, both verbs.

    pd roadmap push --dry-run          # prints source, item count, bytes, age
    pd roadmap push                    # needs `pd account login` first

**The one invariant not to break.** `generatedAt` is the DAEMON's clock and it
travels with the data, so a fallback push of a fortnight-old committed snapshot
arrives in the mirror reading as a fortnight old. Re-stamping it with
`Date.now()` is a one-character "fix" that turns the only staleness signal the
mirror has into a lie. Two tests in `tests/unit/roadmap-mirror-push.test.js`
hold that line; if one of them ever looks like an obstacle, it is not.

### 9.2 The Work Register is PR 3 of 4. Say so, and finish it.

`apps/relay/src/work-register.ts` now reads `roadmap_mirror_items` rather than a
`work_registry_cache` of its own (that table and its meta table are gone, along
with the GitHub round trip and the `refresh` verb, which answers 410 with the
command). The register was built beside the roadmap programme without either
knowing about the other; now they share a table, and the honest move is to stop
treating them as two projects. `docs/reports/relay-roadmap-mirror/MANIFEST.md`
says the board pages were PR 3 — the register IS those pages.

What is left:
- The site surface. The author asked for "an API only my account can talk to,
  and a web viewer only I can see". The mirror is account-scoped, so that is
  already the shape; `/register?repo=owner/name` is the page.
- The limitation, which is written into `2026-09-08-work-register.sql` where the
  deleted tables used to be: claims are per-repository and shared, the registry
  half is per-account. One operator with many agents is one set. Two operators
  are not. Do not "fix" this by reaching around the mirror's tenancy rule —
  `apps/relay/tests/roadmap-mirror.test.ts` asserts a cross-account read is a
  404 and that assertion is correct.

### 9.3 `\ifpdbook` is the tool for every Book/paper divergence from here on.

Declared in `figures/pd-hyperlinks.tex` (false), set true in the Book preamble
immediately after that file loads. Not a two-argument macro — the generator
inlines every `\input`, so a figure branch is a whole table environment and a
macro argument is scanned as one token list whether or not it is used. Not
guarded with `\ifdefined` either: a conditional token inside skipped text counts
as a nested `\if` and desynchronises `\fi` matching. Ordering is cheaper than
cleverness, and the three failed attempts are written out in commit `76d18bf82`
so nobody has to rediscover them.

Use it whenever a chapter and its standalone twin should say different things.
The next instance is already known: `thm:fh-escrow-bound` is stated in BOTH
chapter 6 and chapter 8 under two numbers, and `check_duplicate_figures.py`
catches duplicated drawings but nothing catches a duplicated theorem.

**Whoever generalises that checker: read only the `\ifpdbook` branch**, the way
`check_duplicate_figures.py` already does, with a scanner rather than a regex —
the branches contain prose and nested `\ifnum` from other macros.

### 9.4 One D1 test adapter, and it earned its keep in ten minutes.

`apps/relay/tests/helpers/d1-sqlite.ts` is now the only D1-over-`node:sqlite`
adapter; `roadmap-mirror.test.ts`'s `makeRealDb` delegates to it. Use
`applyAllMigrations()`, not `migration('one-file.sql')`. A suite that loads a
single migration is testing a schema that has never existed anywhere: the table
is there but the foreign keys pointing at the rest of the database are not, so a
constraint that bites in production cannot bite in the test. Switching the
register's surface suite over immediately caught two rows production would have
refused — a `users` insert with no `github_user_id` and no `created_at`, and a
`work_board_members` row pointing at a user id that did not exist — both of
which had been passing green.

### 9.5 The half-fix, as a habit rather than an anecdote

Twice today a correct-looking fix was half of one, and both halves cost a CI
round trip:

- Chapter 6 stopped re-inputting drawings chapters 7 and 8 develop. True, and it
  silently removed five figures from `harbor-economy-whitepaper.pdf`, a
  submission artifact whose reader has no other chapters to be pointed at.
- The five atlas rows for those figures were deleted. Also true at the time, and
  wrong within a day, because the figures never left the corpus — they moved
  into the `\else` branch.

The generalisable check, which does not exist yet and should:
**no edit to a twin source may change the standalone paper's figure count.**
Both failures would have been caught at the desk instead of in CI.

**Superseded — do not build that check.** It was built
(`check_standalone_figures.py`), and it has since been retired along with the
thing it protected: the eight per-chapter PDFs are gone and the Book is the one
document, so no chapter source is a twin any more and there is no second figure
count to preserve. The half-fix lesson stands as a habit; this particular
instance of it does not. The Book-side half — a drawing must not print twice —
is still enforced, by `check_duplicate_figures.py`.
