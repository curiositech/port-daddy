"""
swarmsheaf: split-view lie detection for agent swarms via sheaf residuals on the clique complex.

Model
-----
- Agents V, undirected channels E (stored oriented u<v).
- Facts: named, finite-valued. Each agent may report a claim about a fact on each channel.
- Message m[(v,u)][f] = value that v told u about fact f.
- Edge cochain (one-hot per fact): g_e[f] = onehot(m[(v,u)][f]) - onehot(m[(u,v)][f]) for e=(u,v), u<v.
  Norm is 0 (agree) or sqrt(2) (disagree). Facts absent on either side are skipped.
- Residual r = || (I - B B^+) g ||_2  (Paper-7 / CR-1).
- 2-cells: the clique (flag) complex -- every triangle of the channel graph is a face.
- Hodge split of the inconsistency rho = g - grad into curl (im d1^T) and harmonic (ker L1).
"""
import itertools
import numpy as np


class Swarm:
    def __init__(self, n, edges):
        self.n = n
        self.edges = sorted({(min(u, v), max(u, v)) for u, v in edges})
        self.eidx = {e: i for i, e in enumerate(self.edges)}
        self.adj = {v: set() for v in range(n)}
        for u, v in self.edges:
            self.adj[u].add(v); self.adj[v].add(u)
        self.tris = [(u, v, w) for u, v, w in itertools.combinations(range(n), 3)
                     if v in self.adj[u] and w in self.adj[u] and w in self.adj[v]]
        m = len(self.edges)
        self.B = np.zeros((m, n))
        for i, (u, v) in enumerate(self.edges):
            self.B[i, u] = -1; self.B[i, v] = 1
        self.D1 = np.zeros((len(self.tris), m))
        for t, (u, v, w) in enumerate(self.tris):
            self.D1[t, self.eidx[(u, v)]] = 1
            self.D1[t, self.eidx[(v, w)]] = 1
            self.D1[t, self.eidx[(u, w)]] = -1
        assert np.allclose(self.D1 @ self.B, 0)
        # projectors (dense; fine for n <= few hundred; sparse CG for production)
        self.P_grad = self.B @ np.linalg.pinv(self.B)                   # onto im(d0)
        self.P_curl = self.D1.T @ np.linalg.pinv(self.D1.T) if len(self.tris) else np.zeros((m, m))
        self.P_harm = np.eye(m) - self.P_grad - self.P_curl               # onto ker L1
        L = self.B.T @ self.B
        Lp = np.linalg.pinv(L)
        self.Reff = np.array([(self.B[i] @ Lp @ self.B[i]) for i in range(m)])
        self.beta1 = m - n + self.components()

    def components(self):
        seen, c = set(), 0
        for s in range(self.n):
            if s in seen: continue
            c += 1; stack = [s]
            while stack:
                v = stack.pop()
                if v in seen: continue
                seen.add(v); stack.extend(self.adj[v] - seen)
        return c

    # --- edge-level topological constants (independent of any data) ---
    def edge_table(self):
        """Per edge: R_eff, harmonic weight H_ee, curl weight C_ee, edge legibility L(e)."""
        rows = []
        for i, e in enumerate(self.edges):
            H = self.P_harm[i, i]; C = self.P_curl[i, i]; R = self.Reff[i]
            vis = 1 - R
            L = H / vis if vis > 1e-12 else float('nan')
            rows.append(dict(edge=e, Reff=R, visible=vis, harm=H, curl=C, L=L, bridge=vis < 1e-12))
        return rows

    # --- data ---
    def cochain(self, msgs, facts):
        """msgs: dict (sender, receiver) -> {fact: value}. facts: {fact: [values]}.
        Returns g of shape (m, sum |Val(f)|)."""
        cols, off = [], {}
        for f, vals in facts.items():
            off[f] = (len(cols), {v: k for k, v in enumerate(vals)})
            cols.extend([(f, v) for v in vals])
        g = np.zeros((len(self.edges), len(cols)))
        for i, (u, v) in enumerate(self.edges):
            a, b = msgs.get((v, u), {}), msgs.get((u, v), {})
            for f in facts:
                if f in a and f in b:
                    o, idx = off[f]
                    g[i, o + idx[a[f]]] += 1
                    g[i, o + idx[b[f]]] -= 1
        return g

    def analyze(self, g):
        grad = self.P_grad @ g
        rho = g - grad
        curl = self.P_curl @ g
        harm = self.P_harm @ g
        r = np.linalg.norm(rho)
        Ec, Eh = np.sum(curl ** 2), np.sum(harm ** 2)
        L = Eh / (Eh + Ec) if Eh + Ec > 1e-12 else float('nan')
        tri_curl = self.D1 @ g if len(self.tris) else np.zeros((0, g.shape[1]))
        witness_tris = [self.tris[t] for t in range(len(self.tris)) if np.linalg.norm(tri_curl[t]) > 1e-9]
        return dict(r=r, rho=rho, curl_energy=Ec, harm_energy=Eh, L=L,
                    witness_triangles=witness_tris,
                    edge_energy=np.sum(rho ** 2, axis=1))

    def circulation(self, cochain, cycle):
        """Sum of a 1-cochain around a vertex cycle [v0, v1, ..., v0]."""
        s = 0.0
        for a, b in zip(cycle, cycle[1:]):
            i = self.eidx[(min(a, b), max(a, b))]
            s += cochain[i] * (1 if a < b else -1)
        return s

    # --- repair (CR-4) ---
    def greedy_repair(self, g, w=None):
        w = np.ones(len(self.edges)) if w is None else np.asarray(w, float)
        active = list(range(len(self.edges)))
        log = []
        while True:
            sub = Swarm(self.n, [self.edges[i] for i in active])
            res = sub.analyze(g[active])
            if res['r'] < 1e-9:
                log.append(dict(round=len(log), r=0.0, fenced=None)); break
            ratio = res['edge_energy'] / w[active]
            k = int(np.argmax(ratio))
            log.append(dict(round=len(log), r=res['r'], fenced=self.edges[active[k]], ratio=float(ratio[k])))
            active.pop(k)
        return log


def consistent_msgs(sw, claims, fact='f'):
    """Every agent tells every neighbour its own claim."""
    return {(v, u): {fact: claims[v]} for v in range(sw.n) for u in sw.adj[v]}


def two_teams(k=4):
    e = [(u, v) for u, v in itertools.combinations(range(k), 2)]
    e += [(u + k, v + k) for u, v in itertools.combinations(range(k), 2)]
    e += [(0, k), (k - 1, 2 * k - 1)]           # two bridges -> one chordless 4-cycle
    return Swarm(2 * k, e), k


if __name__ == '__main__':
    F = {'f': ['a', 'b']}
    np.set_printoptions(precision=4, suppress=True)

    print('== 1. Tree blindness: split-view on a bridge is silent')
    sw = Swarm(4, [(0, 1), (1, 2), (1, 3)])
    m = consistent_msgs(sw, ['a'] * 4); m[(1, 2)] = {'f': 'b'}
    print('   r =', sw.analyze(sw.cochain(m, F))['r'], ' beta1 =', sw.beta1)

    print('== 2. C6 closed form: r = sqrt(2) * sqrt(1 - 5/6)')
    sw = Swarm(6, [(i, (i + 1) % 6) for i in range(6)])
    m = consistent_msgs(sw, ['a'] * 6); m[(0, 1)] = {'f': 'b'}
    res = sw.analyze(sw.cochain(m, F))
    print('   r =', res['r'], ' predicted', np.sqrt(2) * np.sqrt(1 - 5 / 6), ' L =', res['L'], '(no triangles -> all harmonic)')

    print('== 3. Chordal graph => H^1 = 0 => L identically 0 (K5 minus nothing, and a triangulated ring)')
    for name, edges in [('K5', list(itertools.combinations(range(5), 2))),
                        ('fan', [(0, i) for i in range(1, 6)] + [(i, i + 1) for i in range(1, 5)])]:
        sw = Swarm(len({v for e in edges for v in e}), edges)
        print(f'   {name}: beta1(graph)={sw.beta1}, dim ker L1 = {round(np.trace(sw.P_harm))}')

    print('== 4. Two chordal teams + 2 bridges: honest partition (each team consistent) is gauge')
    sw, k = two_teams()
    m = consistent_msgs(sw, ['a'] * k + ['b'] * k)
    print('   r =', sw.analyze(sw.cochain(m, F))['r'])

    print('== 5. Cross-boundary split-view (agent 0 tells bridge peer b, tells team a)')
    m = consistent_msgs(sw, ['a'] * 2 * k); m[(0, k)] = {'f': 'b'}
    g = sw.cochain(m, F); res = sw.analyze(g)
    print(f"   r={res['r']:.4f}  curlE={res['curl_energy']:.4f}  harmE={res['harm_energy']:.4f}  L={res['L']:.4f}  witness triangles={res['witness_triangles']}")

    print('== 6. Intra-team split-view between adjacent neighbours (0 tells 1 b, tells 2,3 a)')
    m = consistent_msgs(sw, ['a'] * 2 * k); m[(0, 1)] = {'f': 'b'}
    g = sw.cochain(m, F); res = sw.analyze(g)
    print(f"   r={res['r']:.4f}  curlE={res['curl_energy']:.4f}  harmE={res['harm_energy']:.4f}  L={res['L']:.4f}  witness triangles={res['witness_triangles']}")
    harm = sw.P_harm @ g
    print('   harmonic circulation on intra-team cycle 0-1-2-0:', sw.circulation(harm[:, 0], [0, 1, 2, 0]),
          ' on boundary cycle 0-4-7-3-0:', sw.circulation(harm[:, 0], [0, 4, 7, 3, 0]))

    print('== 7. Per-edge legibility table L(e) = H_ee / (1 - Reff(e)) (pure topology)')
    for row in sw.edge_table():
        print(f"   {row['edge']}: Reff={row['Reff']:.3f} visible={row['visible']:.3f} harm={row['harm']:.3f} curl={row['curl']:.3f} L={row['L']:.3f}")

    print('== 8. Greedy repair on scenario 5 with bridge cost 5, team cost 1')
    m = consistent_msgs(sw, ['a'] * 2 * k); m[(0, k)] = {'f': 'b'}
    g = sw.cochain(m, F)
    w = [5.0 if (e in [(0, k), (k - 1, 2 * k - 1)]) else 1.0 for e in sw.edges]
    for step in sw.greedy_repair(g, w): print('  ', step)
