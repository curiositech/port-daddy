# Prescriptions: Governing AI Agents v5

Nov 5, 2026 · @Erich James Owens

The review diagnosed; this prescribes. Every item below says what changes, how, and in which phase, and the plan ends in a book of about 460 body pages with one theorem per chapter, a true dependency chain, and its first measured numbers.

## v5 at a glance

v5 is v4 with its chain made true. Nine chapters, each with one spine theorem, each importing from the chapter before it and exporting to a labelled target later; 689 body pages become about 460; 55 theorems become 9 spine theorems and at most 20 propositions; four vocabularies of evidence become one badge; three numbers get measured; four results get mechanized; the five welds the review found broken (Ch. 0 uncited, Ch. 2 → Ch. 8 proof-of-possession, Ch. 3 → Ch. 7 exfiltration bond, Ch. 4 → Ch. 6 hosted trust, Ch. 5 → Ch. 8 tombstones) become build-checked targets. The map below is the weld graph the build will check.

&#91;embedded content: dependency map · nine chapters, three drawn welds, two of them broken in v4\]

Read it in serpentine order: Chs. 0–2 across the top, 3–5 right to left, 6–8 across the bottom. The accented boxes are the three chapters that get a measured number. The two dashed welds are the ones a reader of v4 can follow to nowhere; the two in the box text (Ch. 2 → Ch. 8 and Ch. 5 → Ch. 8) are the same kind and are not drawn only to keep the picture readable.

## Book-wide prescriptions

Fourteen rules, each with what changes, how it is enforced, and the phase it lands in. The phases are P0 Land (weeks 1–2), P1 Correct (weeks 2–5), P2 Restructure (weeks 4–10), P3 Measure and mechanize (weeks 5–14, in parallel), P4 Exhibits and story (weeks 10–15), P5a Papers, wave 1 (weeks 9–13, inside the restructure) and the release (weeks 16–18); the schedule section draws them with gates.

**1. Land before you fix (P0).** *What:* the 5 Nov PDF still prints at least ten corrections the program's own ledger recorded months ago — X1 (decision-odds denominator), X12 (audit-tail independence), X14 (cheap identity), X15 (shared-head superadditivity), F011 (Fig. 1.4 "replays uncommitted"), F013 (Fig. 2.4 wrong key), F016, F019, F020, and review-synthesis-27 (the probation theorem contradicting its premise). The bottleneck is not finding errors; it is landing them. *How:* one integration branch, one integrator, a merge queue; a `corrections.yaml` with fields id / v4 page / the wrong string / the right string / landed-in-rev / render-verified; CI renders the PDF and greps every entry's "after" string, failing the build on any "before" string. The 89 open PRs are triaged in one sitting into land, fold, or close. *Pivot point:* if landing the ten known fixes takes more than two weeks, the pipeline is the project — stop and build the queue before touching prose.

**2. One label scheme (P1).** *What:* v4 runs four vocabularies at once — evidence tags (\[verified\] / \[verified arithmetic\] / \[internal\]), maturity grades (implemented / partial / specified / proposed), the library page's running-today / modelled-and-checked / proposed, and the Ch. 4 proof markers (verified / proved here / unproved) that only two of fifteen theorems actually carry. Collapse them into one two-axis badge printed under every theorem, invariant, table of numbers and figure: **Evidence** ∈ {proved, mechanized, computed, measured, asserted} × **Status** ∈ {running, modelled, proposed}. *How:* the badge is generated from `book/corpus.json`, never typed by hand; a lint fails the build when any Theorem, Proposition, Invariant or numeric table lacks one. The program's open problem `one-label-scheme` closes with this rule. *When:* P1, because the correction pass rewrites every label anyway.

**3. One spine theorem per chapter (P2).** *What:* 55 theorems, 2 propositions and 1 lemma become nine spine theorems and at most twenty propositions; everything else becomes a Claim with a badge, or moves to Appendix C with a one-line "where it went". The spine: Ch. 1 regimentation equals Ramadge–Wonham controllability (Thm. 1.7.4); Ch. 2 per-hop attenuation soundness (the v7 fix, with a paper proof beside the ProVerif run); Ch. 3 the q·b leakage budget with the canary power curve 1−βᵏ; Ch. 4 decision-sufficiency (new, Blackwell), with the covering floor and the pooling gain as corollaries; Ch. 5 the scope lemma and no-mint (reputation is conserved under transfer); Ch. 6 Myerson–Satterthwaite with the harbor's own corollary (a posted price captures 75% of first-best, the Chatterjee–Samuelson equilibrium 84.4%); Ch. 7 the bonded-patience frontier δ★(qb), proved as subgame-perfect, not Nash; Ch. 8 equivocation as a 1-cocycle — detection needs a cycle in the witness graph (the ring / chain / severed-ring triple). Ch. 0 proves nothing; it defines. *How:* each spine theorem gets a full proof in the body, a mechanization target (rule 9), one figure (rule 10) and one exercise that re-derives a number. *Pivot point:* if a chapter's candidate spine cannot be stated in one sentence with all hypotheses, that chapter merges with its neighbour (the likeliest pair is Ch. 6 into Ch. 7).

**4. A hedge budget (P2).** *What:* 182 hedge phrases and 136 uses of "honest" are replaced by the badge. Each chapter keeps exactly one "What this chapter does not claim" box and at most three inline hedges. *How:* a grep lint with a per-chapter allowance; the box is a required section in the chapter template. *Why it matters:* a reader who sees "does not prove" sixty-five times in one chapter stops distinguishing the hedges that matter (Thm. 4.8.2 reversing sign) from the ones that do not.

**5. Welds resolve or the build fails (P1).** *What:* every cross-chapter promise ("hosted trust, see Ch. 6") must land on a labelled target. The eight broken welds from the review go first: Ch. 0 claims nothing cites; the Ch. 3 orphan; Ch. 4 → Ch. 6 hosted trust; Ch. 5 → Ch. 8 tombstones; Ch. 3 → Ch. 7 the exfiltration bond "Not set"; the Ch. 7 OP-2 / ticket-lock duplicates; Appendix C names that resolve nowhere; Appendix A.2 proof-of-possession. *How:* a `\weld{label}` macro that errors at build time on a missing label; Appendix D's concordance is generated from the weld graph, which is also the dependency map in the first section of this document.

**6. Attribution check (P1).** *What:* five named attributions are wrong or misleading in v4 (BBL on p. 19; ANS authorship; Schneider invoked for a tautology; Everest's venue and framing; "Akerlof" where the model is not his). *How:* `corpus.json` gains a `cites` record per named-person claim with DOI and the sentence it supports; a reviewer agent with web access checks each record once, and the check is recorded, not repeated.

**7. A page budget (P2).** *What:* 689 body pages become about 460. Budget per chapter: Ch. 0 30 · Ch. 1 70 · Ch. 2 45 · Ch. 3 45 · Ch. 4 65 · Ch. 5 60 · Ch. 6 50 · Ch. 7 55 · Ch. 8 45 (465), plus Solutions 60 and Appendices 40. The cuts are named in the chapter section; the largest single move is §4.4.3's six pages of Erlang-C to Ch. 6 beside Thm. 6.1.2, which already carries the other half of the same result. *How:* the build prints a per-chapter page count against the budget; overrun is a warning in P2 and an error at the P4 gate.

**8. Three measured numbers (P3).** *What:* the book has zero completed empirical or human measurements — INSTRUMENTATION is open, REVIEW-PILOT was never run, freeze-probe exists as a design, the substrate study's pilot is blocked on substrate D. v5 ships with at least three: daemon throughput and tail latency under N concurrent agents (Ch. 1), the cost-matched reviewer-dependence experiment (Ch. 4, NEXT-P3), and either the substrate study's S2 arm or the freeze probe (Ch. 7). *How:* each is pre-registered in the repo with the seed (20260816 is the program's), the script under `skills/harbor-results/scripts/`, and the data file; the badge's Evidence axis shows "measured" only for a claim whose data file exists. *Pivot point:* if two of the three cannot be run by week 12, the book's subtitle drops "Textbook" claims about operation and the running-today column shrinks to what the CI actually exercises.

**9. Mechanize four, retract the rest (P3).** *What:* one theorem is mechanized today (claim-signaling incentive compatibility). Four spine results with proofs of two pages or less get mechanized — Ch. 7's δ★ as a subgame-perfection argument (TLA+/TLAPS or Lean), Ch. 4's pooling gain (Lean, elementary), Ch. 5's no-mint conservation (TLA+, extending `Conservation.tla`), Ch. 2's per-hop attenuation (already ProVerif; add the Kani harness to the production path or stop calling it verified). Table 7.9's "EasyCrypt discharged" is retracted until the three admits close. *How:* Appendix B is regenerated from the `proofs/` directory by CI; nothing in Appendix B is typed.

**10. Every figure answers a reader question (P4).** *What:* the figure register's schema (idea · structure · reader question · form · data source) becomes the acceptance test for every exhibit. 146 figures become about 120: roughly thirty that restate an adjacent box or invariant are cut (Figs. 4.2, 4.7, 4.11, 4.20 and their analogues), and the twenty-nine must-priority ideas that still have no figure are drawn — the exhibit section lists them with specs. *How:* each figure's caption begins with the reader question it answers; a figure with no question in the register is not built.

**11. The cast appears in every chapter (P4).** *What:* Alice, Bob, Heron, Wren, Drake, Finch and Crane carry one beat per chapter, and the beats form one story told in order (the story section). *How:* a cast-and-timeline page in the front matter; each chapter opens with its beat in under 300 words and closes by resolving it with the chapter's spine theorem.

**12. Exercises: 212 become about 120 (P2).** *What:* per chapter six check exercises (re-derive a number from the chapter), four build exercises (run or modify an artifact in the repo) and two research exercises (each pointing at one open problem, renumbered to match the research directions in this document). All 120 keep worked solutions. *How:* the solution map (`_solmap.json`) already links 212/212; the cut keeps the links intact.

**13. Two reading routes, not three (P2).** *What:* the chapter-opener route tables are replaced by one front-matter map with two routes, Builder and Theorist, and a glyph on each section heading. *How:* the glyphs are set from `corpus.json` section metadata.

**14. The front matter carries the contracts (P4).** *What:* four pages before Chapter 0 — how to read the badges, the cast and timeline, the dependency map, and what is running today in the harness vocabulary (Genesis, Voyage, Wake, Logbook, Receipt) with the install line. *Why:* a reader who starts at Ch. 4 should be able to find, in two pages, what the book assumes and what it has shown.

*What these rules do together:* rules 1, 5 and 6 make the manuscript trustworthy again; 2, 3, 4 and 7 make it readable; 8 and 9 make the strongest claims true in a sense a referee accepts; 10, 11, 13 and 14 make it teachable. None of them requires new ideas, which is why they come before the research directions.

## Chapter-by-chapter prescriptions

Each entry gives the verdict, then keep / cut / move / rewrite / add, then the v5 outline with its page budget. Page numbers are v4's. The review document holds the page-cited evidence for every item; this section only says what to do about it.

### Chapter 0 — Foundations (v4 pp. 2–55 → v5 30 pages)

*Verdict:* a definitions chapter carrying an eighteen-page classical survey nothing downstream cites, and headings ("Alignment Illusion", "Cognitive Control", "Kernel Gap") the body never cashes.

- **Keep:** the evidence-channel taxonomy (§0.1.6), the five-layer picture, Bratman plus Design Invariant 0.2.1, speech acts and Table 0.3, Becker deterrence, Myerson–Satterthwaite, Ostrom, the hidden-bit indistinguishability example, the KV-cache arithmetic (Eq. 0.10–0.11).
- **Cut:** Thm. 0.7.1 (three trivial lemmas dressed as a theorem; demote to a boxed claim), AgentSpeak/Jason and Fig. 0.1, norms, Contract Net, BBL, POMDPs, Arrow as Theorem 0.2.7, VCG — none is used later.
- **Move:** the surviving classical material to a two-page reference card in Appendix D ("Classical multi-agent systems: what this book borrows").
- **Rewrite:** fix the BBL attribution (p. 19); "sandbox" for Seatbelt and Bubblewrap (p. 44); every heading becomes a claim the section states in its first paragraph.
- **Add:** the badge legend (rule 2), the harness vocabulary with the install line, and a half-page "what the kernel gap is" that Ch. 1 then proves.

*v5 outline:* 0.1 What a harbor is (the running case in 300 words) · 0.2 Evidence channels · 0.3 Four borrowed ideas (commitment, speech act, deterrence, impossibility) · 0.4 The physics of LLM execution · 0.5 The kernel gap, stated · 0.6 How to read this book.

### Chapter 1 — The Single-Writer Kernel (pp. 56–153 → 70 pages)

*Verdict:* the book's most built chapter and its most repetitive: the same correction (a policy monitor detects, it does not prevent) is restated nine times, I1a/I1b twelve, the SO\_PEERCRED caveat six.

- **Keep:** the single-writer argument, the claim lifecycle, the 536-state work-unit machine with its checker transcript, marker decay, Thm. 1.7.4 (regimentation equals Ramadge–Wonham controllability — the spine), the controllability quadrant, the continuity organs.
- **Cut:** §1.16 and §1.A.4 (restatements), the "Review of the key ideas", every duplicate statement of the monitor-versus-mediator point except the first and the figure.
- **Move:** the L0–L3 ladder from 1.A.5 into the body where Ch. 4 later leans on it.
- **Rewrite:** Thm. 1.10.3 — the SQLite `read_uncommitted` hypothesis is vacuous and there is no sequential specification; state the spec (claim / lock operations as a sequential object) and prove linearizability with commit as the linearization point under WAL, as Fig. 1.4 should show once F011 ("replays uncommitted") is fixed. Resolve the SO\_PEERCRED caveat against the threat model: either the same-user adversary is in scope (then say what the kernel does about it) or the caveat goes. Put the Rust verifier on the production path or stop calling the path verified.
- **Add:** the taint-automaton figure (ch1-25), the chapter's first measured number (throughput and tail latency under N agents, rule 8), a precise coverage number for I12 (which writes still accept a self-asserted identity).

*v5 outline:* 1.1 One writer · 1.2 Claims and leases · 1.3 Durability by fault class · 1.4 The work unit and its 536 states · 1.5 Mediation versus monitoring · 1.6 Regimentation is controllability (spine theorem) · 1.7 The consistency model, with a spec · 1.8 Continuity organs · 1.9 What runs today, measured · 1.10 What this chapter does not claim.

### Chapter 2 — The Anchor Protocol (pp. 154–213 → 45 pages)

*Verdict:* the chapter with the book's sharpest result (the v6 multi-hop escalation and the v7 per-hop fix) and no diagram of it.

- **Keep:** attenuation as strict subset per hop, algorithm pinning, the signed chain with fresh nonces, the cuckoo-filter non-mergeability lesson, the card lifecycle, the ProVerif transcript.
- **Cut:** the protocol-history narration of v3 through v6 (keep v6 as the attack, v7 as the fix, the rest in a margin).
- **Rewrite:** Fig. 2.4 with the right key (F013, `pk_daemon`); the Kani claims so they describe what the harness checks, not what the prose wishes; revocation gossip's Θ(log m) with its reliable-round assumption in the theorem statement.
- **Add:** a paper proof of per-hop soundness beside the ProVerif run (spine theorem), the escalation-versus-fix chain diagram (ch2-35), and a one-page "what a verifier must check" checklist a builder can lift.

*v5 outline:* 2.1 Cards, chains, hops · 2.2 Attenuation as containment · 2.3 The escalation attack and the per-hop fix (spine theorem) · 2.4 Verifier discipline · 2.5 Revocation · 2.6 What is mechanized and what is not.

### Chapter 3 — The Sealed Harbor (pp. 214–267 → 45 pages)

*Verdict:* a coherent four-claim pipeline (enforceability, noninterference, conservation, detection) whose best quantitative idea — the q·b leakage budget — is never drawn, and whose bond for exfiltration points at a Ch. 7 section that says "Not set".

- **Keep:** the pipeline, the two-worlds run, the mutant grid, the composition crossover, the canary operating curve and SPRT.
- **Cut:** the orphan subsection the review flagged; duplicated threat-model prose.
- **Rewrite:** the Everest citation's venue and framing; the exfiltration bond becomes a real weld to Ch. 7's bond table with a number.
- **Add:** the q·b ledger figure (ch3-21, 12,800 bits as the worked point), the laundering residual as a paired-path figure (ch3-12) and an explicit open problem, the dual-attested key-release ladder (ch3-06). Spine theorem: the leakage budget with canary power 1−βᵏ and the SPRT expected sample size, stated together as one detection theorem.

*v5 outline:* 3.1 What sealing promises · 3.2 The four-claim pipeline · 3.3 The leakage budget and its canaries (spine theorem) · 3.4 Composition over releases · 3.5 The residual: laundering · 3.6 Key release with two brokers.

### Chapter 4 — The Legible Swarm (pp. 268–377 → 65 pages)

*Verdict:* three chapters interleaved — authority and consent, the operator and attention, information bounds — at 36k words with fifteen theorems of which four carry weight and sixty-five self-hedges. The best political ideas in the book live here and are the hardest to find.

- **Keep:** the legible sovereign and "ranking is governing" with its counter-surface, the consent grant as a per-class level of automation, zoom versus Potemkin digest, the SDT decomposition (legibility raises d′, grants set the criterion, economics prices it) stated once, the covering floor, the two-constraint rate, the split-ranker impossibility.
- **Cut (about 35%):** Thm. 4.8.2 and NbH 4.8.3 with Figs. 4.12 and 4.17 (the split penalty reverses under equal budgets); Thm. 4.6.5's proof and Fig. 4.15 (use Hwang's generalized binary splitting and cite it); Figs. 4.2, 4.7, 4.11, 4.20; §4.5.5–4.5.6 to half a page; §4.7.3–4.7.5 to one "ranker hygiene" subsection; the Dai et al. paragraph to a margin.
- **Move:** §4.4.3 (Erlang-C, Kingman, Pollaczek–Khinchine, pp. 289–296) to Ch. 6 beside Thm. 6.1.2.
- **Rewrite:** the chapter around one definition — a summary is decision-sufficient for the operator's decision problem (Blackwell) — from which the covering floor, the pooling gain, the 1-bit ambient-alarm corollary and the SDT threshold follow as corollaries. Add Rödl achievability to Thm. 4.6.2 so the floor is asymptotically exact; add the log-likelihood-ratio gradient sentence to Thm. 4.6.4's proof; define the aggregates Thm. 4.4.8 is stated over; fix the ANS and Schneider attributions; give the Hobbes reading the promulgation / accountability distinction and sovereignty by acquisition; add the proof markers the appendix promises (now the badge).
- **Add:** the pooling-gain theorem (F(N,2k,m) ≤ 2F(N,k,m/2)) with its three-line proof, the two-constraint rate region figure (ch4-32), the adaptive-zoom advantage figure (ch4-33), the consent-grant lifecycle (ch4-08), the cost-matched reviewer-dependence measurement (NEXT-P3).

*v5 outline:* 4.1 Who sees what: the legible sovereign · 4.2 Consent grants · 4.3 Decision-sufficiency (spine theorem) · 4.4 The price of a summary: floor, rate, pooling gain · 4.5 The operator as a modelled entity · 4.6 Ranking is governing · 4.7 Measured: what reviewers actually open · 4.8 What this chapter does not claim.

### Chapter 5 — From Spawn to Person (pp. 378–467 → 60 pages)

*Verdict:* the identity chapter has a true spine (the scope lemma: price per principal-and-engine, sanction per principal; no-mint under transfer) and a tower whose worked numbers violate the chapter's own Becker condition two paragraphs earlier.

- **Keep:** the scope lemma, no-mint lineage, engine-swap theorem a/b, the migration clauses, audit-spend schedules, tombstones.
- **Cut:** the imported tower contraction as stated (its numbers give ρ★ = 400/(0.8·50) = 10 > 1, so no audit rate deters); the duplicated honesty riders.
- **Rewrite:** the tower with numbers that satisfy G < dB, or as an explicit counterexample showing why bonds must scale with gain; the probation result so it no longer contradicts its premise (review-synthesis-27); the judge ceremony's claims to the one-shot deterrence inequality it actually is.
- **Add:** the engine-swap paired panel (ch5-21/22, unattested spiral versus attested flip on identical numbers), the audit-spend plot (ch5-33: 50.00 flat versus 25.58 under Model A over 200 periods), the migration state machine (ch5-23), and the tombstone weld into Ch. 8.

*v5 outline:* 5.1 Spawn, name, person · 5.2 The scope lemma and no-mint (spine theorem) · 5.3 The body behind the name: engine attestation · 5.4 Newcomers: the cliff · 5.5 Judges and bonded re-audit · 5.6 Migration and resurrection · 5.7 Tombstones.

### Chapter 6 — The Harbor Economy (pp. 468–539 → 50 pages)

*Verdict:* a sound borrowed impossibility (Myerson–Satterthwaite) with correct worked arithmetic, a complexity dichotomy with no picture, and a Table 6.5 that calls a model "verified".

- **Keep:** Myerson–Satterthwaite with the Chatterjee–Samuelson numbers (7/32 refused, 9/64 captured), the deontic-conflict fragment, Thm. 6.1.2 with breakdowns.
- **Cut:** the marketplace / underwriting material the program itself rejected (X25); the duplicate derivations of the posted-price result.
- **Move in:** §4.4.3's queueing (so the specialist-versus-pool result lives in one place, with Smith and Whitt 1981 cited per review-synthesis-34).
- **Rewrite:** Table 6.5 ("verified as model" becomes "modelled" on the badge); the conflict-enumeration bound (n², per the ledger); the NP-completeness remark so it does not imply a human resolver is needed (X6).
- **Add:** the posted-price corollary as the chapter's own result (75% of first-best, against 84.4% for the second-best optimum) with the surplus-fraction plot; the (v, c) refused-wedge figure (ch6-15); the Horn derivation trace (ch6-10); the polynomial-versus-NP boundary (ch6-09); hosted trust as the target of Ch. 4's weld.

*v5 outline:* 6.1 Prices inside a harbor · 6.2 Specialist or pool (moved queueing) · 6.3 Why some efficient trades are refused (spine theorem) · 6.4 Deontic conflicts: the tractable fragment · 6.5 Hosted trust · 6.6 What this chapter does not claim.

### Chapter 7 — The Bonded Commons (pp. 540–623 → 55 pages)

*Verdict:* the book's headline mechanized number (δ★ = 0.3425) with no plot, two TLA+ listings with defects, and a Table 7.9 that says "discharged" for a proof with three admits.

- **Keep:** the five expressive classes, the four-mechanism dispute ladder, the three-tier Merkle commitment, the lifecycle, the stock-flow conservation (Thm. 7.10.2, 1,716 states), cold-start phases.
- **Cut:** the OP-2 / ticket-lock duplicates; the grim-trigger derivation as a separate result (it becomes one line: δ > (1−qb)/(3−qb)).
- **Rewrite:** Thm. 7.7.2 as subgame-perfect equilibrium with the bond in the statement — δ★(qb) is the root of 2δ³+2δ²+2δ−(1−qb), 0.3425 at qb = 0, 0.2013 at qb = 0.5, 0 at qb = 1; Listing 7.3 (NULL.status after Dismiss) and Listing 7.4 (NoteMonotonicity uses a primed variable); Table 7.9's EasyCrypt row; the float comparisons in `Conservation.tla` (1e−6 tolerance) stated as a modelling choice.
- **Add:** the bond–patience frontier plot (the chapter's figure), the lifecycle state machine (ch7-46), the three-bucket stock-flow ledger (ch7-47), the Merkle tiers (ch7-14), the class-by-bonding table (ch7-42), and the exfiltration bond Ch. 3 promises.

*v5 outline:* 7.1 Five things agents say · 7.2 Bonds, escrow, commons · 7.3 The lifecycle, checked · 7.4 Honesty as patience: the bond–patience frontier (spine theorem) · 7.5 Disputes: four mechanisms · 7.6 Evidence commitments · 7.7 Cold start · 7.8 What is mechanized.

### Chapter 8 — The Federated Harbor (pp. 624–696 → 45 pages)

*Verdict:* a ceremony that ships a bearer card, an epoch fix that over-invalidates, a witness-log uniqueness requirement that is consensus in disguise, and a flagship worked example (Acme / Beta / staging) with no figure.

- **Keep:** the equivocation-as-cocycle idea with the ring / chain / severed-ring triple, the six pre-registered arms table, bond conservation across four buckets, sponsor probation, the worked example.
- **Cut:** Thm. 8.5.2 as a theorem (push versus push–pull rounds is a textbook fact; keep the 7/3 number in a margin); the second half of the sheaf machinery that Paper 8's own ledger marks edge-only (paper8-edge-only-utility).
- **Rewrite:** the four-message ceremony so no message carries a bearer card (proof-of-possession, which also closes the Appendix A.2 weld); the epoch fix with the smallest invalidation set; the witness-log requirement stated as what it is — a uniqueness assumption that needs either a consensus layer or a detection-after-the-fact argument, and the chapter should choose the latter and say so.
- **Add:** the three-harbor swimlane (ch8-39), the three-panel residual figure (ch8-23), the probation state machine (ch8-36), the four-bucket ledger (ch8-33), and the tombstone target for Ch. 5.

*v5 outline:* 8.1 Why federate · 8.2 Crossing: cards between harbors · 8.3 Equivocation and where it can be seen (spine theorem) · 8.4 Bonds across harbors · 8.5 Joining under a sponsor · 8.6 Acme, Beta and staging, end to end.

### Solutions and Appendices (pp. 697–793 → 100 pages)

- **Solutions:** keep 120 worked solutions; the ninety cut exercises' solutions are archived in the repo, not printed.
- **Appendix A (assurance modes):** keep as is — it is the best short piece in the book; close the A.2 proof-of-possession weld from Ch. 8.
- **Appendix B (mechanized claims):** regenerated by CI from `proofs/`; the EasyCrypt row reads "3 admits" until it does not.
- **Appendix C (result atlas):** every identifier resolves (blocker); add the "where it went" table for demoted theorems.
- **Appendix D:** notation, the weld concordance generated from the weld graph, and the classical reference card moved from Ch. 0.

## Figures, plots, tables and diagrams: the exhibit plan

The program already has the right instrument: `FIGURE-REGISTER.md` (7 Sept 2026) enumerates 378 ideas across eight chapters with a schema — idea, structure, reader question, recommended form, existing figure, priority, data source — and finds 64 must-priority ideas, 141 existing figures and 237 ideas with none. v4 now has 146 figures and 79 tables. The prescription is to make the register the acceptance test (rule 10) and to execute its must list, not to invent a new one.

**Four moves, in order.**

1. *Cut what restates.* A figure that draws the adjacent box or invariant in boxes (Figs. 4.2, 4.7, 4.11, 4.20 are the named cases; the review found their analogues in Chs. 1, 5 and 7) goes. Expected: about thirty cuts.
2. *Draw the must list.* The register's must-priority ideas with no figure are listed below; the register predates the 5 Nov manuscript by five figures, so check each against v4 before building.
3. *Unify the grammar.* The 146 figures use at least six visual languages. v5 uses four diagram grammars and one plot style: a state machine (labels off the edges, terminal states distinct), a typed stock-flow ledger (buckets and arrows with units), a provenance chain (hops with the broken-link splice drawn as a splice), and a swimlane sequence (lifelines, one message per arrow). Plots: measured quantity on the y-axis, the theorem's threshold as a rule, the worked point annotated, the badge in the corner.
4. *Generate every numeric exhibit.* Each plot and every table of numbers is produced by a script under `skills/harbor-results/scripts/` with seed 20260816, and the caption names the script. A number that no script produces is not printed.

**The must list** (register id · what the figure carries · form · source).

| id | what it carries | form | source |
| --- | --- | --- | --- |
| ch1-25 | gate the channel, never the token: ok → tainted on an in-context read, egress disabled while tainted | two-state machine | Ch. 1 prose, §1.5 |
| ch2-35 | root-versus-final check accepts a re-escalated middle hop (A:write → B:read → C:write); per-hop check rejects it | paired provenance chains | ProVerif v6/v7 transcripts |
| ch3-06 | dual-attested key release: CVM boots, two brokers verify independently, key released only on both | protocol ladder | §3.6 |
| ch3-12 | the laundering residual: honest path (gate applies g to committed s) beside t = f(s) submitted so the gate honestly releases g(t) | paired paths | §3.5 |
| ch3-21 | q jobs × b bits accumulates to the leakage budget (12,800 bits at the worked point) | ledger / accounting | `b3` script |
| ch4-08 | consent grant: ISSUED → ACTIVE → {ADMITTED, ESCALATED} → EXPIRED / REVOKED | state machine | §4.2 |
| ch4-20 | completion claim: CLAIMED → verifier → {DONE, FAIL-LOUD}; an unverifiable predicate fails loud | state machine | §4.3 |
| ch4-22 | feasible dismissal-debit interval \[δmin, δmax\] against the alarm-load and separation constraints | threshold plot | `b4` script |
| ch4-32 | two-constraint rate region in (δ, f): pinned joint, the corner R(0,p) = H(p) = 0.2864 bits, the zero line | phase-boundary plot | `b1_frontier.py` |
| ch4-33 | adaptive-zoom advantage against flagged density d, crossover at d = 1/12, worked point F = 2500, k = 10 (162.6 opens versus 2500) | threshold plot | `zoom_bound_check.py` |
| ch4-48 | replaced: pooling gain versus the printed split penalty at N = 60 (worked plot 3 below) | line plot | closed form |
| ch5-21/22 | engine swap: unattested gain Δc = 0.3 flat in price (pool collapses below μ★ = 1/6); attested gain Δc − Δθ = −0.3 | paired panel | `b5_engine_substitution.py` |
| ch5-23 | migration: lineage verified → per-outcome engine attestation → sanction carried, else resurrection refused | state machine | §5.6 |
| ch5-33 | cumulative audit spend over 200 periods: flat 50.00, stake-decaying 25.58, third schedule | line plot | `b5` script |
| ch6-04 | specialist with breakdowns: mean wait decreasing toward a floor it never reaches; pool wins at every premium | threshold plot | `b6` script |
| ch6-09 | the tractable fragment: polynomial without disjunction, NP-complete with | boundary diagram | §6.4 |
| ch6-10 | fact → Horn rule → derived fact → obligation and prohibition on write‑prod overlapping on \[5, 10\] | derivation trace | §6.4 |
| ch6-15 | (v, c) square: trade line v − c = M/4, the refused-but-efficient wedge (7/32 of the square), worked point (70, 60) | regime plot | closed form |
| ch7-14 | note chain → session root → harbor root; a 700-byte proof of inclusion | provenance tree | §7.6 |
| ch7-30 | δ★ as a frontier in the bond (worked plot 1 below) | threshold plot | `delta-threshold.z3`, `sweep-delta.sh` |
| ch7-37 | cold start: subsidized seeding → complexity-proportional pricing → competitive insurance, each gated | staged timeline | §7.7 |
| ch7-42 | Signal / Request / Distress / Commons / Proposal × frequency, stakes, bonding profile, failure under uniform pricing | comparison table | §7.1 |
| ch7-46 | Begin → Claim (never blocks) → Commit / Crash → Reap → Salvage / Dismiss | full state machine | `lifecycle.tla` |
| ch7-47 | wallet / escrow / commons pool; only topUp changes the total | stock-flow ledger | `Conservation.tla` |
| ch8-23 | the same lie of size 3: r = 1.5 on a ring, 0 on a chain, 0 on a severed ring | three small panels | Paper 8 script |
| ch8-25 | six arms × trials × cohomology-only detections × dark cases | results table | pre-registered runs |
| ch8-33 | posted / escrow / cleared / refunded, exactly one nonzero at any time | stock-flow ledger | §8.4 |
| ch8-36 | unsponsored → probationary (sponsor's bond at risk) → graduated / ejected | state machine | §8.5 |
| ch8-39 | Controller-7's card crosses Acme → staging; Beta finds schema damage two hours later; settlement | three-harbor swimlane | §8.6 |

**Tables.** 79 become about 55. Cut: the per-chapter route tables (replaced by the front-matter map), the restated open-problem tables in §1.16 and Ch. 7, and any table whose numbers appear in a figure on the same spread. Keep and badge: every numeric table (Table 6.5 is the model case — its "verified as model" becomes a modelled badge). Add: the demoted-theorem "where it went" table in Appendix C, the weld concordance in Appendix D, the measured-numbers table in Ch. 1 (rule 8), and the per-chapter page-budget table in the front matter.

**Diagrams that are arguments.** Three drawings carry proofs and should be drawn as proofs, with the hypotheses on the picture: the per-hop attenuation chain (Ch. 2, every hop a strict subset in rights and TTL), the two-worlds lockstep (Ch. 3, equivalence marks at every step and the one permitted difference), and the dependency map of the book itself (first section of this document), which is also the weld graph the build checks.

**Three worked plots.** Each is drawn below from numbers recomputed for this document; each is the chapter's figure in v5.

*Plot 1 — the bond–patience frontier (Ch. 7).* Reader question: how much bond buys how much patience? The x-axis is qb, the expected bond forfeited on a detected lie; the y-axis is the discount factor above which truthful signaling is subgame-perfect. The exact curve is the root of 2δ³ + 2δ² + 2δ − (1 − qb) = 0; the grim-trigger bound (1 − qb)/(3 − qb) runs beneath it. The two never differ by more than 0.01, which is itself the lesson: the closed form is the headline and the cubic is the refinement, so v5 states the closed form first.

&#91;embedded content: recomputed for this document from Thm. 7.7.2's cubic · qb from 0 to 1 in steps of 0.1\]

*Plot 2 — what a posted price costs (Ch. 6).* Reader question: what does a fixed harbor tariff cost relative to the best possible bargaining? With values and costs uniform on \[0, M\], a posted price p captures 3p(M − p)/M² of first-best surplus — at most 75% at p = M/2 — while the Chatterjee–Samuelson equilibrium, which Myerson and Satterthwaite showed is the second-best optimum here, captures 84.4%. The gap between the two is the price of simplicity, about nine points; and the posted price stays above 70% for any p between 0.37M and 0.63M, which is the robustness argument for the harbor's tariff.

&#91;embedded content: recomputed for this document from the Ch. 6 uniform bilateral-trade model · p from 0 to M in steps of 0.05M; references from Myerson–Satterthwaite 1983\]

*Plot 3 — pooling gain, not split penalty (Ch. 4).* Reader question: does splitting review across two heads cost or save bits? At N = 60 and m = 8, the printed comparison F(60, 2k, 8) against 2F(60, k, 8) gives 1.029, 1.067, 1.122, 1.224 for k = 1..4 — but the two single heads were given twice the opens. Under equal budget, F(60, 2k, 8) against 2F(60, k, 4) gives 0.766, 0.778, 0.795, 0.827: sharing one evidence store saves 17–23% of the bits. The reference line at 1.0 is where the chapter's moral flips.

&#91;embedded content: recomputed for this document from Thm. 4.6.2's floor F(N, k, m) = log2 C(N, k) − log2 C(m, k) · N = 60, k = 1..4\]

## Stories: the running case as one narrative

v4 has the right cast and uses it unevenly: Heron appears in eight chapters, Crane in one, Alice sixty times in Ch. 6 and five in Ch. 7; Derek and Erin exist only in Ch. 3; Acme and Beta only in Ch. 8. The story is there but told as nine separate anecdotes. The prescription is one story, one world, nine beats in dependency order, with the rule that a beat is resolved only by the mechanism of its own chapter or an earlier one — so the narrative's causality is the book's dependency chain, and a reader who follows the story has followed the argument.

**The story in one paragraph.** Bob's company, Beta Vision, runs a checkout whose payment path fails under load. Alice's team at Acme Robotics takes the repair: five agents — Heron, Wren, Drake, Finch and Crane — in one harbor, under Alice's authority, paid by Bob. Over nine beats the repair goes wrong in nine instructive ways, each caught by exactly one mechanism, and ships at the end with a logbook that is the evidence it shipped correctly. Derek and Erin enter in the middle: the checkout needs a fraud model, Erin supplies the model, Derek supplies the confidential records it must be fitted on, and neither may see the other's plaintext. Acme and Beta enter at the end when the repair crosses into Beta's staging harbor.

**Cast page (front matter).**

| who | role | what they do, and in which chapter |
| --- | --- | --- |
| Alice | operator; Acme Robotics | authorizes, delegates, reads digests, settles (every chapter) |
| Bob | customer; Beta Vision | owns the checkout; values the repair at 70 (Ch. 6); runs staging (Ch. 8) |
| Heron | senior agent | the stale patch and the lost acknowledgement (Ch. 1); delegates to Finch (Ch. 2) |
| Finch | junior agent | force-pushes outside the grant; tries the middle-hop escalation (Ch. 2) |
| Drake | test agent | makes the suite green by deleting the failing test (Ch. 4) |
| Crane | long-lived agent | the quality vector, the engine swap, the resurrection (Ch. 5) |
| Wren | agent | fixes the defect but bundles an unrelated migration; the bonded request and the dispute (Ch. 7) |
| Derek | data owner | the confidential records (Ch. 3) |
| Erin | model owner | the diagnostic model and the laundering worker (Ch. 3) |

**The nine beats.** Each beat opens its chapter in under 300 words, returns at the spine theorem, and closes the chapter with the theorem's own numbers.

1. *Ch. 0 — The job.* Alice accepts the repair. The chapter ends with the nine questions the job raises (who writes, who may delegate, who may see, who is paid, who is believed) — the table of contents as a worry list.
2. *Ch. 1 — Heron's stale patch.* Heron and Wren both touch the same file; Heron's acknowledgement is lost; Heron crashes mid-claim. One writer, a lease, the 536-state work unit, and the salvage. Resolved by: the kernel's claim lifecycle; the measured number is how long Heron's lease held under load.
3. *Ch. 2 — Finch's force-push.* Alice's card to Heron, Heron's narrower card to Finch; Finch's force-push is outside the grant and is refused; Finch then routes a request through a middle hop that re-widens it. The v6 verifier accepts; the v7 verifier rejects. Resolved by: per-hop attenuation.
4. *Ch. 3 — Derek and Erin.* The fraud model is fitted inside a sealed harbor; the two-worlds run shows Erin learns nothing of Derek's records beyond the agreed status bits; the ledger counts them (q·b); a canary catches the one leak; Erin's worker tries the laundering trick and the chapter admits it cannot see it. Resolved by: the leakage budget; the residual is named, not hidden.
5. *Ch. 4 — Drake's green suite.* The digest says done. Alice cannot read every artifact; she zooms, and the zoom resolves to a deleted test. The consent grant Drake acted under did not cover deletion of tests; the ranker that put Drake's claim at the top is itself examined. Resolved by: decision-sufficiency — what the digest must carry for Alice's merge decision to be the one she would make with the full record.
6. *Ch. 5 — Crane's vector.* Crane's reputation is a quality vector earned over weeks; the provider swaps Crane's engine; the price schedule and attestation decide whether the swap pays; Crane is restarted and the name survives; one of Crane's outcomes is found fraudulent and tombstoned. Resolved by: the scope lemma and no-mint.
7. *Ch. 6 — Bob pays.* Bob values the repair at 70, Alice's cost is 60, the range is 90 — and the mechanism refuses the trade. The chapter explains why any honest, voluntary, self-funding mechanism must refuse some good trades, and what the harbor's posted price loses by being simple. The deontic conflict — Drake's prod access obliges and forbids a write on the same interval — is the second half. Resolved by: Myerson–Satterthwaite and the posted-price corollary.
8. *Ch. 7 — Wren's migration.* Wren's fix bundles an unrelated migration; Wren files it as a Signal when it is a Request; the bond is posted; the dispute climbs the ladder (direct release, time-out, bonded preemption, human escalation). Will Wren keep telling the truth next week? Resolved by: the bond–patience frontier.
9. *Ch. 8 — Acme, Beta and staging.* The repair crosses to Beta's staging harbor on a card; two hours later Beta finds schema damage; one witness's account of the crossing disagrees with another's; the disagreement is visible only because the witnesses form a ring. Settlement across harbors; a new harbor joins under a sponsor's bond. Resolved by: equivocation as a cocycle.

*Coda (after Ch. 8, two pages).* The repair ships. The logbook is reprinted as the evidence trail of all nine beats, each line carrying its badge, and Appendix A's five assurance modes say which beat was Observed, Coordinated, Brokered, Confined or Attested. This is where the harness vocabulary (Genesis, Voyage, Wake, Logbook, Receipt) earns its place: the reader sees the vocabulary name things that happened in the story.

**Three rules for using the story.**

- A beat is never resolved by a later chapter's mechanism. If a chapter needs one, the dependency map is wrong, not the story.
- Numbers in the story are the chapter's worked numbers (70 / 60 / 90; δ = 0.30 fails and 0.35 holds; 12,800 bits; 536 states), so the story is also the exercise key.
- The story is drawn once: a nine-beat timeline in the front matter in the swimlane grammar, with the same lanes (Alice, Bob, the five agents, Derek and Erin, the two harbors) that the chapter figures reuse.

*A smaller option, if the full rewrite is too much for one pass:* keep v4's anecdotes but add the cast page, the timeline, and the opening beat to Chs. 3, 6 and 8, which are the chapters where the story currently disappears. That is two days' work and gets most of the continuity.

## Schedule: phases, gates and pivot points

Eighteen weeks from Monday 9 November 2026 to a v5.0 release on 12 March 2027, in six overlapping phases with a gate at the end of each. A gate is a checklist the CI can print; a pivot point is the decision you take if the gate fails, decided now so it is not relitigated then. The first paper wave is not a final phase: the USENIX Security, CSF and SAIS deadlines (26 Jan, 28 Jan, 4 Feb) fall in weeks 12–13, so the two most finished papers are written during the restructure, by the same discipline as the chapters they come from.

&#91;embedded content: v5 roadmap · six phases, five gates, three deadlines, one release\]

The overlap is deliberate: measurement starts in week 5 because the experiments take elapsed time the prose does not, and the paper wave sits inside the restructure because the two papers are the two chapters whose spines are already firm.

| phase | weeks (dates) | deliverable | gate | pivot if the gate fails |
| --- | --- | --- | --- | --- |
| P0 Land the ledger | 1–2 (9–20 Nov) | integration branch, merge queue, `corrections.yaml`, PR triage | G0: ten ledger corrections render-verified; open PRs under twenty | the pipeline is the project: build the queue before touching prose |
| P1 Correct | 2–5 (16 Nov–11 Dec) | twelve blockers closed in the rendered PDF; badge, weld and attribution lints green | G1: zero blockers, zero unresolved welds, every theorem badged | any blocker that needs new research (the Ch. 5 tower, the Ch. 8 ceremony) is cut from v5 and listed as open |
| P2 Restructure | 4–10 (30 Nov–15 Jan) | nine spine theorems with full proofs; cuts and moves; exercises to 120; two routes | G2: body under 480 pages, hedge lint green, Appendix C resolves | a chapter whose spine cannot be stated in one sentence merges with its neighbour (Ch. 6 into Ch. 7 first) |
| P3 Measure and mechanize | 5–14 (7 Dec–12 Feb) | three measurements with data files; four mechanizations in CI; EasyCrypt row resolved | G3: three data files; three of four proofs green | fewer than two measurements: drop the operational claims to what CI exercises and change the subtitle |
| P5a Papers, wave 1 | 9–13 (4 Jan–4 Feb) | attenuation paper (CSF or USENIX Security); leakage-budget paper (SAIS); EC draft on the EC'26 calendar | G5: two submissions out | one submission out; the other waits for the mid-2027 wave |
| P4 Exhibits and story | 10–15 (11 Jan–19 Feb) | thirty cuts, the must list drawn, four grammars, cast page, timeline, coda | G4: figures under 125, every must row drawn, every caption opens with its question | draw the twelve must rows that belong to spine theorems; the rest wait for v5.1 |
| Release | 16–18 (22 Feb–12 Mar) | fresh-eyes review at the rendered PDF, v5.0 PDF, library page, arXiv for the folded Papers 7 + 8 | the review finds no blocker | v5.0 ships with the review's majors listed in the front matter as known issues |

**Running it with agents.** The program's roadmap already shows what parallel agents without a single writer do to a manuscript. The orchestration below is the book's own kernel applied to the book: one writer, work units with leases, receipts, a legible digest at each gate.

- *Integrator (one, with you):* owns the integration branch and the merge queue; nothing lands except through it. Everything else files against it.
- *Lander agents (many, short-lived):* one per `corrections.yaml` row. Prompt: "Row X of corrections.yaml names a page in the 5 Nov PDF, a wrong string and a right one. Find the wrong string in the LaTeX source, apply the right one, rebuild, extract the PDF text, and attach the page number where the right string now appears. Change nothing else. If the wrong string is not found verbatim, stop and report the nearest match."
- *Render-verifier (CI, not an agent):* `pdftotext` plus grep for every correction's after-string; the badge lint; the `\weld` check; the per-chapter page budget; the hedge count. This is the reference monitor; agents are the agents.
- *Figure agents (one per register row):* "Draw register row ch7-46 in the state-machine grammar (labels off the edges, terminal states distinct) from `lifecycle.tla`; caption opens with the reader question; output TikZ and a PNG; list every label you typed." Review the PNGs in batches of ten.
- *Proof agents:* "State and prove in Lean 4: for N ≥ m ≥ 2k, log2 C(N,2k) − log2 C(m,2k) ≤ 2(log2 C(N,k) − log2 C(m/2,k)). Use C(m,2k) ≥ C(m/2,k)² and C(N,k)² ≥ C(N,2k); no sorry." For the TLA+ work: "Extend Conservation.tla with discount-and-split transfer; the invariant is that total live creditable reputation never increases; run TLC on three principals and report the state count."
- *Measurement agents:* run only pre-registered scripts; they may not change a script after seeing data. Prompt them with the pre-registration text and the seed.
- *Literature agent (web-enabled):* one `cites` record at a time: "Verify that this DOI exists, that the sentence it supports is a claim the cited work makes, and quote the supporting passage."
- *Fresh-eyes reviewer at every gate:* a new agent that has not seen the work reads the rendered PDF with the review document's brief and the gate's checklist. The work does not grade itself.

*What to try later:* run the whole P0–P1 pipeline on `port-daddy` itself — claims as leases, PRs as work units, the render check as the receipt — and record what breaks; that is D28, and it is the only experiment that costs nothing extra.

## The Harbor Research Program: inventory and development plan

*What it is.* The program lives in `docs/harbor-research/` of the public `curiositech/port-daddy` repository (portdaddy.dev refuses automated fetches, so this reads the repo and the library page you printed to Drive on 7 Sept). Its own statement: the part of the whitepaper that has to be proved, measured, or openly admitted unsolved rather than argued for. As of 23 Sept 2026 it holds eight conference-form papers, 35 indexed results (17 R-results, CR, B6, one mechanized proposition, and 14 Paper-8 results marked standalone-only), seven deep dives, four wrong turns, 13 open problems, four planned lifts, one pre-registered study, an estate of 39 formal artifacts (26 ProVerif, 6 Kani, 4 TLA+, 1 Z3, 1 EasyCrypt; 42 wired into CI, 5 retired), and a critique ledger of 897 items (636 done, 242 declined, 18 blocked). The epistemic manifest ties each result to a claim, its conditions, its boundary, its book home and its evidence script, all seeded 20260816.

**Inventory.**

| paper | title | results | book home | deep-dive verdict | state |
| --- | --- | --- | --- | --- | --- |
| 1 | The Price of a Summary | R1–R4, R14, R16 | Ch. 4 | — | folded; R14, R16 chapter-only |
| 2 | Regimented or Enforced | R5, R8 | Ch. 1 | NARROW (Basin et al. 2013 is the real prior; Schneider bugs fixed) | folded; r8-apalache lift planned |
| 3 | Reputation is Amortized Verification | R7 | Ch. 5 | CLEAR (Kofman–Lawarrée leave the regress open) | folded; sampler-leakage open |
| 4 | The Sealed Harbor | R9–R11 | Ch. 3 | NARROW (each pillar is a known result, conceded) | folded; r9-isabelle lift planned |
| 5 | Continuity Without Metaphysics | R12, R13, B6 | Ch. 5 | NARROW (Theorem 2a is Akerlof, renamed) | folded |
| 6 | What Needs an Authority | R15, R17 | Ch. 6 (and 4) | NARROW (compliance-checking literature mapped the shape) | folded; r17 incremental checker open |
| 7 | The Cohomology of Equivocation | CR-1/2/3 | Ch. 8 | CLEAR (citation audit) | folded; cr-coalitions open |
| 8 | Active Sheaf Cohomology for Swarms | R6 + 14 standalone | Ch. 8 | NARROW (sound in its model; utility edge-only) | arXiv tarball prepared; eight attack items |

**What the book takes from each.** Paper 1 gives Ch. 4 its floor, rate, zoom and split-ranker results; Paper 2 gives Ch. 1 its spine (controllability) and the work-unit machine; Paper 3 gives Ch. 5 the judge tower; Paper 4 gives Ch. 3 all four pillars and the canary curve; Paper 5 gives Ch. 5 no-mint, engine substitution and the probation cliff; Paper 6 gives Ch. 6 the queueing boundary and the deontic fragment; Papers 7 and 8 give Ch. 8 the residual and the sheaf machinery. Everything in Part IV's Ch. 7 except the mechanized claim-signaling proposition comes from the book itself, not a paper — which is why Ch. 7 is where the TLA+ defects and the EasyCrypt admits sit.

**Assessment, paper by paper.**

- *Paper 1 (Price of a Summary) — develop.* The program's own ledger already records X15 (shared-head superadditivity is wrong as stated) and X2 (counting bound versus achievability); neither reached the manuscript. Rewrite the paper around decision-sufficiency with Rödl achievability, the pooling gain, and the 1-bit corollary; replace the halving analysis with Hwang; add one measurement (NEXT-P3, the cost-matched reviewer-dependence experiment). Then it is a workshop paper; today it is a counting bound plus a simulation that confirms it.
- *Paper 2 (Regimented or Enforced) — develop, narrowly.* R5 is right and the Basin et al. positioning is now honest. The open problem `partial-observation-regimentation` is the paper's natural second theorem and is standard supervisory-control-under-partial-observation (observability plus controllability); state and prove it for the finite policy model, and run the r8-apalache lift so the 536-state machine has a second checker. This is the easiest paper to finish.
- *Paper 3 (Reputation is Amortized Verification) — fix before develop.* The tower's worked numbers violate its own Becker condition (ρ★ = 10 > 1 in Ch. 5). Repair the numbers, then take `sampler-leakage-correlation` as the next result: the bribery threshold with partially leaked draws and dependent cliques. The deep dive's finding that Kofman and Lawarrée leave exactly this regress open is the paper's best positioning sentence; use it in the abstract.
- *Paper 4 (Sealed Harbor) — narrow and finish.* The pillars are known results and the paper concedes it; its contribution is the composition — four known mechanisms closing each other's gaps — plus the q·b accounting and the laundering residual stated as an open problem. Add `canary-dependence` (power under correlated misses: replace 1−βᵏ with a copula or a worst-case bound) and the r9-isabelle lift only if a reviewer asks; the depth-seven TLC result is enough for a systems venue. Target USENIX SAIS (4 Feb 2027).
- *Paper 5 (Continuity Without Metaphysics) — narrow.* The engine-substitution pair (unattested spiral, attested flip) is the paper; no-mint is a lemma; the probation cliff must be restated so it no longer contradicts its premise (review-synthesis-27). Drop the metaphysics framing from the title if submitting to an economics-adjacent venue.
- *Paper 6 (What Needs an Authority) — split.* It is two notes: the queueing boundary (a tidy addition to Smith and Whitt 1981, with the succession corner) and the deontic fragment (a known shape with a specific tractable fragment). Publish the queueing note short (Operations Research Letters or arXiv math.PR); take `r17-incremental-checker` as the deontic note's new result, with the n² enumeration correction and the X6 fix (NP-completeness does not imply a human resolver).
- *Papers 7 and 8 (equivocation and sheaves) — fold into one.* R6's own one-breath statement says an equal-information sender-claim checker subsumes residual detection on the relayed-report contract; the ATT8 attack items and the `paper8-edge-only-utility` problem say the typed-sheaf machinery's utility is unproven beyond edges. The honest paper is one: equivocation is a 1-cocycle, detection needs a visible cycle, the consistency radius bounds a single liar, coalitions on a cycle cancel (open), and the sheaf formalism is the notation, not the result. That paper (the program's X23) is a clean PODC/DISC brief announcement or an arXiv cs.DC note; the fourteen standalone-only results are an appendix. Do not submit the Paper 8 tarball as it stands.

**The program's machinery, and the one structural fix.** The ledgers are excellent and the pipeline is broken: `BOOK-PROGRAM-ROADMAP.md` records state lost across parallel agent sessions, 89 open PRs, and byte-identical duplicate fixes; the uptake table lists seven corrections-before-expansion the manuscript still prints. A program whose first theorem is "one writer" is running itself with many. Prescription (rule 1): one integrator, a merge queue, `corrections.yaml`, and a CI job that renders the book and greps for every ledger correction's "after" string. Until that job is green, no new research lands in the book.

**Development plan, in priority order.**

1. *Propagate the ledger into the manuscript (P0–P1).* X1, X2, X5, X6, X12, X14, X15, X16, F011, F013, F016, F019, F020, F024, F026, review-synthesis-11, -12, -14, -27, -34. Each becomes a `corrections.yaml` row.
2. *Run three measurements (P3).* INSTRUMENTATION (kernel throughput and tail latency; Ch. 1), NEXT-P3 (cost-matched reviewer dependence; Ch. 4), and the substrate study's S2 arm or the freeze probe (Ch. 7). The substrate study needs substrate D's merge-queue defect fixed and 20 seeds instead of 2; S1 needs KVM on your machine — schedule it as a weekend, not a sprint.
3. *Mechanize four (P3).* δ★ as subgame-perfection (extend `claim_signaling.tla` or Lean), the pooling gain (Lean, elementary), no-mint conservation (TLA+), per-hop attenuation (ProVerif exists; add the paper proof). Retract "EasyCrypt discharged" until the three admits close; EasyCrypt is not in CI, so either install it or remove the row.
4. *Fold Papers 7 and 8 (P2–P5).* One paper, as above.
5. *Take four NEXT items, drop four.* Take P1 (decision-preserving oversight — it is the Ch. 4 spine), P4 (release model with explicit payloads — it closes the laundering residual's model gap), P2 (safe effects under partial or stale observation — it is Paper 2's second theorem) and P6 (future-safe commitments and output-sensitive conflict checking — it is r17). Defer P5, P7, P8 and the c2 take-rate lift to the research directions; they are new work, not repair.
6. *Close the four cheap open problems in prose (P2).* `one-label-scheme` (rule 2), `registry-constitution` (write the two-page constitution: who suspends, under what review, with what appeal), `dispute-arithmetic` (a table of windows, partial work and refunds that Ch. 7's ladder already implies), `canary-dependence` (a worst-case bound replaces the independence assumption; the formula is a paragraph).
7. *Kill list.* X25 (marketplace underwriting), X26 (noisy zoom redo), X27 (sheaf duplication) stay rejected; the Paper 8 arXiv tarball is withheld; `sheaf_experiment.py` and `sheaf_verdict.py` stay in `wrong-turns/` as the cautionary tale they already are.

**What the program is already doing right, and should keep.** Pre-registration with seeds; the critique ledger with declines recorded, not deleted; wrong turns kept with their lessons; negative controls in the estate (six); the epistemic manifest's claim / conditions / boundary triple, which is the badge in rule 2 before it had a name. The book should say, once, that this is how it was made — it is the strongest honesty claim in it, and it is currently invisible to a reader.

## Thirty new research directions

These go beyond the twenty-two additional-work items in the review document and the program's thirteen open problems; where one sharpens an existing open problem it says so. Each gives the question, the method, what would count as a result, the effort in focused weeks, and where it lands in v5. Effort assumes one person with agents; the value-versus-effort map after the list places them. The ones marked **spine** change a chapter's main theorem; the ones marked **measured** are the book's first data.

### Kernel and control (Chs. 1–2)

**D1. Enforceability under delayed observation.** *Question:* the mediator sees events with lag τ; which policies remain regimentable? *Method:* supervisory control with communication delay (Lin 2014; Balemi 1992) applied to the Ch. 1 policy model, with the lease deadline as the delay bound. *Result:* a theorem that the controllable language shrinks to the τ-delay-controllable sublanguage, and a table of which of the chapter's forty invariants survive which τ. *Effort:* 3 weeks. *Lands:* Ch. 1 §1.6 as the spine theorem's second clause; sharpens `partial-observation-regimentation`.

**D2. Crash consistency, measured.** *Question:* does I1b (power-loss rollback under WAL/NORMAL) actually happen, and how often? *Method:* fault injection on the daemon with a CrashMonkey-style harness; 10⁴ injected crashes at random fsync boundaries. *Result:* a measured rollback rate per fault class, replacing "not guaranteed" with a number. *Effort:* 2 weeks. **measured** *Lands:* Ch. 1 §1.3 and the Ch. 1 measured-numbers table.

**D3. Attenuation is a meet in a lattice.** *Question:* what, exactly, does the per-hop check guarantee? *Method:* model a capability as a point in the product lattice (rights × TTL × identity-binding); delegation is meet; the v6 bug is non-monotonicity under composition. Connect to Dennis and Van Horn 1966, Macaroons' caveats, and abstract interpretation's Galois connections. *Result:* a one-page theorem that per-hop verification is exactly the descending-chain condition, which gives the ProVerif result a mathematical statement a reader can carry. *Effort:* 1 week. **spine** *Lands:* Ch. 2 §2.2.

**D4. Revocation that merges.** *Question:* cuckoo filters cannot be OR-ed; what revocation set can be? *Method:* an observed-remove set (Shapiro et al. 2011) with epoch compaction; prove convergence and bound staleness by the Θ(log m) gossip rounds. *Result:* a CRDT for revocation with a stated staleness window; the Ch. 2 gossip theorem gains an object to apply to. *Effort:* 2 weeks. *Lands:* Ch. 2 §2.5.

### Sealing and leakage (Ch. 3)

**D5. Quantity versus semantics of leakage.** *Question:* does laundering (t = f(s) submitted so the gate releases g(t)) ever exceed the q·b budget? *Method:* quantitative information flow (Smith 2009; Alvim et al.). *Result:* it cannot — the gate's output is b bits whatever is submitted — so the residual is semantic (which function of s leaks), not quantitative; the fix is typed payloads (NEXT-P4), and the chapter's residual becomes a clean theorem-plus-open-problem pair. *Effort:* 1 week. **spine** *Lands:* Ch. 3 §3.5.

**D6. Canaries as group testing.** *Question:* where should k canaries go when misses are correlated? *Method:* treat canary placement as a non-adaptive group-testing design (Dorfman 1943; Hwang 1972; Du and Hwang) sharing Ch. 4's machinery; a worst-case power bound under a given dependence structure. *Result:* the power curve 1−βᵏ replaced by a bound that holds under dependence; closes `canary-dependence`. *Effort:* 2 weeks. *Lands:* Ch. 3 §3.3, cross-welded to Ch. 4 §4.4.

**D7. The two-broker ceremony on real hardware.** *Question:* what does dual-attested key release cost? *Method:* run the Ch. 3 ceremony on SEV-SNP or TDX cloud VMs; measure boot-to-release latency and attestation failure modes over 200 runs. *Result:* a measured latency distribution and a list of the ceremony steps that fail in practice. *Effort:* 3 weeks, some cloud spend. **measured** *Lands:* Ch. 3 §3.6.

### Legibility and the operator (Ch. 4)

**D8. The price of a digest in decision terms.** *Question:* how many decisions does a digest lose, not how many bits? *Method:* Le Cam deficiency between the full-record experiment and the digest experiment; compute it for the running case's digests. *Result:* a scalar that prices digests in the operator's loss, which the covering floor cannot; this is the quantitative form of decision-sufficiency. *Effort:* 3 weeks. **spine** *Lands:* Ch. 4 §4.3; sharpens NEXT-P1.

**D9. Read-poverty in the wild.** *Question:* how many artifacts do reviewers actually open? *Method:* instrument the harness' logbook viewer; record open and zoom events over four weeks of real use; estimate the distribution of m. *Result:* the first empirical m, which gives the covering floor its units. *Effort:* 4 weeks elapsed, 1 week of work. **measured** *Lands:* Ch. 4 §4.7.

**D10. Auditing the ranker.** *Question:* "ranking is governing" — so how is the ranker held to account? *Method:* a counter-surface specification (the ranker publishes a sufficient statistic of its ordering) and a sampling audit whose power is computed with Ch. 3's SPRT; connect to algorithm-audit work (Sandvig et al. 2014). *Result:* a protocol plus a power table. *Effort:* 2 weeks. *Lands:* Ch. 4 §4.6; the Ch. 3 → Ch. 4 weld.

**D11. The operator as a player.** *Question:* the SDT model treats the operator as a detector; what if she best-responds to the ranker she knows? *Method:* a Bayesian game between operator criterion and ranker; equilibrium miss rate; connect to misuse / disuse (Parasuraman and Riley 1997) and automation bias. *Result:* conditions under which calibration fails even with a truthful ranker. *Effort:* 3 weeks. *Lands:* Ch. 4 §4.5.

**D12. Attention-priced covering.** *Question:* the covering floor prices bits nobody budgets; what prices attention? *Method:* minimize B / r‑read + m · c‑open subject to zero miss over m; derive the optimum curve. *Result:* a real optimum with a worked point, and the 1-bit ambient-alarm corollary as its boundary case. *Effort:* 1 week. *Lands:* Ch. 4 §4.4.

### Identity and reputation (Ch. 5)

**D13. The judge ceremony as peer prediction.** *Question:* is truthful judging an equilibrium, or only deterred? *Method:* replace the one-shot Becker inequality with a peer-prediction mechanism (Miller, Resnick and Zeckhauser 2005; Dasgupta and Ghosh 2013). *Result:* incentive-compatibility conditions for the ceremony, which the chapter's honesty rider currently says nothing proves. *Effort:* 4 weeks. **spine** *Lands:* Ch. 5 §5.5.

**D14. Which Cheng–Friedman condition does no-mint break?** *Question:* symmetric Sybil-proof reputation functions are trivial (Cheng and Friedman 2005); the harbor's lineage-rooted scheme is not symmetric. *Method:* state the asymmetry precisely and prove no-mint is Sybil-proof against coalitions of principals, or exhibit the coalition that mints. *Result:* either a theorem or a counterexample; both are publishable. *Effort:* 2 weeks. *Lands:* Ch. 5 §5.2.

**D15. What can a daemon attest about the engine?** *Question:* the engine-swap theorem's attested regime assumes the daemon can attest which model ran; can it? *Method:* survey TEE-hosted inference, model watermarking and proof-of-inference schemes; test what the harness can attest today. *Result:* a table of attestable properties with their costs; the theorem's hypothesis made concrete. *Effort:* 2 weeks. *Lands:* Ch. 5 §5.3.

**D16. Tombstones against the right to erasure.** *Question:* append-only evidence meets a lawful request to erase. *Method:* crypto-shredding (encrypt per-record, destroy the key) and the GDPR literature on erasure in logs. *Result:* a tombstone design that keeps the ledger's conservation invariant while making the content unrecoverable. *Effort:* 1 week. *Lands:* Ch. 5 §5.7 and Ch. 8.

### Economy (Ch. 6)

**D17. The tariff under correlated values.** *Question:* the 75% result assumes independent uniform values and costs; when does a posted price do better? *Method:* a common-component model v = θ + εᵥ, c = θ + εᶜ; closed form for a family, simulation for the rest. *Result:* the regime where a tariff approaches the second-best, which is the regime a harbor operator should hope to be in. *Effort:* 2 weeks. *Lands:* Ch. 6 §6.3.

**D18. Partial-work refunds as a cooperative game.** *Question:* `dispute-arithmetic` asks what a refund for partial work is. *Method:* model the repair's partial value and divide by Shapley value against proportional division; check which the Ch. 7 ladder implements. *Result:* the refund table the open problem asks for, with an axiomatic justification. *Effort:* 2 weeks. *Lands:* Ch. 7 §7.5; closes `dispute-arithmetic`.

**D19. Specialist versus pool with learning.** *Question:* the Erlang-C boundary is static; sole ownership also teaches. *Method:* add learning-by-doing (Arrow 1962) to the specialist's service rate. *Result:* the horizon beyond which the specialist wins even below the static boundary. *Effort:* 3 weeks. *Lands:* Ch. 6 §6.2.

**D20. Conflict checking as difference logic.** *Question:* the tractable deontic fragment is Horn rules plus difference constraints on intervals; that is exactly SMT difference logic. *Method:* implement with Z3's difference-logic solver; measure against the chapter's n² enumeration on synthetic policies to 10⁴ rules. *Result:* an incremental checker with timings; closes `r17-incremental-checker`. *Effort:* 2 weeks. **measured** *Lands:* Ch. 6 §6.4.

### Commons and disputes (Ch. 7)

**D21. An empirical δ for agents.** *Question:* δ★ = 0.3425 is a threshold; what is an LLM agent's actual discount factor? *Method:* choice experiments on the harness (now versus later access, bond versus delay), elicited the way behavioural economics elicits time preference (Frederick, Loewenstein and O'Donoghue 2002). *Result:* an estimated δ with a confidence interval per model, which turns the frontier into a bond-sizing rule. *Effort:* 3 weeks. **measured** *Lands:* Ch. 7 §7.4.

**D22. When does anyone climb the ladder?** *Question:* the four dispute mechanisms exist; how often is human escalation reached in equilibrium? *Method:* a sequential bargaining game with mechanism costs; compare the predicted frequency with the logbook's dispute records. *Result:* an equilibrium escalation rate and its empirical check. *Effort:* 3 weeks. *Lands:* Ch. 7 §7.5.

**D23. Cold start as a two-sided platform.** *Question:* the three cold-start phases are gated qualitatively. *Method:* Rochet and Tirole 2003 pricing for the harbor's two sides. *Result:* the subsidy schedule and the quantitative gate conditions. *Effort:* 2 weeks. *Lands:* Ch. 7 §7.7.

**D24. A registry constitution, model-checked.** *Question:* who may suspend a publisher, under what review, with what appeal? *Method:* write the two-page constitution and model its emergency path in TLA+ with a liveness property (every suspension is reinstated or finalized). *Result:* the constitution plus a checked protocol; closes `registry-constitution`. *Effort:* 2 weeks. *Lands:* Ch. 7 §7.5.

### Federation (Ch. 8)

**D25. Locating colluding liars with the cycle code.** *Question:* two liars on one cycle cancel (`cr-coalitions`); how many can be located? *Method:* the witness graph's cycle space is a binary linear code (Hakimi and Bredeson 1968); equivocation is a syndrome; the number of locatable liars is governed by the code's minimum distance. *Result:* a theorem connecting the residual to syndrome decoding, and a design rule for witness topologies. *Effort:* 3 weeks. **spine** *Lands:* Ch. 8 §8.3.

**D26. Witness logs without consensus.** *Question:* the uniqueness requirement is consensus in disguise. *Method:* an accountability argument in the style of PeerReview (Haeberlen, Kouznetsov and Druschel 2007): detection after the fact with the damage window bounded by the gossip rounds. *Result:* a theorem that replaces the uniqueness assumption with a bounded-damage guarantee. *Effort:* 3 weeks. **spine** *Lands:* Ch. 8 §8.2.

**D27. Sponsorship as joint liability.** *Question:* how long should probation be, and how much should the sponsor risk? *Method:* group-lending models (Ghatak 1999) for the sponsor bond. *Result:* probation length and exposure as functions of the newcomer's prior. *Effort:* 2 weeks. *Lands:* Ch. 8 §8.5.

### Cross-cutting

**D28. The book as a harbor.** *Question:* the program lost state across parallel agent sessions and accumulated 89 PRs; what does the single-writer rail do to an agent-run writing pipeline? *Method:* measure PR duplication, lost fixes and time-to-land before and after the merge queue (rule 1); write it up as a software-process case study. *Result:* the book's own production as its first field evidence. *Effort:* runs alongside P0–P1. **measured** *Lands:* a two-page epilogue and a short paper.

**D29. Assurance modes as a lattice.** *Question:* what is the assurance of a system that composes an Attested part with a Coordinated part? *Method:* define composition on the five modes, prove monotonicity, connect to Lampson's gold standard and Saltzer and Schroeder. *Result:* a composition table that lets Appendix A be used, not just read. *Effort:* 1 week. *Lands:* Appendix A, referenced from Ch. 0.

**D30. The Harbor Governance Suite.** *Question:* can another runtime be tested against the nine beats? *Method:* make each beat an executable scenario with a known-correct outcome and a checker; run the harness and two other agent frameworks. *Result:* a benchmark with a leaderboard of what each runtime catches. *Effort:* 5 weeks. **measured** *Lands:* a new Appendix E and a benchmark paper (NeurIPS Datasets and Benchmarks or an agents workshop).

**Value against effort.** The map below places all thirty. *Quick wins* (high value, two weeks or less): D3, D5, D12, D29, D6, D14, D16, D18, D20, D24. *Big bets* (high value, three weeks or more): D8, D9, D13, D21, D25, D26, D28, D30, D1. *Fill-ins* (useful, cheap, not decisive): D2, D4, D10, D15, D17, D23, D27. *Long shots* (expensive, uncertain): D7, D11, D19, D22. Start with the quick wins that are also spine changes — D3, D5 — because each is a week and each gives a chapter its theorem.

&#91;embedded content: effort from each brief above · value zone is this document's judgment · 30 directions\]

## Literature positioning and venues

The literature report's finding, in one sentence: between 2025 and 2026 three neighbouring literatures matured fast enough to anticipate the book's framing — capability and information-flow confinement for agents (CaMeL, FIDES, Progent), attenuated delegation for agents (UCAN, Biscuit, South et al., the IETF agent-grant drafts, the MCP authorization spec), and agent-economy clearing layers (RAILS, TessPay, AP2 / x402, Virtual Agent Economies) — so the defensible novelty is narrower and sharper: the mechanized substrate, the price of a summary, and the bond and inspection-game accounting. The prescription is a **Positioning box** in every chapter (rule: one sentence each on what the neighbours already do and what the chapter adds), and the chapter's claims labelled by the badge where the status page itself says "proposed" (the confined mode, settlement across authorities, the witness log).

**Per chapter: the must-cites and the positioning sentence.**

- *Ch. 1.* Cite AIOS (Mei et al., COLM 2025) and the 2026 AOS reference architecture (arXiv 2608.03214); the filesystem-control and transactional-sandbox papers (arXiv 2604.13536, 2512.12806, 2605.22781 — verify each); the MAC framework (2601.11893); the exact MCP revision targeted. *Sentence:* "AIOS schedules agents; this kernel orders their effects, splits durability by fault class, and states a consistency theorem — none of which an agent OS provides." Do not claim superiority over worktree-plus-merge-queue until the substrate study reports.
- *Ch. 2.* Cite UCAN ("each direct delegation MUST either directly restate or attenuate"), Biscuit, South et al. 2025, AIP (2603.24775), draft-mishra-oauth-agent-grants (the closest standards analogue: sub-agent grants scoped to a subset, depth limit, cascade revocation), the MCP authorization spec (audience-bound, not attenuable across hops — the precise gap), and the classical lineage (Macaroons NDSS 2014, SPKI/SDSI, RFC 8693). *Sentence:* "Narrowing at every hop is the definitional property of Macaroons, Biscuit and UCAN; what is new is the mechanized non-escalation proof with an explicit escalation adversary and negative-control models." The June 2026 "could not have failed" admission must appear in the chapter with the negative controls described.
- *Ch. 3.* Cite CaMeL (SaTML 2026), FIDES (Microsoft 2025; the q·b budget is a quantitative refinement of its selective-reveal primitive), Progent, AgentDojo, A2M (2609.26761; label-based confinement leaks 11–23% under adaptive attack — the argument for a budget rather than a binary), and Lampson 1973 / Kemmerer 1983 for the timing carve-out. *Sentence:* "Gated confinement is CaMeL's and FIDES's architecture; this chapter prices the residual in bits and gives the detector a power curve." If the chapter makes any empirical claim, reviewers expect AgentDojo numbers.
- *Ch. 4.* Cite Korbak et al. 2025 (CoT monitorability), Baker et al. 2025, Drori et al. 2025, Emmons et al. 2025, Zolkowski et al. 2025 (detection collapsing under obfuscation pressure — verify the 96% to under 10% figure in the body before quoting), Kirchner et al. 2024 (prover–verifier legibility, the ML sense of the title word), Chan et al. FAccT 2024, MemGPT for compaction. *Sentence:* "Monitorability work measures what a CoT monitor can see; this chapter bounds what any digest can carry for a finite operator, and zoom-to-evidence is its partial answer to adversarial compression." A targeted ACM DL search for CHI/CSCW studies of humans supervising multiple agents is still owed.
- *Ch. 5.* Cite Chan et al. 2024 (IDs for AI systems) and 2025 (Infrastructure for AI Agents), Tomašev et al. 2025 (Virtual Agent Economies; `did:key` for disposable agents) and Distributional AGI Safety (persistent identity plus directory plus reputation — the closest anticipation), Friedman and Resnick 2001, Douceur 2002, the inspection-game literature (Avenhaus, von Stengel and Zamir 2002) so the bonded judge is not a rediscovery, Zheng et al. 2023 and Miller–Resnick–Zeckhauser 2005 for judging. *Sentence:* "Persistent identity with reputation is proposed in outline elsewhere; this chapter proves what is conserved under fork, distill, swap and resurrect."
- *Chs. 6–8.* Cite Tomašev et al. (the harbor is an intentionally designed, semi-permeable sandbox economy), Hadfield and Koh 2025, RAILS (2606.08790 — the closest single competitor: provisional settlement, appeal window, evidence-gated finality), TessPay, AgentCity (constitutional governance, which overlaps the registry constitution), AP2 and x402 (authorization evidence and payment rail; neither judges performance), Kleros for juror bonds and appeals, Aumann 1974 for the daemon as a correlated-equilibrium device, and for Ch. 8 Certificate Transparency gossip (RFC 6962 / 9162, Chuat et al. 2015), CONIKS, SCITT, Interledger and Herlihy 2018. *Sentence:* "The rails standardize the transaction and RAILS now occupies the clearing layer; what none of them has is a model-checked conservation law, a bond price from an inspection game, a truthful-signaling threshold, and equivocation detection on the witness graph." The July 2026 claim that the rails name agent trust out of scope is no longer true of the field and must be revised.

**Ten works the bibliography most likely lacks** (verify against the 790-page list): CaMeL; FIDES; RAILS; the UCAN specification; South et al. 2025; draft-mishra-oauth-agent-grants-02; Virtual Agent Economies and Distributional AGI Safety; Infrastructure for AI Agents; Korbak et al. with the Zolkowski stress test; AIOS with the AOS reference architecture.

**Venues that are still open, and the paper each fits.** Dates are AoE; those marked tracker are not from an official CFP.

| paper | venue | deadline | fit |
| --- | --- | --- | --- |
| Verified per-hop attenuation (Ch. 2 + Paper 2's calculus) | IEEE S&P 2027 cycle 2 | 17 Nov 2026 (abstract 10 Nov) | only if already complete — it is not; skip |
| same | USENIX Security '27 cycle 2 | 26 Jan 2027 (registration 19 Jan) | 13 pages; Open Science appendix; the Kani and ProVerif artifacts are the asset |
| same | IEEE CSF 2027 winter | 28 Jan 2027 | best fit for a formal attenuation calculus compatible with Biscuit or UCAN rather than bespoke |
| same | ACM CCS 2027 cycle 1 | \~14–15 Jan 2027 (tracker) | broad security venue |
| Leakage budget + canary power (Ch. 3) | USENIX SAIS '27 | 4 Feb 2027 | purpose-built; needs an AgentDojo-style evaluation |
| same | CCS AISec 2027 workshop | mid-2027, TBA | first leakage-budget paper if SAIS slips |
| Price of a summary + decision-sufficiency (Ch. 4) | ICML 2027 main or NeurIPS/ICML oversight workshops | ICML \~22–28 Jan 2027 (tracker); workshops May–Aug 2027 | framed against CoT monitorability |
| same, with the operator study | CHI 2028 / CSCW rolling | \~Sep 2027 / rolling | needs the D9 and NEXT-P3 measurements |
| Bond–patience frontier + inspection-game pricing (Chs. 5, 7) | ACM EC 2027 | TBA; EC'26 precedent 2 Feb abstracts, 9 Feb papers | the right home; prepare on the EC'26 calendar |
| same | WINE 2027; ACM TEAC | \~Jul 2027; rolling | TEAC for the full mechanism with proofs |
| Conservation law + TLA+ with negative controls (Ch. 7) | FM / ABZ / NFM 2027, TLA+ Conference | check official sites | industrial case study framing |
| Equivocation on the witness graph (Ch. 8; Papers 7 + 8 folded) | PODC 2027 brief announcement; DISC 2027 | \~Feb 2027 (tracker); not checked | three-page brief announcement, then arXiv cs.DC |
| Identity and the grading oracle (Ch. 5) | AAMAS 2028; FAccT 2028 | \~Oct 2027; \~Nov 2027 | 2027 cycles closed |
| Whole system | OSDI '27 (8 Dec 2026); EuroSys 2028 spring; NSDI '28 | Dec 2026 is not realistic; \~May 2027 | needs the substrate study, fault injection, AgentDojo numbers, per-hop overhead, measured revocation, a public artifact |

**Portfolio by readiness, mapped to the schedule.** First wave (P5a, weeks 9–13, in parallel with the restructure, for the late-January and early-February 2027 deadlines): the attenuation paper to CSF or USENIX Security, the leakage-budget paper to SAIS, the EC paper prepared on the EC'26 calendar. Second wave (after the measurements, mid-2027): the price-of-a-summary paper with D9's data to an oversight workshop and then CHI 2028, the folded equivocation paper to PODC, the TLA+ case study. The whole-system paper waits for the substrate study, and should: OSDI's programme committee will ask for exactly the five measurements the book does not yet have. The program's own publication candidates X17–X24 should be mapped onto this table and the rest closed.

## Sources

**The manuscript and the review.** Governing AI Agents v4.0 Textbook Edition, 5 Nov 2026 build (409 spreads, 689 body pages, 219,566 words); the companion review document [Review: Governing AI Agents v4.0](https://claude.ai/artifact/51k7t9YXqANsKXbkWuJhS4), whose ten page-cited reviewer notes carry the evidence for every error and cut named here. All arithmetic in this document (δ★(qb), the surplus fractions, the pooling-gain ratios, the Becker ρ★) was recomputed for it.

**The Harbor Research Program** (public repository `github.com/curiositech/port-daddy`, read on 5 Nov 2026): `docs/harbor-research/README.md`; `mega-volume-epistemic-manifest.yaml`; `program.json` (v1, updated 23 Sept 2026: papers, deep dives, wrong turns, planned lifts, open problems, results, estate, critique ledger); `OMNI-LEDGER.md` (work table, NEXT-P1–P8, corrections X1–X27, review-synthesis-01–40, BOOK-RESEARCH-UPTAKE); `BOOK-PROGRAM-ROADMAP.md`; `review-20261014/` (PROGRAM and SEED-FINDINGS F001–F026); `tex/paper1–8.tex`; `experiments/` (checkpoint-busy, freeze-probe-design, handoff-coverage, receipt-gap); `studies/substrate-study/` (PROTOCOL, PILOT, CHANGELOG); `proofs/`; `skills/harbor-results/scripts/`. portdaddy.dev itself refuses automated fetches; the library page was read from your Drive print.

**Google Drive.** Library page print (portdaddy.dev/library, 7 Sept 2026; v4.0 at 538 pages and 221 references; the running-today / modelled / proposed status; changelog); `FIGURE-REGISTER.md` (7 Sept 2026; 378 rows, 64 must, 141 existing figures); "Manuscript Review and Research Plan" (8 Sept 2026, an earlier review; not used here); `coordination-papers-mega-volume.pdf` (Aug 2026, v1.0).

**Literature and venues** (from the finished research report, 5 Nov 2026). Confinement: CaMeL, [arXiv 2503.18813](https://arxiv.org/abs/2503.18813) (SaTML 2026); FIDES, [arXiv 2505.23643](https://arxiv.org/abs/2505.23643); Progent, [arXiv 2504.11703](https://arxiv.org/abs/2504.11703); A2M, [arXiv 2609.26761](https://arxiv.org/pdf/2609.26761). Delegation: [UCAN specification](https://ucan.xyz/specification/); South et al., [arXiv 2501.09674](https://arxiv.org/abs/2501.09674); AIP, [arXiv 2603.24775](https://arxiv.org/pdf/2603.24775); [draft-mishra-oauth-agent-grants-02](https://www.ietf.org/archive/id/draft-mishra-oauth-agent-grants-02.html); [MCP authorization](https://modelcontextprotocol.io/specification/2025-11-25). Kernels: AIOS, [arXiv 2403.16971](https://arxiv.org/abs/2403.16971); AOS, [arXiv 2608.03214](https://arxiv.org/pdf/2608.03214). Legibility: Korbak et al., [arXiv 2507.11473](https://arxiv.org/abs/2507.11473); Zolkowski et al., [arXiv 2510.19851](https://arxiv.org/html/2510.19851v1); Emmons et al., [arXiv 2510.23966](https://arxiv.org/pdf/2510.23966). Identity and economy: Chan et al., [arXiv 2501.10114](https://arxiv.org/abs/2501.10114); Tomašev et al., [arXiv 2509.10147](https://arxiv.org/abs/2509.10147) and [arXiv 2512.16856](https://arxiv.org/html/2512.16856v1); RAILS, [arXiv 2606.08790](https://arxiv.org/pdf/2606.08790); TessPay, [arXiv 2602.00213](https://arxiv.org/pdf/2602.00213); AgentCity, [arXiv 2604.07007](https://arxiv.org/pdf/2604.07007); [AP2 announcement](https://cloud.google.com/blog/products/ai-machine-learning/announcing-agents-to-payments-ap2-protocol). Venues: [IEEE S&P 2027](https://sp2027.ieee-security.org/cfpapers.html); [USENIX Security '27](https://www.usenix.org/conference/usenixsecurity27/call-for-papers); [CSF 2027](https://csf2027.ieee-security.org/cfp.html); [USENIX SAIS '27](https://www.usenix.org/conference/sais27/call-for-papers); [OSDI '27](https://www.usenix.org/conference/osdi27/call-for-papers); [EC'26 CFP precedent](https://ec26.sigecom.org/call-for-contributions-acm/papers/); [CCS 2027 workshops](https://www.sigsac.org/ccs/CCS2027/call-for-workshops.html).

**Classical references invoked in the research directions** (to be verified when cited): Lin 2014 and Balemi 1992 (supervisory control with delay); Dennis and Van Horn 1966; Shapiro et al. 2011 (CRDTs); Smith 2009 and Alvim et al. (quantitative information flow); Dorfman 1943, Hwang 1972 (group testing); Le Cam deficiency; Sandvig et al. 2014; Parasuraman and Riley 1997; Miller, Resnick and Zeckhauser 2005; Dasgupta and Ghosh 2013; Cheng and Friedman 2005; Arrow 1962; Frederick, Loewenstein and O'Donoghue 2002; Rochet and Tirole 2003; Hakimi and Bredeson 1968 (graph-theoretic codes); Haeberlen, Kouznetsov and Druschel 2007 (PeerReview); Ghatak 1999; Lampson 2004; Saltzer and Schroeder 1975; Rödl 1985 and Erdős–Hanani 1963 (covering designs); Smith and Whitt 1981; Myerson and Satterthwaite 1983; Chatterjee and Samuelson 1983.
