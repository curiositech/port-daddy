# Governing AI Agents — Literature Scout for Fourteen Research Directions

Four of the fourteen directions are already settled by known theorems: D5 (laundering capacity is bounded by the gate's output alphabet), D20 (the polynomial/NP boundary for interval-deontic conflict detection), D25 (how many colluding equivocators can be located, via minimum distance) and D6's dependence bound (Fréchet/FKG). The manuscript should cite and restate these rather than claim them. The open contributions are agent-specific: D1 (lease deadlines as delay-robust controllability), D14 (no-mint lineage sybil-proofness), D26 (an explicit damage-window bound), D29 (an assurance-composition law with a non-meet counterexample) and D30 (a governance benchmark covering what no existing suite covers).

## TL;DR

- **Already known (cite and reframe):** D5 (Smith: the min-capacity of a deterministic channel is log of its feasible outputs, and a cascade cannot exceed either link); D20 (Horn rules plus difference constraints are polynomial via negative cycles, and disjunction gives NP-complete disjunctive temporal problems); D25 (the number of locatable errors is ⌊(d−1)/2⌋ for the correctly identified code); D6 worst case (Fréchet: power can collapse to 1−β).
- **Partially known (novelty is in the agent-specific composition):** D1 (Lin 2014 "network controllability"); D3 (attenuation is everywhere, but the lattice-chain theorem has not been stated); D8; D13 (peer prediction for LLM evaluation appeared in 2026, but not for bonded agent-outcome judges); D15 (TEE attestation is cheap, zk is still slow); D26 (BFT forensics gives "0 or ≥ t+1 culpable", but no gossip damage window); D28 (agent merge-conflict rates were measured in 2026, duplicates were not).
- **Open:** D14 (the conservation + lineage theorem), D29 (an assurance-composition law), D30 (a governance benchmark). The strongest standalone papers would be D30+D28 and D1.

## Summary table

| Dir | Verdict | Most important citation | Novelty remaining |
|---|---|---|---|
| D1 | Partially known | Lin, SIAM J. Control Optim. 52(2):1276–1298, 2014, DOI 10.1137/130914942 | A lease deadline turns delayed enforcement into (U,O)-safety/controllability on a delay-augmented plant |
| D3 | Partially known | Birgisson et al., "Macaroons," NDSS 2014 | Per-hop check ⇔ descending chain in a product lattice; the middle-hop bug as a failure of endpoint checking |
| D5 | Known (quantity); partial (semantics) | Smith, QEST 2011 (Thms 3.3–3.4) + Alvim et al. CSF 2012 | A policy language and bound for *which* b-bit functions agent gates release |
| D6 | Partially known | Fréchet–Hoeffding bounds; arXiv 2606.04141 | Power under a specified agent-canary correlation model, plus a disjunct-matrix placement design |
| D8 | Partially known | Blackwell 1953; Le Cam 1964 | The covering bound as the zero-deficiency corner for merge/inspect |
| D13 | Partially known | Qiu, Carroll, Allen, arXiv 2601.20299 | An IC bonded-judge ceremony with spot-checks and collusion resistance |
| D14 | Partially known / open | Seuken & Parkes, AAMAS 2014 | "Conservation + lineage ⇒ sybil-proof" against split-and-recombine |
| D15 | Partially known | Cai et al., arXiv 2504.04715 + H100/Blackwell CC benchmarks | Engine-swap theorem parameterized by attestation mode |
| D20 | Already known | Wałęga et al., IJCAI 2019/2020 + STP/difference logic | Only the mapping and an incremental checker |
| D25 | Already known (with correction) | Hakimi & Bredeson, IEEE TIT 14:584–591, 1968 | Vertex-liar locatability with signed evidence |
| D26 | Partially known | Sheng et al., CCS 2021, DOI 10.1145/3460120.3484566 | An explicit gossip-round damage-window theorem |
| D29 | Partially known / open | McCullough 1988 composability; Common Criteria composition | A meet law for the five modes plus a non-meet counterexample |
| D30 | Open (gap confirmed) | AgentDojo arXiv 2406.13352; MAST (NeurIPS 2025 D&B) | The first suite covering delegation, digests, reputation, economics and federation |
| D28 | Partially known | Xu, Subramanian, Karthik, arXiv 2607.04697 | Measure duplicate work and lost state; test a single integrator |

---

## D1. Enforceability under delayed observation

**(a) Verdict: partially known.** Supervisory control under observation and control delay is a mature subfield with an exact characterization. Feng Lin (SIAM J. Control Optim. 52(2):1276–1298, 2014, DOI 10.1137/130914942) models delays and losses with observation mappings and defines **network controllability** and network observability, which "capture precisely the requirements on effective supervisory control in networked discrete event systems."\[1\]\[2\] Shu & Lin and others give synthesis algorithms. Basin, Jugé, Klaedtke & Zălinescu ("Enforceable Security Policies Revisited," ACM TISSEC 16(1):3, 2013, DOI 10.1145/2487222.2487225) partition actions into **controllable** and **only-observable** ones.\[3\]\[4\] They characterize enforceability as (U,O)-safety, informally "P is safety and bad things are not caused by an only-observable action", and apply it to timing constraints.\[3\]\[5\] Not stated anywhere: a **lease deadline** as the controllable timeout that makes a delayed policy enforceable.

**(b) Must-cite**
- Ramadge & Wonham, SIAM J. Control Optim. 25(1), 1987 (DOI 10.1137/0325013, unverified)
- Lin 2014 (verified)
- Balemi & Brunner, ACC 1992, and Balemi, DEDS 4(1):41–85, 1994\[6\]
- Park & Cho, IEEE TAC 51(5):911–915, 2006 (delay-robust) and Systems & Control Letters 56(2):106–112, 2007\[6\]
- Shu & Lin, IEEE TAC 60(8):2183–2188, 2015, and IEEE TAC 62(1):190–205, 2017\[6\]
- These were all verified as references in arXiv 2103.11273.
- Lin, Zhu, Su et al., "Networked supervisor synthesis against lossy channels with bounded network delays as non-networked synthesis," Automatica 2022, arXiv 2103.11273 (verified)\[7\]
- Basin et al. 2013; Schneider, TISSEC 3(1):30–50, 2000; Ligatti, Bauer & Walker, TISSEC 12(3), 2009
- Textbooks: Cassandras & Lafortune, *Introduction to Discrete Event Systems*; Wonham & Cai, *Supervisory Control of Discrete-Event Systems*, Springer 2018.

**(c) Novelty.** With mediator lag τ and lease ℓ ≥ τ, a policy is regimentable iff it is controllable for the delay-augmented plant. Equivalently, lease expiry is a controllable event that makes the policy (U,O)-safe. This extends the Ch. 1 spine theorem from τ = 0.

**(d) Technique.** Build the delay-augmented "observed plant" automaton (Rashidinejad et al., arXiv 2102.09255; arXiv 2103.11273), then apply supremal controllable sublanguage synthesis.\[8\] Key lemmas are Lin's network-controllability characterization, the "networked = non-networked on the augmented plant" reduction, and Basin et al.'s (U,O)-enforceability theorem, with lease expiry in U and the agent commit in O.

**(e) Venues.** IEEE TAC and Automatica (Shu–Lin line); IFAC-PapersOnLine/WODES; RV and ACM TOPS/TISSEC.

---

## D3. Capability attenuation as a lattice meet

**(a) Verdict: partially known.** Attenuation-only semantics are the design invariant of Macaroons (NDSS 2014: caveats "attenuate and contextually confine," and removing or reordering a caveat breaks the HMAC chain), Biscuit and UCAN.\[9\]\[10\] The 2026 IETF individual draft draft-niyikiza-oauth-attenuating-agent-tokens-00 states a "capability monotonicity invariant (I4)" and depth monotonicity (I2), with chain verification that "enforces the monotonic attenuation invariant at each delegation step."\[11\] That is per-hop checking stated as an invariant, not as a lattice theorem. Lattice access models are classical (Denning 1976; Sandhu 1993). I found **no** statement of "per-hop verification ⇔ descending chain in the product lattice (rights × TTL), with root-vs-leaf checking unsound." I also found none naming the A:write → B:read → C:write re-escalation as an endpoint-check failure. Macaroon verification exists only at the cryptographic level (López-Alt, NYU TR2013-962, verified).\[12\] I found no Tamarin or ProVerif model of chain monotonicity.

**(b) Must-cite**
- Dennis & Van Horn, CACM 9(3), 1966 (unverified DOI)
- Lampson, "Protection," ACM SIGOPS OSR 8(1), 1974 (unverified)
- Denning, CACM 19(5), 1976 (unverified)
- Sandhu, IEEE Computer 26(11), 1993 (unverified)
- Birgisson et al., NDSS 2014 (verified)
- RFC 2693 (SPKI; 5-tuple reduction intersects tags and validity), https://www.rfc-editor.org/rfc/rfc2693
- Abadi, Burrows, Lampson & Plotkin, ACM TOPLAS 15(4), 1993 (unverified)
- Li, Mitchell & Winsborough, RT, IEEE S&P 2002 (unverified)
- draft-niyikiza-oauth-attenuating-agent-tokens-00 (verified).

**(c) Novelty.** For any meet-semilattice of authorities with monotone TTL, per-hop acceptance equals chain descent. Root-vs-final checking accepts exactly the chains with ordered endpoints. The difference between the two is the class of middle-hop re-escalations, which gives a constructive counterexample generator.

**(d) Technique.** Tokens are elements of L = 2^Rights × (ℕ, ≥), and attenuation is a meet, so it is deflationary. SPKI 5-tuple reduction *is* this meet. Prove the descent lemma by induction. Mechanize it as a ProVerif correspondence "accept(c) ⇒ ∀i. auth_{i+1} ≤ auth_i", or as a lemma in Lean/Isabelle. Caveat application forms a closure operator (Galois framing).

**(e) Venues.** IETF OAuth WG (2025–2026 agentic drafts); IEEE CSF; ACM CCS.

---

## D5. Quantity versus semantics of leakage through a gate

**(a) Verdict: already known (quantity) / partially known (semantics).** Smith ("Quantifying information flow using min-entropy," QEST 2011) proves Theorem 3.3: "If C is deterministic, then its min-capacity is the logarithm of the number of feasible outputs." He also proves Theorem 3.4: "the min-capacity of a cascade cannot exceed the min-capacity of either link."\[13\] Laundering t = f(s) followed by an honest g(t) is such a cascade, so leakage is ≤ log₂|range(g)| ≤ b bits per job regardless of f. The "miracle theorem" (Alvim, Chatzikokolakis, Palamidessi & Smith, CSF 2012, Thm 5.1) gives g-capacity ≤ min-capacity for every gain function.\[14\] Shannon capacity ≤ log|Y|.\[15\] So the q·b ledger is a **known-correct upper bound** under all three measures. The semantic residual is the "**what**" dimension of Sabelfeld & Sands' taxonomy (JCS 2009), formalized by delimited release's "escape hatches" (Sabelfeld & Myers). Robust declassification (Zdancewic & Myers 2001) addresses attacker influence over what is released.

**(b) Must-cite**
- Smith, FoSSaCS 2009 (unverified DOI)
- Smith, QEST 2011 (theorems verified)
- Alvim et al., CSF 2012 (verified via arXiv 1905.04332)
- Alvim, Chatzikokolakis, McIver, Morgan, Palamidessi & Smith, *The Science of Quantitative Information Flow*, Springer 2020
- Sabelfeld & Myers, delimited release, ISSS 2003; Sabelfeld & Sands, JCS 17(5), 2009; Zdancewic & Myers, CSFW 2001; Askarov & Sabelfeld, gradual release, S&P 2007 (ids unverified)
- Agent framing: arXiv 2606.04141 (leakage as "bits revealed per observable response").\[16\]

**(c) Novelty.** Not the bound. The novelty is an escape-hatch policy language for agent gates, plus a theorem that a laundering worker can realize exactly the functions in the hatch set. Under adaptive choice across q jobs, total leakage is ≤ q·b bits over an adversarially chosen predicate family.

**(d) Technique.** Cascade/garbling lemmas (Smith Thm 3.4, data processing); adaptive-composition chapters of the 2020 textbook; the counting bound |outputs| ≤ 2^{qb}; Askarov–Sabelfeld knowledge-based release for semantics.

**(e) Venues.** IEEE CSF; IEEE S&P / USENIX Security (agent IFC).

---

## D6. Canary placement under correlated misses

**(a) Verdict: partially known.** The worst-case dependence bound is classical. By Fréchet–Hoeffding, P(all k miss) ∈ [max(0, kβ − (k−1)), β], so power lies between **1 − β** (comonotone misses) and min(1, k(1−β)). Under positive association (Harris–FKG), P(all miss) ≥ β^k, so 1 − β^k is an **upper** bound on power that is valid only under independence. A 2026 agent paper says exactly this: "If an attacker leaks one visible credential string and that string is a honeytoken, the detection probability is 1−β, not 1−β^k" (arXiv 2606.04141, "Caught in the Act(ivation)," with DP honeytoken generation and conformal calibration).\[17\] Related work: "Kill-Chain Canaries" (arXiv 2603.28013) tracks a SECRET-[A-F0-9]{8} canary through exposed/persisted/relayed/executed stages, and arXiv 2507.15613 uses decoy secrets.\[18\]\[19\] I found no application of non-adaptive group-testing designs to canary *placement*.

**(b) Must-cite**
- Spitzner, "Honeytokens," 2003 (unverified URL)
- Bowen, Hershkop, Keromytis & Stolfo, SecureComm 2009 (unverified)
- Juels & Rivest, "Honeywords," ACM CCS 2013 (unverified DOI)
- Dorfman, Ann. Math. Stat. 14(4), 1943; Hwang, JASA 1972; Du & Hwang's book; Aldridge, Johnson & Scarlett, arXiv 1902.06002 (unverified)
- Fortuin–Kasteleyn–Ginibre, Commun. Math. Phys. 22, 1971 (unverified)
- arXiv 2606.04141, 2603.28013, 2507.15613 (verified).

**(c) Novelty.** A one-factor/exchangeable model for agent canary misses, where a shared "recognition" skill Z gives power = 1 − E[β(Z)^k]. Add a d-disjunct placement design that localizes *which* job or channel leaked.

**(d) Technique.** De Finetti/one-factor representation; Bonferroni/Kounias bounds with pairwise data; COMP/DD decoders (Aldridge et al.). Empirically, vary canary format, channel and semantic class, and estimate the pairwise miss correlation per stage, as Kill-Chain Canaries does.

**(e) Venues.** arXiv cs.CR 2026; SaTML; IEEE TIT for designs.

---

## D8. The price of a digest: Blackwell and Le Cam

**(a) Verdict: partially known (provisional; no searches were budgeted).** Blackwell (1953) shows that E dominates F for all decision problems iff F is a garbling of E. Le Cam's deficiency δ(E,F) (1964) is the worst-case excess risk over bounded losses, which is exactly a "decision price of a digest," and it is a linear program for finite experiments. Rate-distortion with d(x,a) = loss (Shannon 1959; "task-oriented" compression) gives the minimal *average* bits. Frankel & Kamenica (2019) value information via decision problems. I found no zero-error, worst-case combinatorial counterpart. The covering bound log₂C(N,k) − log₂C(m,k) sits at the δ = 0, 0-1-loss corner.

**(b) Must-cite (all unverified this session)**
- Blackwell, Ann. Math. Stat. 24(2):265–272, 1953
- Le Cam, Ann. Math. Stat. 35(4), 1964
- Torgersen, *Comparison of Statistical Experiments*, CUP 1991
- Shannon 1959; Cover & Thomas, ch. 10
- Kamenica & Gentzkow, AER 2011; Bergemann & Morris, JEL 2019; Frankel & Kamenica, AER 109(10), 2019
- Tishby, Pereira & Bialek, arXiv physics/0004057.

**(c) Novelty.** For 0-1 merge/inspect loss, δ = 0 iff the digest is a covering. Add an interpolation giving minimal bits at deficiency ε.

**(d) Technique.** Blackwell–Sherman–Stein for δ = 0; Le Cam's randomization criterion for δ > 0; rate-distortion with Hamming-on-decisions distortion compared with covering numbers (greedy covering within a ln factor).

**(e) Venues.** IEEE TIT/ISIT; Econometrica/AER/TE; NeurIPS/ICML. No 2024–2026 application to AI-oversight digests was found (not exhaustively searched).

---

## D13. Incentive-compatible judging of agent work

**(a) Verdict: partially known.** IC elicitation was ported to LLM evaluation in 2025–2026. Qiu, Carroll & Allen (arXiv 2601.20299) prove peer prediction IC under a common prior (Thm 1). They report "inverse scaling": deception resistance grows with the capability gap.\[20\]\[21\] Their abstract reports that "LLM-as-a-Judge become worse than random guess when facing deceptive models 5-20x the judge's size," while training an 8B model with a "0.135B" peer-prediction reward model "recovers most of the drop in truthfulness." arXiv 2508.05469 shows f-mutual-information mechanisms are uniquely characterized as IC under natural conditions (TVD-MI is implementable with LLMs).\[22\]\[23\] Peer Elicitation Games (arXiv 2505.13636) uses determinant-based MI among heterogeneous LLM discriminators.\[24\] Judge manipulation is documented (arXiv 2504.18333, cited in the 2026 survey arXiv 2602.10453).\[25\] **Not published:** a bonded-judge mechanism for *agent outcomes* that combines stake, spot-check verification and collusion resistance. The Becker-style inequality is inspection-game deterrence.

**(b) Must-cite**
- Miller, Resnick & Zeckhauser, Management Science 51(9), 2005; Prelec, Science 306, 2004
- Dasgupta & Ghosh, WWW 2013; Shnayder, Agarwal, Frongillo & Parkes, EC 2016; Kong & Schoenebeck, ACM TEAC 2019
- Gao, Wright & Leyton-Brown, "Incentivizing evaluation via limited access to ground truth: peer-prediction makes things worse" (2016/2019)
- Avenhaus, von Stengel & Zamir, "Inspection games," Handbook of Game Theory Vol. 3, 2002; Becker, JPE 1968
- The ids for the four entries above are unverified.
- arXiv 2601.20299, 2508.05469, 2505.13636 (verified).

**(c) Novelty.** Bonded judges paid by multi-task correlated agreement, with a random fraction p spot-checked against ground truth. The spot-check penalty makes truthful grading a strict equilibrium against k-colluding judges, with a repeated-game version of p·D ≥ bribe.

**(d) Technique.** The Shnayder et al. correlated-agreement mechanism plus a dominating spot-check, since Gao–Wright–Leyton-Brown warn that naive mixing hurts. Inspection-game equilibrium for audit rates. Experiment: Qiu et al.'s deceptive-participant protocol with in-context bribes to judges.

**(e) Venues.** ACM EC; AAMAS; ICLR 2026 (Qiu et al., per the arXiv 2601.20299 abstract page).

---

## D14. Sybil-proofness of lineage-rooted reputation transfer

**(a) Verdict: partially known; the exact theorem is open.** Cheng & Friedman (2005) show symmetric sybilproof reputation functions are trivial, and asymmetric flow-based ones escape (id unverified). Seuken & Parkes (AAMAS 2014, pp. 205–212, verified) prove that accounting mechanisms with *strong transitive trust* cannot be robust to strongly beneficial sybil attacks.\[26\]\[27\] They give a *weak transitive trust* mechanism (an agent transfers trust to only one other) that is robust to the strongest attacks.\[26\]\[28\] Their NetEcon 2011 paper shows that "under reasonable assumptions no sybil-proof accounting mechanism exists."\[29\] "Transfer, never copy" is structurally weak transitive trust plus conservation. I found **no** "conservation + lineage asymmetry ⇒ sybil-proof" theorem.

**(b) Must-cite**
- Cheng & Friedman, P2PECON 2005
- Friedman & Resnick, JEMS 10(2), 2001
- Seuken & Parkes, AAMAS 2014 and NetEcon 2011 (both verified)
- Yokoo, Sakurai & Matsubara, GEB 2004; Conitzer et al., WINE 2010
- SybilGuard (SIGCOMM 2006), SybilLimit (S&P 2008), SumUp (NSDI 2009), Advogato
- Ids for the unverified entries above were not checked.

**(c) Novelty.** With conserved live reputation, discount λ < 1 and a spawn tree rooted at bonded principals, no coalition gains from **split-and-recombine** (fork, trade internally, merge) iff the payoff of reputation is not superadditive over splits. Give an explicit counterexample for threshold (convex) payoffs.

**(d) Technique.** Use Seuken–Parkes' axioms on the transfer graph. Conservation makes a sybil attack a zero-sum internal redistribution, so the only gain is from payoff curvature (Jensen). The lineage tree supplies Cheng–Friedman asymmetry (trust flows from roots).

**(e) Venues.** AAMAS; ACM EC; WINE.

---

## D15. What a runtime can attest about which model ran

**(a) Verdict: partially known; TEE attestation makes "engine attested" realistic for self-hosted or confidential-cloud engines.** On H100, CC overhead "remains below 7%" for most LLM queries (arXiv 2409.03992).\[30\] A 2026 H100+TDX study by Wang, Waqas & Smith (Mozilla) on one H100 80GB found that "confidential mode increases average TTFT by 21.8% for Mistral-7B and 27.8% for Qwen3-30B-A3B, while global token throughput drops by 17.7% and 21.1%" (arXiv 2607.19353). On 8×B200+TDX, Asad & Grunseid (Confidential.ai) measured MiniMax-M2.7 MoE overhead at 1.5% at TP4 and 2.8–3.6% at TP8 (five-repeat medians), whereas unpatched single-GPU SGLang "pays about 35 to 39%" and 8-GPU training "about 10 to 13%" (arXiv 2608.26575). Black-box auditing is weak: Cai, Shi, Zhao & Song (arXiv 2504.04715) show providers evade detection via quantization, randomized substitution and benchmark evasion.\[31\]\[32\] Model equality testing (Gao, Liang & Guestrin, ICLR 2025) and RUT (arXiv 2506.06975) partly close the gap.\[31\] zkLLM (CCS 2024, DOI 10.1145/3658644.3670334) proves 13B-parameter inference "in under 15 minutes" with a proof under 200 kB.\[33\] "Hollow-LLM" (arXiv 2607.28884) shows ZK proves computation with *committed* weights, not that they are the advertised model.

**(b) Must-cite**
- TEE: arXiv 2409.03992, 2607.19353, 2608.26575, 2606.31408 (EnclaveX)
- Auditing: arXiv 2504.04715; Gao et al., ICLR 2025; arXiv 2506.06975; 2512.03816; 2607.20860 (IRIS)
- Proofs: zkLLM (CCS 2024); ZKML (EuroSys 2024); arXiv 2607.28884
- Watermarks: Kirchenbauer et al., ICML 2023 (unverified id)
- Behavior: arXiv 2601.17406 (XGBoost gets 99% precision/recall for Codex PRs, 57% recall for Claude Code)\[34\]
- All verified unless marked otherwise.

| Property | Mechanism | Cost | What it proves | Citation |
|---|---|---|---|---|
| Engine identity | GPU TEE (H100/B200 CC + TDX/SEV-SNP) with remote attestation | <7% (H100 typical); 21.8–27.8% TTFT (H100+TDX, Mozilla study); 1.5–3.6% (B200 MoE, tuned) | The measured weights and stack ran on genuine hardware; trust rests in vendor roots | 2409.03992; 2607.19353; 2608.26575 |
| Correct computation | zk-SNARK/sumcheck | minutes per inference, ~200 kB | Output = f(committed weights, input) | CCS 2024; 2607.28884 |
| Statistical identity | Equality/rank tests, log-prob tracking, IRIS | tens–hundreds of queries | Distributional match with stated power; evadable by partial routing | ICLR 2025; 2506.06975; 2512.03816; 2607.20860 |
| Output provenance | Watermarks | ~0 | That a key was used, not which weights | Kirchenbauer 2023 |
| Agent family | Behavioral classifier | offline | Probable vendor | 2601.17406 |
| Optimistic | Re-execution on dispute (opML-style) | cheap unless challenged | Detectable fraud if re-run | unverified |

**(c) Novelty.** Restate the engine-swap theorem at three levels: unattested; audited with power 1−β_audit; TEE-attested with residual hardware trust. Show the efficient-swap result survives with an audit-power-weighted penalty.

**(d) Technique.** Inspection game where detection probability is a two-sample test's power. TEE as a commitment device. Experiment: Cai et al.'s substitution attacks against each daemon mode.

**(e) Venues.** ICLR 2025; ACM CCS; EuroSys; arXiv cs.CR/DC 2026.

---

## D20. Deontic conflict detection as difference logic

**(a) Verdict: already known.** Ground Horn derivation is linear (Dowling–Gallier). Consistency of difference constraints is negative-cycle detection (Bellman–Ford, O(nm)). Obligation/prohibition overlap is interval intersection. Disjunction yields the NP-complete disjunctive temporal problem (Stergiou & Koubarakis; unverified). DatalogMTL is PSPACE-complete in data complexity (Wałęga, Cuenca Grau, Kaminski & Kostylev, IJCAI 2019, DOI 10.24963/IJCAI.2019/261).\[35\] Its core fragment with only the diamond operator is TC⁰-complete, and the linear extension is NL-complete (IJCAI 2020, DOI 10.24963/IJCAI.2020/266).\[36\]\[37\] Propositional DatalogMTL over ℤ is in NC¹ (KR 2020).\[38\] "Inconsistency Handling in DatalogMTL" (arXiv 2505.10394) studies the complexity of recognizing and generating *conflicts*, with PTIME fragments identified.\[39\] The n² enumeration is naive; a sweep-line gives O(n log n + K).

**(b) Must-cite**
- Wałęga et al., IJCAI 2019, IJCAI 2020, KR 2020 (verified)
- arXiv 2505.10394 (verified)
- Dechter, Meiri & Pearl, AIJ 49, 1991 (STP) (unverified)
- Nebel & Bürckert, JACM 42(1), 1995 (ORD-Horn) (unverified)
- Nieuwenhuis & Oliveras, CAV 2005 (unverified)
- Governatori, "Thou Shalt is not You Will," arXiv 1404.1685 (verified)\[40\]
- Normative-conflict survey in multi-agent systems (Santos et al., JAAMAS 2017; unverified).\[41\]

**(c) Novelty.** None mathematically. The contribution is the reduction (fragment ⊆ STP + ground Horn ⊆ a PTIME DatalogMTL fragment) and an incremental checker.

**(d) Technique.** Incremental negative-cycle detection (as in SMT difference-logic solvers) plus incremental Datalog (DRed/differential dataflow). STP and ORD-Horn give the incremental checker for free.

**(e) Venues.** IJCAI/KR; JURIX/ICAIL; CAV/SAT.

---

## D25. Locating colluding equivocators via graph codes

**(a) Verdict: already known, with a framing correction.** The cycle space of a connected graph is a binary [m, m−n+1, g] code with g the girth (Hakimi & Bredeson, IEEE TIT 14:584–591, 1968; decoding by Bredeson & Hakimi, IEEE TIT 13:348–349, 1967).\[42\]\[43\] A distance-d code corrects ⌊(d−1)/2⌋ errors. **Correction:** consistent witness data is a *coboundary*, and the cycles are **parity checks**. An undetectable edge-error pattern is itself a coboundary, i.e., lies in the **cut space**. The relevant distance is therefore the minimum cut, λ(G), not the girth, and "two liars cancel" means their combined error forms a cut. So ≤ t edge-level equivocations are locatable iff λ(G) ≥ 2t+1, matching power-grid bad-data identifiability (critical measurements; unverified textbook source). Robinson's consistency radius "places a lower bound on the amount of distortion incurred by the fusion process" (Information Fusion 2017; arXiv 1603.01446), which is the manuscript's single-liar bound.\[44\]\[45\] Sheng et al. (CCS 2021) prove the number of identifiable culpable replicas is "either 0 or as large as t+1," and that for n = 2t+1 under synchrony forensic support is "inherently nonexistent."\[46\]\[47\]

**(b) Must-cite**
- Hakimi & Bredeson 1968; Bredeson & Hakimi 1967
- Jungnickel & Vanstone, "q-ary graphical codes," Discrete Math. 1999\[43\]
- Robinson, arXiv 1603.01446; Joslyn, Robinson et al., arXiv 1912.05487\[48\]
- Hansen & Ghrist, J. Appl. Comput. Topology 2019 (arXiv 1808.01513, unverified)
- Sheng et al., CCS 2021 (verified)
- Haeberlen et al., PeerReview, SOSP 2007
- Biggs, *Algebraic Graph Theory*.

**(c) Novelty.** Vertex-liar locatability. A liar corrupts any subset of its incident edges, so the parameter is the minimum-weight nonzero coboundary supported on edges incident to ≤ 2t vertices. Signatures upgrade detection to proofs of culpability.

**(d) Technique.** Syndrome on the fundamental cycles of a spanning tree; minimum-weight decoding as T-join/min-cut; sheaf Laplacian for real coefficients; Sheng et al.'s two-world indistinguishability for impossibility.

**(e) Venues.** IEEE TIT; ACM CCS 2021; AFT 2024 (CFT-Forensics, DOI 10.4230/LIPIcs.AFT.2024.3).\[49\]

---

## D26. Witness logs without consensus

**(a) Verdict: partially known.** Fork-linearizability is the best achievable against a Byzantine server without trusted hardware (Mazières & Shasha, PODC 2002; Cachin, Shelat & Shraer, PODC 2007; ids unverified). PeerReview gives accountability instead of agreement (SOSP 2007). BFT forensics formalizes (m, k, d) with d ∈ {0} ∪ [t+1, …] (Sheng et al., CCS 2021).\[46\] Gong et al. (USENIX Security 2025) define accountability as: "when correct replicas commit to contradicting outputs, all correct replicas eventually identify a set of faulty parties with proofs of culpability."\[50\] CFT-Forensics (AFT 2024) extends this to crash-fault protocols.\[49\] **I found no explicit theorem of the form "equivocation detected within R gossip rounds w.h.p., with at most X operations affected."**

**(b) Must-cite**
- Mazières & Shasha 2002; SUNDR, OSDI 2004; Cachin et al. 2007
- PeerReview, SOSP 2007; Depot, OSDI 2010
- Sheng et al., CCS 2021; Gong et al., USENIX Security 2025; Tang et al., AFT 2024 (verified)
- Civit, Gilbert & Gramoli, Polygraph, 2021 (unverified)\[50\]
- Chuat et al., IEEE CNS 2015 (CT gossip; unverified)
- Karp, Schindelhauer, Shenker & Vöcking, FOCS 2000 (unverified).

**(c) Novelty.** A stated pair. Impossibility: uniqueness ⇒ consensus (n > 3f under partial synchrony). Possibility: with signed statements and push-pull gossip, detection occurs in O(log n) rounds w.h.p. and the damage is ≤ rate × window, priced by slashing.

**(d) Technique.** Karp et al.'s rumor-spreading bound (two conflicting statements as two rumors; detection when one node holds both) plus fork-linearizability's join-at-most-once property. Simulate a CT-style overlay under adversarial partition.

**(e) Venues.** ACM CCS; USENIX Security 2025; AFT 2024; PODC/DISC.

---

## D29. Assurance modes as a lattice

**(a) Verdict: partially known; the specific law is open (provisional; no searches budgeted).** "Weakest link = meet" is the folk law behind Common Criteria composite evaluation (ACO class, Composed Assurance Packages, ISO/IEC 15408-3). Bell–LaPadula and Biba compose by lattice operations. But composition can fail. McCullough (IEEE S&P 1988) showed generalized noninterference is not preserved under hook-up, and McLean (IEEE S&P 1994) characterized which trace properties compose. Bloomfield & Rushby's "Assurance 2.0" (arXiv 2004.10474, unverified) composes *arguments*, not levels. I found no stated meet law for runtime assurance modes.

**(b) Must-cite (unverified ids)**
- Saltzer & Schroeder, Proc. IEEE 63(9), 1975
- Lampson, IEEE Computer 37(6), 2004
- Bell–LaPadula 1973/76; Biba 1977
- McCullough 1988; McLean 1994
- ISO/IEC 15408-3
- Bloomfield & Rushby, arXiv 2004.10474
- Clarkson & Schneider, "Hyperproperties," JCS 2010.

**(c) Novelty.** Order the five modes by guaranteed properties. Prove composition is the meet for safety-type guarantees (closed under conjunction). Exhibit a non-meet counterexample for confidentiality (hyperproperties): Confined ∘ Observed, where the audit log records sealed inputs, is worse than either component.

**(d) Technique.** Alpern–Schneider safety composes by intersection; hyperproperties do not (McCullough/McLean); Abadi–Lamport assume-guarantee ("Composing specifications," TOPLAS 1993) for the positive direction.

**(e) Venues.** IEEE CSF; SAFECOMP/ISSRE; IEEE S&P.

---

## D30. Benchmarks for governing agent swarms

**(a) Verdict: open; the gap is confirmed.** Existing suites cover prompt injection, harmful compliance, sabotage/monitoring and collaboration. None covers delegation chains, digest sufficiency, reputation under engine swap, economic mechanisms or federation.

**(b) Benchmarks** (arXiv ids verified on abstract pages; venues unverified except MAST and MonitorBench)

| Benchmark | arXiv | Measures | Concur. | Deleg. | Exfil. | Oversight | Identity | Econ. | Fed. |
|---|---|---|---|---|---|---|---|---|---|
| AgentDojo | 2406.13352 | Prompt injection; 97 tasks, 629 security cases\[51\] | – | partial | yes | – | – | – | – |
| ASB | 2410.02644 | 10 scenarios, 400+ tools, 27 attacks/defenses\[52\] | – | partial | yes | – | – | – | – |
| InjecAgent | 2403.02691 | 1,054 indirect-injection cases\[53\] | – | – | yes | – | – | – | – |
| SHADE-Arena | 2506.15740 | Sabotage vs LLM monitors\[54\] | – | – | partial | yes | – | – | – |
| MonitoringBench | 2605.09684 | 2,644 BashArena attacks; catch rate 94.9%→60.3%\[55\]\[56\] | – | – | partial | yes | – | – | – |
| MonitorBench | 2603.28590 (COLM 2026) | CoT monitorability; 1,514 instances\[57\] | – | – | – | partial | – | – | – |
| AgentHarm | 2410.09024 | 110 malicious tasks, 11 categories\[58\] | – | – | – | – | – | – | – |
| ToolEmu | 2309.15817 | LM-emulated sandbox; 144 cases\[59\] | – | partial | partial | – | – | – | – |
| OS-Harm | 2506.14866 | Computer-use safety; 150 tasks\[60\] | – | – | partial | – | – | – | – |
| R-Judge | 2401.10019 | Risk judging; 569 records\[61\] | – | – | – | partial | – | – | – |
| Agent-SafetyBench | 2412.14470 | 349 envs, 2,000 cases\[62\] | – | partial | partial | – | – | – | – |
| TheAgentCompany | 2412.14161 | Workplace capability (30% best)\[63\] | partial | – | – | – | – | – | – |
| MultiAgentBench | 2503.01935 | Collaboration/competition KPIs\[64\] | yes | – | – | – | – | partial | – |
| Secret Collusion | 2402.07510 | Steganographic collusion\[65\] | partial | – | yes | – | – | – | – |
| MAST | 2503.13657 (NeurIPS 2025 D&B) | 14 failure modes, 1,642 traces\[66\] | yes | – | – | – | – | – | – |

**Gaps the nine scenarios fill:**
- Linearizability checking for stale writes; MAST only taxonomizes such failures.
- Delegation-chain tests (force-push, middle-hop).
- Bit-budgeted leakage with canaries; AgentDojo and InjecAgent test exfiltration but without a budget.
- Digest sufficiency (Potemkin green suite); SHADE-Arena and MonitoringBench test monitors, not digests.
- Engine swap, refused efficient trades, bonded disputes and cross-harbor equivocation: entirely absent.

**(c) Novelty.** The first suite with deterministic *property checkers*: linearizability, attenuation monotonicity, the q·b ledger, digest-decision invariance, conservation, IC outcomes and cocycle consistency.

**(d) Design.** Follow AgentDojo's stateful user-task × injection-task design with utility-under-attack metrics.\[51\] Report judge–human agreement for non-deterministic checks (as OS-Harm and R-Judge do).\[60\] Ship a Docker harness, a versioned leaderboard and held-out adaptive attacks, since MonitoringBench shows refined attacks sharply cut catch rates.\[56\]

**(e) Venues.** NeurIPS D&B (MAST 2025); COLM 2026 (MonitorBench); ICLR (several, unverified).

---

## D28. Agent-run software processes losing state

**(a) Verdict: partially known.** Merge conflicts were measured in 2026; duplicate work and lost state were **not** found as published metrics. Xu, Subramanian & Karthik (arXiv 2607.04697) used AIDev-pop (33,596 agent PRs in 2,807 repositories).\[67\] 79.4% of agent PRs were open concurrently with another agent PR, mostly from the same agent. Merge replay of 747 unique pairs gave textual conflict rates of 19.8% for same-agent pairs and 41.7% for cross-agent pairs, with non-overlapping CIs. 84.4% of conflicting files were source code, and 42% of conflicts were structural.\[68\] AgenticFlict (Ogenrwot & Businge, AIware '26, DOI 10.1145/3805760.3814923; arXiv 2604.03551) simulated merges for 107,026 of 142,652 agent PRs and found "a conflict rate of 27.67%," ranging from 31.85% for OpenAI Codex to 15.24% for Copilot. An SBES 2026 study of 14,960 conflicting internal merges in 12,299 AI-authored PRs found agents rarely resolve their own conflicts, with self-resolution rates differing "by nearly 60× across vendors."\[69\] MAST (Cemri et al., NeurIPS 2025 D&B; 150 traces, κ = 0.88; 1,642 annotated traces) names step repetition, loss of conversation history and information withholding, which are qualitative analogues of duplicate work and lost state.\[66\]\[70\] Base dataset: AIDev (arXiv 2507.15003), with 456,535 agent PRs across 61,453 repositories.\[71\]

**(b) Must-cite**
- AIDev, arXiv 2507.15003; arXiv 2607.04697; arXiv 2604.03551
- "How AI Coding Agents Resolve Merge Conflicts," SBES/CBSoft 2026
- Cemri et al., arXiv 2503.13657
- Brooks, *The Mythical Man-Month* (surgical team)
- Wessel et al. on bot PRs (unverified)
- Bors/Homu/Zuul and the GitHub merge queue (not searched).

**(c) Novelty.** First measurement of duplicate (byte-identical or equivalent) fixes and lost/superseded PRs across parallel agent sessions, plus a single-integrator intervention. The manuscript's own 89-PR history is an n = 1 case study.

**(d) Design.** Reuse the merge-replay pipeline of arXiv 2607.04697. Detect duplicates by diff hash, then AST-normalized diff, then embeddings. Report supersession rate, time-to-integration and conflict rate before and after a merge queue, using an interrupted time series.

**(e) Venues.** MSR 2026 (AIDev mining challenge); ICSE/FSE; SBES 2026; NeurIPS D&B.

---

## Collisions and merges

- **D25 + D26 are one problem.** D25 is identifiability (the cut-code distance); D26 is latency (gossip). Sheng et al.'s "0 or ≥ t+1" applies to both. Present them as "identifiability + latency = bounded-damage accountability."
- **D5 + D6 share the ledger.** Expected undetected leakage is ≤ q·b·P(all canaries miss). The worst case is q·b·β, not q·b·β^k.
- **D8 contains Ch. 4's covering bound** as the zero-deficiency corner (Blackwell–Sherman–Stein).
- **D13 + D15 are one inspection game:** audit probability × penalty ≥ gain, whether the audit is a judge spot-check or a model-equality test.
- **D3 + D29 share meet algebra,** and in both a middle element breaks endpoint reasoning: re-escalation in D3, McCullough's hook-up in D29.
- **Settled by one theorem:** D5 (Smith Thm 3.4 + the miracle theorem); D20 (STP negative cycles + NP-completeness of disjunctive temporal problems + DatalogMTL fragments); D25 (⌊(d−1)/2⌋ with d = λ(G)).
- **D1 is a corollary** of the augmented-plant reduction (arXiv 2103.11273) once the lease is modeled as a controllable timeout.

## Caveats

- The search budget ran out before D8, D29, Gao–Wright–Leyton-Brown and the inspection-games chapter were searched. Those identifiers are from memory and marked unverified.
- D30 arXiv ids were verified. Venues were not, except MAST and MonitorBench. SHADE-Arena is confirmed as Kutasov et al. (last author Joe Benton; arXiv 2506.15740): its best saboteurs score "27% (Claude 3.7 Sonnet) and 15% (Gemini 2.5 Pro)," and the top monitor (Gemini 2.5 Pro) reaches "an AUC of 0.87."
- Several 2026 substitution audits (KBF, API-TAIL, IMMACULATE, AgentProv) were seen only in a blog and are not cited.\[72\]
- The D25 cut-space correction is my derivation from standard algebraic graph theory and was not found stated for witness graphs. Check it against the manuscript's coefficient ring.
- D6 bounds are standard probability; arXiv 2606.04141 is the only agent-specific source.
- Many 2026 sources are unrefereed preprints (2607.04697, 2606.04141, 2607.19353, 2608.26575, 2607.28884); AgenticFlict appeared at AIware '26 and Qiu et al. at ICLR 2026.
- TEE overhead figures conflict across studies and depend on stack configuration.\[30\]\[73\]\[74\]

## Sources

1. [Supervisory control under delayed observations of events and states](https://www.researchgate.net/publication/381754633_Supervisory_control_under_delayed_observations_of_events_and_states)
2. [Supervisory Control Synthesis of Timed Automata Using Forcible Events](https://www.researchgate.net/publication/349424520_Supervisory_Control_Synthesis_of_Timed_Automata_Using_Forcible_Events)
3. [GitHub - repowazdogz-droid/mcp-authority-boundary: Cedar-enforced MCP tool boundary separating mediation, authorization-execution binding, and policy adequacy. Falsified and repaired; fully reproducible. · GitHub](https://github.com/repowazdogz-droid/mcp-authority-boundary)
4. [A Enforceable Security Policies Revisited DAVID BASIN, ETH Zurich](https://people.inf.ethz.ch/basin/pubs/tissec-enforce2013.pdf)
5. [Enforceable Security Policies Revisited](https://dl.acm.org/doi/10.1145/2487222.2487225)
6. [Networked Supervisor Synthesis Against Lossy Channels with Bounded Network Delays as Non-Networked Synthesis](https://arxiv.org/pdf/2103.11273)
7. [Networked supervisor synthesis against lossy channels with bounded network delays as non-networked synthesis - ScienceDirect](https://www.sciencedirect.com/science/article/abs/pii/S000510982200125X)
8. [Supervisory Control of Timed Discrete-Event Systems Subject to Communication Delays and Non-FIFO Observations - ScienceDirect](https://www.sciencedirect.com/science/article/pii/S2405896318306700)
9. [Macaroons: Cookies with Contextual Caveats for ...](https://www.ndss-symposium.org/wp-content/uploads/2017/09/04_3_1.pdf)
10. [How Superintelligence Works](https://edukatesg.com/2026/10/26/how-superintelligence-works-agent-macaroon-capabilities-chained-hmac-caveats-delegation/)
11. [Attenuating Authorization Tokens for Agentic Delegation Chains](https://datatracker.ietf.org/doc/html/draft-niyikiza-oauth-attenuating-agent-tokens-00)
12. [Cryptographic Security of Macaroon Authorization Credentials Adriana L´opez-Alt](https://cs.nyu.edu/media/publications/TR2013-962.pdf)
13. [(PDF) Quantifying Information Flow Using Min-Entropy](https://www.researchgate.net/publication/224261861_Quantifying_Information_Flow_Using_Min-Entropy)
14. [Quantifying information flow in interactive systems](https://arxiv.org/pdf/1905.04332)
15. [1 Channel Capacity Channel Capacity](https://www.di.univr.it/documenti/OccorrenzaIns/matdid/matdid596931.pdf)
16. [Caught in the Act(ivation): Toward Pre-Output and Multi-Turn Detection of Credential Exfiltration by LLM Agents](https://arxiv.org/pdf/2606.04141)
17. [Caught in the Act(ivation): Toward Pre-Output and Multi-Turn Detection of Credential Exfiltration by LLM Agents](https://arxiv.org/html/2606.04141)
18. [Multi-Stage Prompt Inference Attacks on Enterprise LLM Systems](https://arxiv.org/html/2507.15613v1)
19. [Kill-Chain Canaries: Stage-Level Tracking of Prompt ...](https://arxiv.org/html/2603.28013v2)
20. [Truthfulness Despite Weak Supervision:Evaluating and Training LLMs Using Peer Prediction](https://arxiv.org/html/2601.20299)
21. [\[2601.20299\] Truthfulness Despite Weak Supervision: Evaluating and Training LLMs Using Peer Prediction](https://arxiv.org/abs/2601.20299)
22. [Let’s Measure Information Step-by-Step: LLM-Based Evaluation Beyond Vibes](https://arxiv.org/html/2508.05469v1)
23. [Let's Measure Information Step-by-Step: AI-Based Evaluation Beyond Vibes](https://arxiv.org/pdf/2508.05469)
24. [Incentivizing Truthful Language Models via Peer Elicitation Games](https://arxiv.org/html/2505.13636v1)
25. [The Landscape of Prompt Injection Threats in LLM Agents: From Taxonomy to Analysis](https://arxiv.org/pdf/2602.10453)
26. [\[PDF\] Sybil-proof accounting mechanisms with transitive trust](https://www.semanticscholar.org/paper/Sybil-proof-accounting-mechanisms-with-transitive-Seuken-Parkes/2d26b9350e6686ec9746386bbcf1d563322c8cd8)
27. [Full article: Sybil attack vulnerability trilemma](https://www.tandfonline.com/doi/full/10.1080/17445760.2024.2352740)
28. [Sybil-proof Accounting Mechanisms with Transitive Trust Citation](https://dash.harvard.edu/server/api/core/bitstreams/7312037d-8968-6bd4-e053-0100007fdf3b/content)
29. [On the Sybil-Proofness of Accounting Mechanisms](https://dash.harvard.edu/entities/publication/73120378-962b-6bd4-e053-0100007fdf3b)
30. [Confidential Computing on NVIDIA Hopper GPUs: A Performance Benchmark Study](https://arxiv.org/pdf/2409.03992)
31. [Auditing Black-Box LLM APIs with a Rank-Based Uniformity Test](https://arxiv.org/html/2506.06975)
32. [Preprint. Are You Getting What You Pay For? Auditing Model Substi-](https://arxiv.org/pdf/2504.04715v1)
33. [zkLLM: Zero Knowledge Proofs for Large Language Models](https://dl.acm.org/doi/10.1145/3658644.3670334)
34. [Fingerprinting AI Coding Agents on GitHub Taher A. Ghaleb](https://arxiv.org/pdf/2601.17406)
35. [DatalogMTL: Computational Complexity and Expressive Power](https://mlanthology.org/ijcai/2019/walega2019ijcai-datalogmtl/)
36. [Tractable Fragments of Datalog with Metric Temporal Operators](https://ijcai.org/proceedings/2020/266)
37. [Tractable Fragments of Datalog with Metric Temporal Operators](https://mlanthology.org/ijcai/2020/walega2020ijcai-tractable/)
38. [DatalogMTL over the Integer Timeline](https://proceedings.kr.org/2020/79/kr2020-0079-walega-et-al.pdf)
39. [Inconsistency Handling in DatalogMTL](https://arxiv.org/pdf/2505.10394)
40. [Thou Shalt is not You Will](https://arxiv.org/pdf/1404.1685)
41. [(PDF) Detection and resolution of normative conflicts in multi-agent systems: a literature survey](https://www.researchgate.net/publication/315931669_Detection_and_resolution_of_normative_conflicts_in_multi-agent_systems_a_literature_survey)
42. [Codes based on complete graphs](https://link.springer.com/article/10.1007/BF00130575)
43. [Maximality of the cycle code of a graph - ScienceDirect](https://www.sciencedirect.com/science/article/pii/0012365X94901325)
44. [Sheaves are the canonical data structure for sensor integration - ScienceDirect](https://www.sciencedirect.com/science/article/abs/pii/S156625351630207X)
45. [Sheaves are the canonical datastructure for sensor integration](https://arxiv.org/pdf/1603.01446)
46. [BFT Protocol Forensics](https://arxiv.org/pdf/2010.06785)
47. [BFT Protocol Forensics](https://dl.acm.org/doi/10.1145/3460120.3484566)
48. [A Sheaf Theoretical Approach to Uncertainty Quantification of Heterogeneous Geolocation Information](https://arxiv.org/html/1912.05487)
49. [CFT-Forensics: High-Performance Byzantine Accountability for Crash Fault Tolerant Protocols](https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.AFT.2024.3)
50. [Recover from Excessive Faults in Partially-Synchronous ...](https://www.usenix.org/system/files/usenixsecurity25-gong-tiantian.pdf)
51. [AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents](https://arxiv.org/abs/2406.13352)
52. [Agent Security Bench (ASB): Formalizing and Benchmarking Attacks and Defenses in LLM-based Agents](https://arxiv.org/abs/2410.02644)
53. [InjecAgent: Benchmarking Indirect Prompt Injections in Tool-Integrated Large Language Model Agents](https://arxiv.org/abs/2403.02691)
54. [SHADE-Arena: Evaluating Sabotage and Monitoring in LLM Agents](https://arxiv.org/abs/2506.15740)
55. [MonitoringBench: Semi-Automated Red-Teaming for Agent Monitoring](https://arxiv.org/html/2605.09684v1)
56. [\[2605.09684\] MonitoringBench: Semi-Automated Red-Teaming for Agent Monitoring](https://arxiv.org/abs/2605.09684)
57. [\[2603.28590\] MonitorBench: A Comprehensive Benchmark for Chain-of-Thought Monitorability in Large Language Models](https://arxiv.org/abs/2603.28590)
58. [AgentHarm: A Benchmark for Measuring Harmfulness of LLM Agents](https://arxiv.org/abs/2410.09024)
59. [Identifying the Risks of LM Agents with an LM-Emulated Sandbox](https://arxiv.org/abs/2309.15817)
60. [OS-Harm: A Benchmark for Measuring Safety of Computer Use Agents](https://arxiv.org/abs/2506.14866)
61. [R-Judge: Benchmarking Safety Risk Awareness for LLM Agents](https://arxiv.org/abs/2401.10019)
62. [Agent-SafetyBench: Evaluating the Safety of LLM Agents](https://arxiv.org/abs/2412.14470)
63. [TheAgentCompany: Benchmarking LLM Agents on Consequential Real World Tasks](https://arxiv.org/abs/2412.14161)
64. [MultiAgentBench: Evaluating the Collaboration and Competition of LLM agents](https://arxiv.org/abs/2503.01935)
65. [Secret Collusion among AI Agents: Multi-Agent Deception via Steganography](https://arxiv.org/abs/2402.07510)
66. [Why Do Multi-Agent LLM Systems Fail?](https://www.alphaxiv.org/abs/2503.13657)
67. [\[2607.04697v2\] AI Agent Pull Requests on GitHub: Frequency, Structure, and Merge Conflict Rates](https://arxiv.org/abs/2607.04697v2)
68. [AI Agent Pull Requests on GitHub: Frequency, Structure, and Merge Conflict Rates](https://arxiv.org/pdf/2607.04697)
69. [How AI Coding Agents Resolve Merge Conflicts: An Empirical Study](https://cbsoft.sbc.org.br/2026/data/papers/sbes/How%20AI%20Coding%20Agents%20Resolve%20Merge%20Conflicts%20An%20Empirical%20Study.pdf)
70. [Why Do Multi-Agent LLM Systems Fail? Mert Cemri1∗ Melissa Z. Pan1∗ Shuyi Yang2∗](https://proceedings.neurips.cc/paper_files/paper/2025/file/b1041e52d3be19f0a9bc491657488e4a-Paper-Datasets_and_Benchmarks_Track.pdf)
71. [The Rise of AI Teammates in Software Engineering (SE) 3.0: How Autonomous](https://arxiv.org/pdf/2507.15003)
72. [Which model is your API actually serving? Four ways it has been checked in 2026 - DEV Community](https://dev.to/lumen_ilands/which-model-is-your-api-actually-serving-four-ways-it-has-been-checked-in-2026-1kmm)
73. [Benchmarking Confidential GPU Inference on NVIDIA H100 under Intel TDX](https://arxiv.org/html/2607.19353v1)
74. [Benchmarking Confidential Computing Performance on NVIDIA Blackwell GPUs](https://arxiv.org/pdf/2608.26575)
