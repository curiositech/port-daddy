Port Daddy FleetBar developer preview

This archive contains FleetBar.app, the macOS menu-bar companion for Port Daddy.
It is built from apps/FleetBar in the Port Daddy repository by:

  npm run package:fleetbar-preview

This developer preview is ad-hoc signed, not Developer ID signed or notarized.
macOS may require Open Anyway in System Settings. The full daemon, CLI, MCP
wiring, and project setup still come from the normal Port Daddy install path.
