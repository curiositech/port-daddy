Port Daddy FleetBar signed Mac build

This archive contains FleetBar.app, the macOS menu-bar companion for Port Daddy.
It is built from apps/FleetBar in the Port Daddy repository by:

  npm run package:fleetbar-preview

The full daemon, CLI, MCP wiring, and project setup still come from the normal
Port Daddy install path.

Signing: developer-id
Developer ID identity: Developer ID Application: Curiositech LLC (P5H9P59X2M)
Team ID: P5H9P59X2M
Notarization: not-submitted
Notary request ID: 8075359e-5dfc-4598-84c0-771f60dbef17
Notarization result: Accepted
